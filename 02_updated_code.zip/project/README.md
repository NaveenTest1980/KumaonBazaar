# Kumaon Bazaar - Kumaon's Premier Marketplace

A local marketplace application for the Kumaon region of Uttarakhand, India. This platform allows users to buy, sell, and exchange goods locally.

## Features

- User authentication (signup, login, profile management)
- Ad posting with multiple image uploads
- Category and location-based browsing
- Search functionality
- Favorites system
- Responsive design for all devices
- Multi-language support (Hindi/English)
- Location-based filtering by Kumaon districts
- Phone number visibility management
- Featured ads system

## Technologies Used

- **Frontend**: React, TypeScript, Tailwind CSS
- **Backend**: Node.js with Express
- **Database**: Neon PostgreSQL (Serverless Postgres)
- **Storage**: Cloudflare R2 (Object Storage)
- **Authentication**: JWT Authentication

## Getting Started

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a `.env` file with required environment variables
4. Start the development server:
   ```bash
   npm run dev
   ```

## Environment Variables

```env
# Database
VITE_NEON_DATABASE_URL=your_database_url

# Cloudflare R2 Configuration
VITE_CLOUDFLARE_ACCESS_KEY_ID=your_access_key_id
VITE_CLOUDFLARE_SECRET_ACCESS_KEY=your_secret_access_key
VITE_CLOUDFLARE_TOKEN=your_token_value
CLOUDFLARE_BUCKET_NAME=your_bucket_name
CLOUDFLARE_PUBLIC_URL=https://pub-xxxxxxxxxxxxxxxx.r2.dev

# JWT Configuration
JWT_SECRET=your_jwt_secret_key
JWT_EXPIRY=1h
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License.

## Contact

For any queries, please contact us at contact@kumaonbazaar.com