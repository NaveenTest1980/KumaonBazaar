import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    strictPort: true,
    host: true,
    hmr: {
      clientPort: 443,
      port: 5173,
      timeout: 60000 // Increase timeout to 60 seconds
    }
  },
  preview: {
    port: 5173,
    strictPort: true,
    host: true
  },
  optimizeDeps: {
    exclude: ['@neondatabase/serverless'] // Exclude problematic dependencies
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')
    }
  }
});