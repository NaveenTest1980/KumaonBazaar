-- Set search path to neondb
SET search_path TO neondb;

-- Start transaction
BEGIN;

-- Drop and recreate categories table to ensure clean state
DROP TABLE IF EXISTS categories CASCADE;

CREATE TABLE categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  icon text NOT NULL,
  price_label text DEFAULT 'Price',
  coming_soon boolean DEFAULT false,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

-- Insert all categories with proper price labels and coming soon status
INSERT INTO categories (id, name, icon, price_label, coming_soon)
VALUES
  ('books', 'Books', 'BookOpen', 'Price', false),
  ('vehicles', 'Vehicles', 'Car', 'Price', false),
  ('real-estate', 'Real Estate', 'Home', 'Price', false),
  ('electronics', 'Electronics', 'Smartphone', 'Price', false),
  ('jobs', 'Jobs', 'Briefcase', 'Salary', false),
  ('furniture', 'Furniture', 'Sofa', 'Price', false),
  ('fashion', 'Fashion', 'ShoppingBag', 'Price', false),
  ('education', 'Education & Learning', 'GraduationCap', 'Fees', false),
  ('hotels', 'Hotels & Resorts', 'Hotel', 'Price', false),
  ('food', 'Food & Dining', 'UtensilsCrossed', 'Price', false),
  ('grocery', 'Grocery & Supermarkets', 'ShoppingCart', 'Price', false),
  ('transport', 'Transport & Vehicles', 'Truck', 'Price', false),
  ('events', 'Events & Activities', 'Calendar', 'Price', false),
  ('nightlife', 'Bars & Nightclubs', 'Wine', 'Price', false),
  ('mobile', 'Mobile & Tablets', 'Smartphone', 'Price', false),
  ('laptops', 'Laptops & Computers', 'Laptop', 'Price', false),
  ('electrical', 'Electrical & Electronics', 'Zap', 'Price', false),
  ('wedding', 'Wedding & Matchmaking', 'Heart', 'Price', true);

-- Create indexes
CREATE INDEX idx_categories_name ON categories(name);
CREATE INDEX idx_categories_coming_soon ON categories(coming_soon);
CREATE INDEX idx_categories_price_label ON categories(price_label);

COMMIT;