-- Set search path to neondb
SET search_path TO neondb;

-- Start transaction
BEGIN;

-- Drop and recreate categories table to ensure clean state
DROP TABLE IF EXISTS categories CASCADE;

CREATE TABLE categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  icon text NOT NULL,
  coming_soon boolean DEFAULT false,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

-- Insert all categories including the new Wedding category
INSERT INTO categories (id, name, icon, coming_soon)
VALUES
  ('books', 'Books', 'BookOpen', false),
  ('vehicles', 'Vehicles', 'Car', false),
  ('real-estate', 'Real Estate', 'Home', false),
  ('electronics', 'Electronics', 'Smartphone', false),
  ('jobs', 'Jobs', 'Briefcase', false),
  ('furniture', 'Furniture', 'Sofa', false),
  ('fashion', 'Fashion', 'ShoppingBag', false),
  ('education', 'Education & Learning', 'GraduationCap', false),
  ('hotels', 'Hotels & Resorts', 'Hotel', false),
  ('food', 'Food & Dining', 'UtensilsCrossed', false),
  ('grocery', 'Grocery & Supermarkets', 'ShoppingCart', false),
  ('transport', 'Transport & Vehicles', 'Truck', false),
  ('events', 'Events & Activities', 'Calendar', false),
  ('nightlife', 'Bars & Nightclubs', 'Wine', false),
  ('mobile', 'Mobile & Tablets', 'Smartphone', false),
  ('laptops', 'Laptops & Computers', 'Laptop', false),
  ('electrical', 'Electrical & Electronics', 'Zap', false),
  ('wedding', 'Wedding & Matchmaking', 'Heart', true);

-- Create index on name for faster searches
CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name);

-- Create index on coming_soon for filtering
CREATE INDEX IF NOT EXISTS idx_categories_coming_soon ON categories(coming_soon);

COMMIT;