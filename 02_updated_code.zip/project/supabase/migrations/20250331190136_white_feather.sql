/*
  # Update Price Labels for Jobs and Education Categories
  
  1. Changes
    - Add price_label column to categories table
    - Set "Salary" label for jobs category
    - Set "Fees" label for education category
    
  2. Security
    - Transaction to ensure atomic updates
*/

-- Set search path
SET search_path TO neondb;

-- Start transaction
BEGIN;

-- Add price_label column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'neondb' 
    AND table_name = 'categories' 
    AND column_name = 'price_label'
  ) THEN
    ALTER TABLE neondb.categories ADD COLUMN price_label text DEFAULT 'Price';
  END IF;
END $$;

-- Update price labels for jobs and education categories
UPDATE neondb.categories
SET price_label = 
  CASE 
    WHEN id = 'jobs' THEN 'Salary'
    WHEN id = 'education' THEN 'Fees'
    ELSE 'Price'
  END;

-- Create index on price_label for faster searches
CREATE INDEX IF NOT EXISTS idx_categories_price_label ON neondb.categories(price_label);

COMMIT;