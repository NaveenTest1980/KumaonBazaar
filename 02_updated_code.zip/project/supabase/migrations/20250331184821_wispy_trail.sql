/*
  # Remove Categories Migration
  
  This migration removes the 'bikes' and 'computers' categories and updates any existing ads
  to use alternative categories.
  
  1. Changes
    - Move 'bikes' ads to 'vehicles' category
    - Move 'computers' ads to 'laptops' category
    - Remove 'bikes' and 'computers' categories
    
  2. Safety
    - Updates existing ads before removing categories
    - Uses transaction to ensure data consistency
*/

-- Set search path
SET search_path TO neondb;

-- Start transaction
BEGIN;

-- Update existing ads to new categories
UPDATE neondb.ads
SET category_id = 'vehicles'
WHERE category_id = 'bikes';

UPDATE neondb.ads
SET category_id = 'laptops'
WHERE category_id = 'computers';

-- Delete the categories
DELETE FROM neondb.categories
WHERE id IN ('bikes', 'computers');

COMMIT;