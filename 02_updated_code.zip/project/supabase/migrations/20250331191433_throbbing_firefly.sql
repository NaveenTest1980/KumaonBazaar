-- Set search path
SET search_path TO neondb;

-- Start transaction
BEGIN;

-- Insert wedding category
INSERT INTO neondb.categories (id, name, icon, price_label)
VALUES ('wedding', 'Wedding & Matchmaking', 'Heart', 'Price')
ON CONFLICT (id) DO UPDATE
SET 
  name = EXCLUDED.name,
  icon = EXCLUDED.icon,
  price_label = EXCLUDED.price_label;

-- Add coming_soon column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'neondb' 
    AND table_name = 'categories' 
    AND column_name = 'coming_soon'
  ) THEN
    ALTER TABLE neondb.categories ADD COLUMN coming_soon boolean DEFAULT false;
  END IF;
END $$;

-- Set wedding category as coming soon
UPDATE neondb.categories
SET coming_soon = true
WHERE id = 'wedding';

COMMIT;