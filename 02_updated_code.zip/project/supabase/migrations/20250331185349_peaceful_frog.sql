-- Set search path
SET search_path TO neondb;

-- Start transaction
BEGIN;

-- Recreate categories table to ensure clean state
DROP TABLE IF EXISTS neondb.categories CASCADE;

-- Create categories table
CREATE TABLE neondb.categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  icon text NOT NULL,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

-- Insert updated categories
INSERT INTO neondb.categories (id, name, icon)
VALUES
  ('books', 'Books', 'BookOpen'),
  ('vehicles', 'Vehicles', 'Car'),
  ('real-estate', 'Real Estate', 'Home'),
  ('electronics', 'Electronics', 'Smartphone'),
  ('jobs', 'Jobs', 'Briefcase'),
  ('furniture', 'Furniture', 'Sofa'),
  ('fashion', 'Fashion', 'ShoppingBag'),
  ('education', 'Education & Learning', 'GraduationCap'),
  ('hotels', 'Hotels & Resorts', 'Hotel'),
  ('food', 'Food & Dining', 'UtensilsCrossed'),
  ('grocery', 'Grocery & Supermarkets', 'ShoppingCart'),
  ('transport', 'Transport & Vehicles', 'Truck'),
  ('events', 'Events & Activities', 'Calendar'),
  ('nightlife', 'Bars & Nightclubs', 'Wine'),
  ('mobile', 'Mobile & Tablets', 'Smartphone'),
  ('laptops', 'Laptops & Computers', 'Laptop'),
  ('electrical', 'Electrical & Electronics', 'Zap');

-- Create index on name for faster searches
CREATE INDEX IF NOT EXISTS idx_categories_name ON neondb.categories(name);

COMMIT;