import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { S3Client, PutObjectCommand } from 'npm:@aws-sdk/client-s3';

// Cloudflare R2 configuration
const CLOUDFLARE_ACCOUNT_ID = '4601c91cb316c52ef7b13bf168bc19fb';
const CLOUDFLARE_BUCKET_NAME = 'checkitonce';
const CLOUDFLARE_PUBLIC_URL = `https://pub-f51dd620dd1650da3f502dcb4952d2c4.r2.dev`;

// Supported file types
const SUPPORTED_FILE_TYPES = [
  'image/jpeg',
  'image/png',
  'image/gif',
  'image/webp'
];

// Maximum file size (5MB)
const MAX_FILE_SIZE = 5 * 1024 * 1024;

// Initialize R2 client
const r2Client = new S3Client({
  region: 'auto',
  endpoint: `https://${CLOUDFLARE_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: Deno.env.get('CLOUDFLARE_ACCESS_KEY_ID') || '',
    secretAccessKey: Deno.env.get('CLOUDFLARE_SECRET_ACCESS_KEY') || ''
  }
});

serve(async (req: Request) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
      }
    });
  }

  try {
    // Verify request method
    if (req.method !== 'POST') {
      return new Response('Method not allowed', { status: 405 });
    }

    // Get the file from the request
    const formData = await req.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return new Response('No file provided', { status: 400 });
    }

    // Validate file type
    if (!SUPPORTED_FILE_TYPES.includes(file.type)) {
      return new Response(
        `Unsupported file type: ${file.type}. Supported types are: ${SUPPORTED_FILE_TYPES.join(', ')}`,
        { status: 400 }
      );
    }

    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      return new Response(
        `File size exceeds 5MB limit. Current size: ${(file.size / 1024 / 1024).toFixed(2)}MB`,
        { status: 400 }
      );
    }

    // Generate a unique ID for the file
    const fileId = crypto.randomUUID();
    const extension = file.name.split('.').pop()?.toLowerCase() || 'jpg';
    const objectKey = `${fileId}.${extension}`;

    // Convert File to ArrayBuffer
    const arrayBuffer = await file.arrayBuffer();

    // Create upload command for R2
    const command = new PutObjectCommand({
      Bucket: CLOUDFLARE_BUCKET_NAME,
      Key: objectKey,
      Body: arrayBuffer,
      ContentType: file.type,
      CacheControl: 'public, max-age=31536000', // Cache for 1 year
      Metadata: {
        'original-filename': file.name,
        'upload-date': new Date().toISOString()
      }
    });

    // Upload file to R2
    const response = await r2Client.send(command);

    // Return success response
    return new Response(
      JSON.stringify({
        success: true,
        url: `${CLOUDFLARE_PUBLIC_URL}/${objectKey}`,
        cloudflareId: objectKey,
        etag: response.ETag
      }),
      {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      }
    );
  } catch (error) {
    console.error('Error uploading file:', error);

    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'Failed to upload file'
      }),
      {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      }
    );
  }
});