/*
  # Setup RLS Policies for Users Table
  
  This migration creates the necessary RLS policies to allow:
  1. Public access for reading user profiles
  2. Authenticated users to update their own profiles
  3. Authenticated users to delete their own profiles
*/

-- Enable RLS on users table
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Create policy to allow anyone to read user profiles
CREATE POLICY "Allow public read access to user profiles"
ON public.users
FOR SELECT
TO public
USING (true);

-- Create policy to allow users to update their own profile
CREATE POLICY "Users can update own profile"
ON public.users
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Create policy to allow users to delete their own profile
CREATE POLICY "Users can delete own profile"
ON public.users
FOR DELETE
TO authenticated
USING (auth.uid() = id);

-- Create policy to allow authenticated users to insert their own profile
CREATE POLICY "Users can insert own profile"
ON public.users
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);