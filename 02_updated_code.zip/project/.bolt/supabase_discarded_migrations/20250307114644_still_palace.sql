/*
  # Add images column to ads table

  1. Changes
    - Add JSONB column 'images' to store Base64 image data
    - Set default empty array for images column
    - Drop old ad_images table since images are now stored in ads table

  2. Schema
    - images: JSONB array containing:
      - id: UUID
      - data: Base64 string
      - is_primary: boolean
      - created_at: timestamp
*/

-- Add images column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'ads' AND column_name = 'images'
  ) THEN
    ALTER TABLE ads ADD COLUMN images JSONB DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- Drop ad_images table if it exists
DROP TABLE IF EXISTS ad_images;