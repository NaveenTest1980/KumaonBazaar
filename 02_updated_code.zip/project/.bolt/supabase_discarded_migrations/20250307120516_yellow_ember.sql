-- Add images column to ads table
DO $$ 
BEGIN
  -- Check if the column exists
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'ads' 
    AND column_name = 'images'
  ) THEN
    -- Add images column as JSONB array
    ALTER TABLE ads 
    ADD COLUMN images JSONB DEFAULT '[]'::jsonb;
    
    -- Create index for better performance when querying images
    CREATE INDEX IF NOT EXISTS idx_ads_images ON ads USING gin(images);
    
    RAISE NOTICE 'Images column added successfully';
  ELSE
    RAISE NOTICE 'Images column already exists';
  END IF;
END $$;