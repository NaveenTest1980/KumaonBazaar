-- Drop schema if exists
DROP SCHEMA IF EXISTS public CASCADE;
DROP SCHEMA IF EXISTS neondb CASCADE;

-- Create schema
CREATE SCHEMA neondb;

-- Set search path
SET search_path TO neondb;

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;

-- Create function for updating timestamps
CREATE OR REPLACE FUNCTION neondb.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Users table
CREATE TABLE neondb.users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT users_email_key UNIQUE (email)
);

-- Categories table
CREATE TABLE neondb.categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  icon text NOT NULL,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

-- Ads table
CREATE TABLE neondb.ads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  price numeric NOT NULL CHECK (price >= 0),
  category_id text NOT NULL REFERENCES neondb.categories(id),
  location text NOT NULL,
  district_id text NOT NULL,
  town_id text NOT NULL,
  user_id uuid NOT NULL REFERENCES neondb.users(id),
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  expiry_date timestamptz DEFAULT (CURRENT_TIMESTAMP + INTERVAL '30 days'),
  featured boolean DEFAULT false,
  needs_moderation boolean DEFAULT false,
  phone_number text,
  phone_number_visible boolean DEFAULT true,
  phone_number_expiry_date timestamptz DEFAULT (CURRENT_TIMESTAMP + INTERVAL '15 days'),
  status text DEFAULT 'Active' CHECK (status IN ('Active', 'Pending', 'Rejected', 'Expired', 'Sold')),
  images jsonb DEFAULT '[]'::jsonb
);

-- Create trigger for ads updated_at
CREATE TRIGGER update_ads_updated_at
  BEFORE UPDATE ON neondb.ads
  FOR EACH ROW
  EXECUTE FUNCTION neondb.update_updated_at_column();

-- Create indexes
CREATE INDEX idx_ads_category_id ON neondb.ads(category_id);
CREATE INDEX idx_ads_user_id ON neondb.ads(user_id);
CREATE INDEX idx_ads_created_at ON neondb.ads(created_at);
CREATE INDEX idx_ads_status ON neondb.ads(status);
CREATE INDEX idx_ads_featured ON neondb.ads(featured);
CREATE INDEX idx_ads_needs_moderation ON neondb.ads(needs_moderation);
CREATE INDEX idx_ads_expiry_date ON neondb.ads(expiry_date);
CREATE INDEX idx_ads_district_id ON neondb.ads(district_id);