-- Connect directly to neondb database and schema
\c neondb;
SET search_path TO neondb;

-- Ensure we're in the correct schema
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = 'neondb') THEN
    CREATE SCHEMA neondb;
  END IF;
END $$;

-- Ensure categories table exists with correct structure
CREATE TABLE IF NOT EXISTS neondb.categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  icon text NOT NULL,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

-- Update all categories (both existing and new)
INSERT INTO neondb.categories (id, name, icon)
VALUES
  -- Existing categories
  ('books', 'Books', 'BookOpen'),
  ('vehicles', 'Vehicles', 'Car'),
  ('real-estate', 'Real Estate', 'Home'),
  ('electronics', 'Electronics', 'Smartphone'),
  ('jobs', 'Jobs', 'Briefcase'),
  ('furniture', 'Furniture', 'Sofa'),
  ('bikes', 'Bikes', 'Bike'),
  ('fashion', 'Fashion', 'ShoppingBag'),
  ('computers', 'Computers', 'Cpu'),
  -- New categories
  ('education', 'Education & Learning', 'GraduationCap'),
  ('hotels', 'Hotels & Resorts', 'Hotel'),
  ('food', 'Food & Dining', 'UtensilsCrossed'),
  ('grocery', 'Grocery & Supermarkets', 'ShoppingCart'),
  ('transport', 'Transport & Vehicles', 'Truck'),
  ('events', 'Events & Activities', 'Calendar'),
  ('nightlife', 'Bars & Nightclubs', 'Wine')
ON CONFLICT (id) DO UPDATE
SET 
  name = EXCLUDED.name,
  icon = EXCLUDED.icon;

-- Verify the update
DO $$
DECLARE
  category_count integer;
  categories_json jsonb;
BEGIN
  -- Get count
  SELECT COUNT(*) INTO category_count FROM neondb.categories;
  
  -- Get all categories as JSON for verification
  SELECT jsonb_agg(row_to_json(c)) INTO categories_json
  FROM (
    SELECT id, name, icon 
    FROM neondb.categories 
    ORDER BY name
  ) c;
  
  -- Log results
  RAISE NOTICE 'Total categories after update: %', category_count;
  RAISE NOTICE 'Categories: %', categories_json;
END $$;