-- Drop existing tables if they exist
DROP TABLE IF EXISTS neondb.ad_images CASCADE;
DROP TABLE IF EXISTS neondb.ads CASCADE;
DROP TABLE IF EXISTS neondb.categories CASCADE;
DROP TABLE IF EXISTS neondb.users CASCADE;

-- Create tables with proper image handling
CREATE TABLE IF NOT EXISTS neondb.users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT users_email_key UNIQUE (email)
);

CREATE TABLE IF NOT EXISTS neondb.categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  icon text NOT NULL,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS neondb.ads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  price numeric NOT NULL CHECK (price >= 0),
  category_id text NOT NULL,
  location text NOT NULL,
  district_id text NOT NULL,
  town_id text NOT NULL,
  user_id uuid NOT NULL,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  expiry_date timestamptz DEFAULT (CURRENT_TIMESTAMP + INTERVAL '30 days'),
  featured boolean DEFAULT false,
  needs_moderation boolean DEFAULT false,
  phone_number text,
  phone_number_visible boolean DEFAULT true,
  phone_number_expiry_date timestamptz DEFAULT (CURRENT_TIMESTAMP + INTERVAL '15 days'),
  status text DEFAULT 'Active' CHECK (status IN ('Active', 'Pending', 'Rejected', 'Expired', 'Sold')),
  images jsonb DEFAULT '[]'::jsonb NOT NULL,
  CONSTRAINT ads_category_id_fkey FOREIGN KEY (category_id) REFERENCES neondb.categories(id),
  CONSTRAINT ads_user_id_fkey FOREIGN KEY (user_id) REFERENCES neondb.users(id)
);

-- Create indexes
CREATE INDEX idx_ads_category_id ON neondb.ads(category_id);
CREATE INDEX idx_ads_user_id ON neondb.ads(user_id);
CREATE INDEX idx_ads_created_at ON neondb.ads(created_at);
CREATE INDEX idx_ads_status ON neondb.ads(status);
CREATE INDEX idx_ads_featured ON neondb.ads(featured);
CREATE INDEX idx_ads_needs_moderation ON neondb.ads(needs_moderation);
CREATE INDEX idx_ads_expiry_date ON neondb.ads(expiry_date);
CREATE INDEX idx_ads_district_id ON neondb.ads(district_id);

-- Insert default categories
INSERT INTO neondb.categories (id, name, icon)
VALUES
  ('books', 'Books', 'BookOpen'),
  ('vehicles', 'Vehicles', 'Car'),
  ('real-estate', 'Real Estate', 'Home'),
  ('electronics', 'Electronics', 'Smartphone'),
  ('jobs', 'Jobs', 'Briefcase'),
  ('furniture', 'Furniture', 'Sofa'),
  ('bikes', 'Bikes', 'Bike'),
  ('fashion', 'Fashion', 'ShoppingBag'),
  ('computers', 'Computers', 'Cpu')
ON CONFLICT (id) DO NOTHING;