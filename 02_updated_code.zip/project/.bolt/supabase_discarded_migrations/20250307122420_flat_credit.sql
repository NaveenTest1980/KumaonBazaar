/*
  # Clean all tables except categories

  1. Changes
    - Removes all data from:
      - ads
      - ad_images
      - users
      - favorites
      - payments
      - books
      - book_images
    - Preserves all data in categories table
    - Preserves table structures and relationships
    - Maintains RLS policies and indexes

  2. Security
    - No changes to RLS policies
    - Maintains all existing security settings

  3. Notes
    - Uses safe DELETE operations instead of TRUNCATE
    - Preserves referential integrity
    - Executed in correct order to handle foreign key constraints
*/

-- Start a transaction block
DO $$ 
BEGIN
  -- Delete data from tables in correct order to handle foreign key constraints
  DELETE FROM book_images;
  DELETE FROM books;
  DELETE FROM ad_images;
  DELETE FROM favorites;
  DELETE FROM payments;
  DELETE FROM ads;
  DELETE FROM users;

  -- Reset sequences if any exist
  -- This is safe even if sequences don't exist
  PERFORM setval(pg_get_serial_sequence('books', 'id'), 1, false) WHERE EXISTS (SELECT 1 FROM pg_sequences WHERE sequencename = 'books_id_seq');
  PERFORM setval(pg_get_serial_sequence('ads', 'id'), 1, false) WHERE EXISTS (SELECT 1 FROM pg_sequences WHERE sequencename = 'ads_id_seq');
  PERFORM setval(pg_get_serial_sequence('users', 'id'), 1, false) WHERE EXISTS (SELECT 1 FROM pg_sequences WHERE sequencename = 'users_id_seq');

  -- Log the cleanup
  RAISE NOTICE 'All tables except categories have been cleaned';
END $$;