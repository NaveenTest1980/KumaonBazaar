/*
  # Create Database Schema
  
  This migration creates the schema and tables for the marketplace.
  
  1. Tables
    - users
    - categories 
    - ads
    - ad_images
    - favorites
    - payments
    
  2. Indexes
    - Performance indexes for all tables
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE public.users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

-- Categories table
CREATE TABLE public.categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  icon text NOT NULL,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

-- Ads table
CREATE TABLE public.ads (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  description text NOT NULL,
  price numeric NOT NULL CHECK (price >= 0),
  category_id text NOT NULL REFERENCES categories(id),
  location text NOT NULL,
  district_id text NOT NULL,
  town_id text NOT NULL,
  user_id uuid NOT NULL REFERENCES users(id),
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  expiry_date timestamptz DEFAULT (CURRENT_TIMESTAMP + INTERVAL '30 days'),
  featured boolean DEFAULT false,
  needs_moderation boolean DEFAULT false,
  phone_number text,
  phone_number_visible boolean DEFAULT true,
  phone_number_expiry_date timestamptz DEFAULT (CURRENT_TIMESTAMP + INTERVAL '15 days'),
  status text DEFAULT 'Active' CHECK (status IN ('Active', 'Pending', 'Rejected', 'Expired', 'Sold'))
);

-- Ad images table
CREATE TABLE public.ad_images (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  ad_id uuid NOT NULL REFERENCES ads(id) ON DELETE CASCADE,
  url text NOT NULL,
  cloudflare_id text NOT NULL,
  is_primary boolean DEFAULT false,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

-- Favorites table
CREATE TABLE public.favorites (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  ad_id uuid NOT NULL REFERENCES ads(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, ad_id)
);

-- Payments table
CREATE TABLE public.payments (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES users(id),
  ad_id uuid NOT NULL REFERENCES ads(id),
  amount numeric NOT NULL CHECK (amount > 0),
  payment_method text NOT NULL,
  payment_id text,
  status text NOT NULL CHECK (status IN ('pending', 'completed', 'failed')),
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX idx_ads_category_id ON ads(category_id);
CREATE INDEX idx_ads_user_id ON ads(user_id);
CREATE INDEX idx_ads_created_at ON ads(created_at);
CREATE INDEX idx_ads_status ON ads(status);
CREATE INDEX idx_ads_featured ON ads(featured);
CREATE INDEX idx_ads_needs_moderation ON ads(needs_moderation);
CREATE INDEX idx_ads_expiry_date ON ads(expiry_date);
CREATE INDEX idx_ads_district_id ON ads(district_id);

CREATE INDEX idx_ad_images_ad_id ON ad_images(ad_id);
CREATE INDEX idx_ad_images_is_primary ON ad_images(is_primary);
CREATE INDEX idx_ad_images_cloudflare_id ON ad_images(cloudflare_id);

CREATE INDEX idx_favorites_user_id ON favorites(user_id);
CREATE INDEX idx_favorites_ad_id ON favorites(ad_id);

CREATE INDEX idx_payments_user_id ON payments(user_id);
CREATE INDEX idx_payments_ad_id ON payments(ad_id);
CREATE INDEX idx_payments_status ON payments(status);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE ads ENABLE ROW LEVEL SECURITY;
ALTER TABLE ad_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can read own data" ON users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own data" ON users
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Anyone can read active ads" ON ads
  FOR SELECT USING (status = 'Active' AND NOT needs_moderation);

CREATE POLICY "Users can create ads" ON ads
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own ads" ON ads
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own ads" ON ads
  FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "Anyone can view ad images" ON ad_images
  FOR SELECT USING (true);

CREATE POLICY "Users can manage own ad images" ON ad_images
  FOR ALL USING (EXISTS (
    SELECT 1 FROM ads WHERE ads.id = ad_images.ad_id AND ads.user_id = auth.uid()
  ));

CREATE POLICY "Users can manage own favorites" ON favorites
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can view own payments" ON payments
  FOR SELECT USING (auth.uid() = user_id);