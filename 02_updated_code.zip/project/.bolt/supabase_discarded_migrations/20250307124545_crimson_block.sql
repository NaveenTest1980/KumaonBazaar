/*
  # Clean Database Tables

  1. Changes
    - Removes all data from:
      - ads
      - ad_images
      - users
      - favorites
      - payments
      - books
      - book_images
    - Preserves all data in categories table
    - Maintains table structures and relationships

  2. Security
    - No changes to RLS policies
    - Maintains all existing security settings

  3. Notes
    - Uses TRUNCATE with CASCADE to handle foreign key relationships
    - Preserves table structures and indexes
    - Resets all sequences
*/

-- Disable triggers temporarily to avoid any trigger-related issues
SET session_replication_role = 'replica';

-- Truncate all tables except categories in correct order
TRUNCATE TABLE book_images CASCADE;
TRUNCATE TABLE books CASCADE;
TRUNCATE TABLE ad_images CASCADE;
TRUNCATE TABLE favorites CASCADE;
TRUNCATE TABLE payments CASCADE;
TRUNCATE TABLE ads CASCADE;
TRUNCATE TABLE users CASCADE;

-- Re-enable triggers
SET session_replication_role = 'origin';

-- Reset all sequences
ALTER SEQUENCE IF EXISTS book_images_id_seq RESTART;
ALTER SEQUENCE IF EXISTS books_id_seq RESTART;
ALTER SEQUENCE IF EXISTS ad_images_id_seq RESTART;
ALTER SEQUENCE IF EXISTS favorites_id_seq RESTART;
ALTER SEQUENCE IF EXISTS payments_id_seq RESTART;
ALTER SEQUENCE IF EXISTS ads_id_seq RESTART;
ALTER SEQUENCE IF EXISTS users_id_seq RESTART;

-- Verify tables are empty except categories
DO $$
BEGIN
  ASSERT (SELECT COUNT(*) FROM book_images) = 0, 'book_images table is not empty';
  ASSERT (SELECT COUNT(*) FROM books) = 0, 'books table is not empty';
  ASSERT (SELECT COUNT(*) FROM ad_images) = 0, 'ad_images table is not empty';
  ASSERT (SELECT COUNT(*) FROM favorites) = 0, 'favorites table is not empty';
  ASSERT (SELECT COUNT(*) FROM payments) = 0, 'payments table is not empty';
  ASSERT (SELECT COUNT(*) FROM ads) = 0, 'ads table is not empty';
  ASSERT (SELECT COUNT(*) FROM users) = 0, 'users table is not empty';
  
  -- Log success
  RAISE NOTICE 'All tables except categories have been cleaned successfully';
END $$;