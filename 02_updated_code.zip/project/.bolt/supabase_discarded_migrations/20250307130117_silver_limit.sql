/*
  # Clean All Data Except Categories

  1. Changes
    - Removes all data from:
      - ads
      - ad_images
      - users
      - favorites
      - payments
      - books
      - book_images
    - Preserves categories table and data
    - Resets all sequences

  2. Security
    - Maintains existing RLS policies
    - No changes to security settings

  3. Notes
    - Uses TRUNCATE CASCADE for efficient deletion
    - Preserves table structures and constraints
*/

-- Disable RLS temporarily
ALTER TABLE ads DISABLE ROW LEVEL SECURITY;
ALTER TABLE users DISABLE ROW LEVEL SECURITY;
ALTER TABLE favorites DISABLE ROW LEVEL SECURITY;
ALTER TABLE books DISABLE ROW LEVEL SECURITY;

-- Clean all tables except categories
TRUNCATE TABLE book_images CASCADE;
TRUNCATE TABLE books CASCADE;
TRUNCATE TABLE ad_images CASCADE;
TRUNCATE TABLE favorites CASCADE;
TRUNCATE TABLE payments CASCADE;
TRUNCATE TABLE ads CASCADE;
TRUNCATE TABLE users CASCADE;

-- Re-enable RLS
ALTER TABLE ads ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE books ENABLE ROW LEVEL SECURITY;

-- Verify tables are empty
DO $$
BEGIN
  ASSERT (SELECT COUNT(*) FROM ads) = 0, 'ads table is not empty';
  ASSERT (SELECT COUNT(*) FROM users) = 0, 'users table is not empty';
  ASSERT (SELECT COUNT(*) FROM favorites) = 0, 'favorites table is not empty';
  ASSERT (SELECT COUNT(*) FROM books) = 0, 'books table is not empty';
  ASSERT (SELECT COUNT(*) FROM book_images) = 0, 'book_images table is not empty';
  ASSERT (SELECT COUNT(*) FROM ad_images) = 0, 'ad_images table is not empty';
  ASSERT (SELECT COUNT(*) FROM payments) = 0, 'payments table is not empty';
  
  RAISE NOTICE 'All tables except categories have been cleaned successfully';
END $$;