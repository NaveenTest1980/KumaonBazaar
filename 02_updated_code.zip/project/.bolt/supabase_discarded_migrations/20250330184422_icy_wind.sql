-- Insert default categories
INSERT INTO public.categories (id, name, icon)
VALUES
  ('books', 'Books', 'BookOpen'),
  ('vehicles', 'Vehicles', 'Car'),
  ('real-estate', 'Real Estate', 'Home'),
  ('electronics', 'Electronics', 'Smartphone'),
  ('jobs', 'Jobs', 'Briefcase'),
  ('furniture', 'Furniture', 'Sofa'),
  ('bikes', 'Bikes', 'Bike'),
  ('fashion', 'Fashion', 'ShoppingBag'),
  ('computers', 'Computers', 'Cpu')
ON CONFLICT (id) DO NOTHING;