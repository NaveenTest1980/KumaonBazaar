-- Create neondb schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS neondb;

-- Drop existing tables if they exist in neondb schema
DROP TABLE IF EXISTS neondb.payments CASCADE;
DROP TABLE IF EXISTS neondb.favorites CASCADE;
DROP TABLE IF EXISTS neondb.ad_images CASCADE;
DROP TABLE IF EXISTS neondb.ads CASCADE;
DROP TABLE IF EXISTS neondb.categories CASCADE;
DROP TABLE IF EXISTS neondb.users CASCADE;

-- Create users table in neondb schema
CREATE TABLE neondb.users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT users_email_key UNIQUE (email)
);

-- Enable RLS
ALTER TABLE neondb.users ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own profile"
ON neondb.users
FOR SELECT
TO authenticated
USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
ON neondb.users
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_users_email ON neondb.users(email);

-- Add trigger for updated_at
CREATE OR REPLACE FUNCTION neondb.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER users_handle_updated_at
  BEFORE UPDATE ON neondb.users
  FOR EACH ROW
  EXECUTE FUNCTION neondb.handle_updated_at();