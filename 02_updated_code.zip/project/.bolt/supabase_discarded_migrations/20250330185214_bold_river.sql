-- Drop schema if exists
DROP SCHEMA IF EXISTS public CASCADE;

-- Create schema
CREATE SCHEMA public;

-- Set search path
SET search_path TO public;

-- Enable UUID extension in public schema
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create function for updating timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language plpgsql;

-- Users table
CREATE TABLE public.users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Categories table
CREATE TABLE public.categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  icon text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Ads table
CREATE TABLE public.ads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  price numeric NOT NULL CHECK (price >= 0),
  category_id text NOT NULL REFERENCES public.categories(id),
  location text NOT NULL,
  district_id text NOT NULL,
  town_id text NOT NULL,
  user_id uuid NOT NULL REFERENCES public.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  expiry_date timestamptz DEFAULT (now() + INTERVAL '30 days'),
  featured boolean DEFAULT false,
  needs_moderation boolean DEFAULT false,
  phone_number text,
  phone_number_visible boolean DEFAULT true,
  phone_number_expiry_date timestamptz DEFAULT (now() + INTERVAL '15 days'),
  status text DEFAULT 'Active' CHECK (status IN ('Active', 'Pending', 'Rejected', 'Expired', 'Sold'))
);

-- Create trigger for ads updated_at
CREATE TRIGGER update_ads_updated_at
  BEFORE UPDATE ON public.ads
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Ad images table
CREATE TABLE public.ad_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ad_id uuid NOT NULL REFERENCES public.ads(id) ON DELETE CASCADE,
  url text NOT NULL,
  cloudflare_id text NOT NULL,
  is_primary boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Favorites table
CREATE TABLE public.favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  ad_id uuid NOT NULL REFERENCES public.ads(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, ad_id)
);

-- Payments table
CREATE TABLE public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id),
  ad_id uuid NOT NULL REFERENCES public.ads(id),
  amount numeric NOT NULL CHECK (amount > 0),
  payment_method text NOT NULL,
  payment_id text,
  status text NOT NULL CHECK (status IN ('pending', 'completed', 'failed')),
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_ads_category_id ON public.ads(category_id);
CREATE INDEX idx_ads_user_id ON public.ads(user_id);
CREATE INDEX idx_ads_created_at ON public.ads(created_at);
CREATE INDEX idx_ads_status ON public.ads(status);
CREATE INDEX idx_ads_featured ON public.ads(featured);
CREATE INDEX idx_ads_needs_moderation ON public.ads(needs_moderation);
CREATE INDEX idx_ads_expiry_date ON public.ads(expiry_date);
CREATE INDEX idx_ads_district_id ON public.ads(district_id);

CREATE INDEX idx_ad_images_ad_id ON public.ad_images(ad_id);
CREATE INDEX idx_ad_images_is_primary ON public.ad_images(is_primary);
CREATE INDEX idx_ad_images_cloudflare_id ON public.ad_images(cloudflare_id);

CREATE INDEX idx_favorites_user_id ON public.favorites(user_id);
CREATE INDEX idx_favorites_ad_id ON public.favorites(ad_id);

CREATE INDEX idx_payments_user_id ON public.payments(user_id);
CREATE INDEX idx_payments_ad_id ON public.payments(ad_id);
CREATE INDEX idx_payments_status ON public.payments(status);

-- Enable RLS
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ad_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can read own data" ON public.users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own data" ON public.users
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Anyone can read active ads" ON public.ads
  FOR SELECT USING (status = 'Active' AND NOT needs_moderation);

CREATE POLICY "Users can create ads" ON public.ads
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own ads" ON public.ads
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own ads" ON public.ads
  FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "Anyone can view ad images" ON public.ad_images
  FOR SELECT USING (true);

CREATE POLICY "Users can manage own ad images" ON public.ad_images
  FOR ALL USING (EXISTS (
    SELECT 1 FROM public.ads WHERE ads.id = ad_images.ad_id AND ads.user_id = auth.uid()
  ));

CREATE POLICY "Users can manage own favorites" ON public.favorites
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can view own payments" ON public.payments
  FOR SELECT USING (auth.uid() = user_id);