import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import './index.css';
import { initializeDatabase } from './db/neon';

// Initialize database before rendering
initializeDatabase().then(() => {
  // Create root element if it doesn't exist
  let rootElement = document.getElementById('root');
  if (!rootElement) {
    rootElement = document.createElement('div');
    rootElement.id = 'root';
    document.body.appendChild(rootElement);
  }

  // Render the application
  createRoot(rootElement).render(
    <StrictMode>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </StrictMode>
  );
}).catch(error => {
  console.error('Failed to initialize database:', error);
  // Show error to user
  document.body.innerHTML = `
    <div style="color: red; padding: 20px;">
      Failed to initialize database. Please try again later.
      <br>
      Error: ${error.message}
    </div>
  `;
});