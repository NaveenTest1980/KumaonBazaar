import React, { useState, useCallback, useEffect } from 'react';
import { useParams, Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { AlertCircle, Phone, Mail, ArrowLeft } from 'lucide-react';
import { getAdById } from '../services/adService';
import { sql } from '../db/neon';
import AdCard from '../components/AdCard';

const DEFAULT_IMAGE_URL = 'https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';

const AdDetails = () => {
  const { adId } = useParams<{ adId: string }>();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  const [ad, setAd] = useState<Ad | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [similarAds, setSimilarAds] = useState<Ad[]>([]);
  const [showPhoneNumber, setShowPhoneNumber] = useState(false);
  const [showSecurityAlert, setShowSecurityAlert] = useState(false);
  
  const referrer = location.state?.from || '/';
  const referrerLabel = location.state?.label || 'Back';

  useEffect(() => {
    const fetchAd = async () => {
      try {
        if (!adId) return;
        
        const adData = await getAdById(adId);
        
        if (adData) {
          // Ensure ad has at least one image
          if (!adData.images || adData.images.length === 0) {
            adData.images = [{
              id: 'default',
              url: DEFAULT_IMAGE_URL,
              is_primary: true,
              created_at: adData.created_at
            }];
          }
          
          setAd(adData);
          
          // Get similar ads
          const similar = await sql`
            SELECT a.*, 
                   COALESCE(jsonb_agg(
                     jsonb_build_object(
                       'id', ai.id,
                       'url', ai.url,
                       'is_primary', ai.is_primary
                     ) ORDER BY ai.is_primary DESC, ai.created_at ASC
                   ) FILTER (WHERE ai.id IS NOT NULL), '[]') as images
            FROM ads a
            LEFT JOIN ad_images ai ON a.id = ai.ad_id
            WHERE a.category_id = ${adData.category_id}
            AND a.id != ${adId}
            AND a.status = 'Active'
            GROUP BY a.id
            ORDER BY a.created_at DESC
            LIMIT 4
          `;

          // Ensure each similar ad has at least one image
          const similarAdsWithImages = similar.map(ad => ({
            ...ad,
            images: ad.images && ad.images.length > 0 ? ad.images : [{
              id: 'default',
              url: DEFAULT_IMAGE_URL,
              is_primary: true,
              created_at: ad.created_at
            }]
          }));

          setSimilarAds(similarAdsWithImages);
        } else {
          setError('Ad not found');
        }
      } catch (err) {
        console.error('Error fetching ad:', err);
        setError('Failed to load ad details');
      } finally {
        setLoading(false);
      }
    };

    fetchAd();
  }, [adId]);

  const handleShowPhoneNumber = useCallback(() => {
    setShowSecurityAlert(true);
  }, []);

  const handleSecurityAlertConfirm = useCallback(() => {
    setShowSecurityAlert(false);
    setShowPhoneNumber(true);
  }, []);

  const handleGoBack = useCallback(() => {
    navigate(referrer);
  }, [navigate, referrer]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  if (error || !ad) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error || 'Ad not found'}
        </div>
        <div className="mt-4 text-center">
          <Link to="/" className="text-orange-500 hover:underline">
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  const formattedDate = new Date(ad.created_at).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Back Button */}
      <button 
        onClick={handleGoBack}
        className="flex items-center text-gray-600 hover:text-orange-500 mb-4 transition-colors"
      >
        <ArrowLeft className="h-5 w-5 mr-1" />
        <span>{referrerLabel}</span>
      </button>

      {/* Security Alert Modal */}
      {showSecurityAlert && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg max-w-md w-full mx-4 transform transition-all animate-fade-in">
            <div className="p-6">
              <div className="flex items-start">
                <div className="flex-shrink-0 bg-yellow-100 rounded-full p-2">
                  <AlertCircle className="w-6 h-6 text-yellow-600" />
                </div>
                <div className="ml-3">
                  <h3 className="text-lg font-semibold text-gray-900">Security Alert</h3>
                  <div className="mt-2 text-sm text-gray-600">
                    <p className="font-medium mb-2">Before contacting any buyer or seller for a deal:</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>Do not share your account number, card number, CVV, or any personal financial details.</li>
                      <li>Do not accept or make payments without physically meeting the buyer or seller in person.</li>
                      <li>Always verify the identity and authenticity of the other party before proceeding.</li>
                    </ul>
                    <p className="mt-3 font-medium text-yellow-600">Stay safe and protect your information!</p>
                  </div>
                </div>
              </div>
              <div className="mt-6 flex justify-end">
                <button
                  onClick={handleSecurityAlertConfirm}
                  className="px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600 transition-colors"
                >
                  I Understand
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="md:flex">
          {/* Image Gallery */}
          <div className="md:w-1/2 relative">
            <div className="relative h-80 md:h-full bg-gray-200">
              <img
                src={ad.images[currentImageIndex]?.url || DEFAULT_IMAGE_URL}
                alt={ad.title}
                className="w-full h-full object-contain"
                loading="lazy"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = DEFAULT_IMAGE_URL;
                }}
              />
            </div>
          </div>

          <div className="md:w-1/2 p-6">
            <div className="flex justify-between items-start mb-4">
              <Link 
                to={`/category/${ad.category_id}`}
                state={{ from: `/ad/${ad.id}`, label: 'Back to Ad' }}
                className="inline-block bg-orange-100 text-orange-800 text-xs px-2 py-1 rounded-full hover:bg-orange-200 transition-colors"
              >
                {ad.category_id}
              </Link>
            </div>
            
            <h1 className="text-2xl font-bold text-gray-800 mb-2">{ad.title}</h1>
            
            <p className="text-3xl font-bold text-orange-600 mb-4">
              ₹{ad.price.toLocaleString('en-IN')}
            </p>
            
            <div className="border-t border-gray-200 pt-6 mb-6">
              <h2 className="text-lg font-semibold mb-3">Description</h2>
              <p className="text-gray-700 whitespace-pre-line">{ad.description}</p>
            </div>

            {/* Phone Number Section */}
            {ad.phone_number && (
              <div className="mb-4">
                {showPhoneNumber ? (
                  <div className="flex flex-col space-y-4">
                    <div className="flex items-center p-3 bg-green-50 rounded-lg border border-green-200">
                      <Phone size={18} className="mr-2 text-green-600" />
                      <a 
                        href={`tel:${ad.phone_number}`}
                        className="text-green-700 font-medium"
                      >
                        {ad.phone_number}
                      </a>
                    </div>
                    <div className="p-4 bg-yellow-50 border-l-4 border-yellow-400 rounded">
                      <div className="flex">
                        <AlertCircle className="h-5 w-5 text-yellow-400 mr-2" />
                        <div className="text-sm text-yellow-700">
                          <p className="font-medium mb-1">Security Alert:</p>
                          <ul className="list-disc list-inside space-y-1">
                            <li>Do not share your account number, card number, CVV, or any personal financial details.</li>
                            <li>Do not accept or make payments without physically meeting the buyer or seller in person.</li>
                            <li>Always verify the identity and authenticity of the other party before proceeding.</li>
                          </ul>
                          <p className="mt-2 font-medium">Stay safe and protect your information!</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={handleShowPhoneNumber}
                    className="w-full bg-orange-500 text-white py-2 rounded-lg font-medium hover:bg-orange-600 transition flex items-center justify-center"
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    Show Phone Number
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Similar Ads Section */}
      {similarAds.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Similar Ads</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {similarAds.map(similarAd => (
              <Link 
                key={similarAd.id}
                to={`/ad/${similarAd.id}`}
                state={{ from: `/ad/${adId}`, label: 'Back to Original Ad' }}
              >
                <AdCard 
                  id={similarAd.id}
                  title={similarAd.title}
                  price={similarAd.price}
                  location={similarAd.location}
                  imageUrl={similarAd.images[0]?.url || DEFAULT_IMAGE_URL}
                  category={similarAd.category_id}
                  createdAt={similarAd.created_at}
                />
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AdDetails;