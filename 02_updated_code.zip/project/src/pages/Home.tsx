import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import CategoryList from '../components/CategoryList';
import RecentAds from '../components/RecentAds';
import { MapPin, Building2, Users } from 'lucide-react';
import { kumaonDistricts } from '../data/locations';

const Home = () => {
  const { currentUser } = useAuth();

  return (
    <>
      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-indigo-600 to-violet-600 rounded-xl p-8 mb-12 text-white shadow-xl">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              Welcome to Kumaon's Premier Marketplace
            </h1>
            <p className="text-lg mb-6 text-indigo-100">
              Buy, sell, and exchange goods locally in the beautiful Kumaon region of Uttarakhand
            </p>
            <Link
              to="/post-ad"
              className="inline-flex items-center px-6 py-3 rounded-lg font-semibold bg-white text-indigo-600 hover:bg-indigo-50 transition-colors shadow-md hover:shadow-lg"
            >
              Post an Ad
            </Link>
          </div>
        </section>

        {/* Categories Section */}
        <section className="mb-12">
          <div className="bg-gradient-to-br from-slate-100 to-gray-100 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-200/50 p-8 pattern-dots">
            <h2 className="text-2xl font-bold mb-8 text-center bg-gradient-to-r from-indigo-600 to-violet-600 text-transparent bg-clip-text">
              Browse Categories
            </h2>
            <CategoryList />
          </div>
        </section>

        {/* Recent Ads Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-8 text-center bg-gradient-to-r from-indigo-600 to-violet-600 text-transparent bg-clip-text">
            Recent Ads
          </h2>
          <div className="bg-gradient-to-br from-slate-100 to-gray-100 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-gray-200/50">
            <RecentAds />
          </div>
        </section>

        {/* Districts Section */}
        <section className="mt-12">
          <h2 className="text-2xl font-bold mb-8 text-center bg-gradient-to-r from-indigo-600 to-violet-600 text-transparent bg-clip-text">
            Browse by District
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
            {kumaonDistricts.map((district) => (
              <Link
                key={district.id}
                to={`/?district=${district.id}`}
                className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-all duration-500"
              >
                {/* Background Image */}
                <div 
                  className="absolute inset-0 bg-cover bg-center transform transition-transform duration-500 group-hover:scale-110"
                  style={{
                    backgroundImage: `url(https://images.unsplash.com/photo-${district.id === 'nainital' 
                      ? '1580974928064-f0aeef70895a' 
                      : district.id === 'almora'
                      ? '1622185135505-2d795003994a'
                      : district.id === 'pithoragarh'
                      ? '1582719508461-905c673771fd'
                      : district.id === 'bageshwar'
                      ? '1607082349566-187342175e2f'
                      : district.id === 'champawat'
                      ? '1580974928064-f0aeef70895a'
                      : '1622185135505-2d795003994a'
                    }?auto=format&fit=crop&w=800&q=80)`
                  }}
                />
                
                {/* Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/80 to-violet-600/80 transition-opacity duration-500 group-hover:opacity-90" />
                
                {/* Content */}
                <div className="relative p-6 flex flex-col h-full min-h-[200px] justify-between text-white">
                  <div>
                    <div className="flex items-center mb-2">
                      <MapPin className="h-5 w-5 mr-2" />
                      <h3 className="text-xl font-bold">{district.name}</h3>
                    </div>
                    <div className="flex items-center text-sm text-indigo-100">
                      <Building2 className="h-4 w-4 mr-1" />
                      <span>{district.towns.length} towns</span>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <div className="flex items-center text-sm bg-white/20 rounded-lg p-2 backdrop-blur-sm">
                      <Users className="h-4 w-4 mr-1" />
                      <span>{Math.floor(Math.random() * 1000) + 500} active users</span>
                    </div>
                  </div>
                  
                  {/* Hover Effect */}
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-white transform scale-x-0 transition-transform duration-500 group-hover:scale-x-100" />
                </div>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;