import React, { memo } from 'react';
import { Link } from 'react-router-dom';
import { 
  BookOpen,
  Car, 
  Home, 
  Smartphone,
  Briefcase,
  Sofa,
  ShoppingBag,
  GraduationCap,
  Hotel,
  UtensilsCrossed,
  ShoppingCart,
  Truck,
  Calendar,
  Wine,
  Laptop,
  Zap,
  ExternalLink,
  Lock
} from 'lucide-react';

// Custom Heart icon with fill
const HeartIcon = ({ size = 24, className = "" }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="currentColor"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
  </svg>
);

interface Category {
  id: string;
  name: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  comingSoon?: boolean;
  externalUrl?: string;
}

const categories: Category[] = [
  { id: 'books', name: 'Books', icon: BookOpen, color: 'from-emerald-500 to-teal-500', bgColor: 'bg-gradient-to-br from-emerald-50 to-teal-50' },
  { id: 'vehicles', name: 'Vehicles', icon: Car, color: 'from-blue-500 to-indigo-500', bgColor: 'bg-gradient-to-br from-blue-50 to-indigo-50' },
  { id: 'real-estate', name: 'Real Estate', icon: Home, color: 'from-purple-500 to-violet-500', bgColor: 'bg-gradient-to-br from-purple-50 to-violet-50' },
  { id: 'electronics', name: 'Electronics', icon: Smartphone, color: 'from-pink-500 to-rose-500', bgColor: 'bg-gradient-to-br from-pink-50 to-rose-50' },
  { 
    id: 'jobs', 
    name: 'Jobs', 
    icon: Briefcase, 
    color: 'from-amber-500 to-orange-500', 
    bgColor: 'bg-gradient-to-br from-amber-50 to-orange-50',
    comingSoon: true,
    externalUrl: 'https://kumaonjobs.com'
  },
  { id: 'furniture', name: 'Furniture', icon: Sofa, color: 'from-lime-500 to-green-500', bgColor: 'bg-gradient-to-br from-lime-50 to-green-50' },
  { id: 'fashion', name: 'Fashion', icon: ShoppingBag, color: 'from-fuchsia-500 to-pink-500', bgColor: 'bg-gradient-to-br from-fuchsia-50 to-pink-50' },
  { id: 'education', name: 'Education & Learning', icon: GraduationCap, color: 'from-cyan-500 to-sky-500', bgColor: 'bg-gradient-to-br from-cyan-50 to-sky-50' },
  { id: 'hotels', name: 'Hotels & Resorts', icon: Hotel, color: 'from-violet-500 to-purple-500', bgColor: 'bg-gradient-to-br from-violet-50 to-purple-50' },
  { id: 'food', name: 'Food & Dining', icon: UtensilsCrossed, color: 'from-rose-500 to-red-500', bgColor: 'bg-gradient-to-br from-rose-50 to-red-50' },
  { id: 'grocery', name: 'Grocery & Supermarkets', icon: ShoppingCart, color: 'from-teal-500 to-emerald-500', bgColor: 'bg-gradient-to-br from-teal-50 to-emerald-50' },
  { id: 'transport', name: 'Transport & Vehicles', icon: Truck, color: 'from-indigo-500 to-blue-500', bgColor: 'bg-gradient-to-br from-indigo-50 to-blue-50' },
  { id: 'events', name: 'Events & Activities', icon: Calendar, color: 'from-sky-500 to-cyan-500', bgColor: 'bg-gradient-to-br from-sky-50 to-cyan-50' },
  { id: 'nightlife', name: 'Bars & Nightclubs', icon: Wine, color: 'from-red-500 to-rose-500', bgColor: 'bg-gradient-to-br from-red-50 to-rose-50' },
  { id: 'mobile', name: 'Mobile & Tablets', icon: Smartphone, color: 'from-green-500 to-lime-500', bgColor: 'bg-gradient-to-br from-green-50 to-lime-50' },
  { id: 'laptops', name: 'Laptops & Computers', icon: Laptop, color: 'from-orange-500 to-amber-500', bgColor: 'bg-gradient-to-br from-orange-50 to-amber-50' },
  { id: 'electrical', name: 'Electrical & Electronics', icon: Zap, color: 'from-slate-500 to-gray-500', bgColor: 'bg-gradient-to-br from-slate-50 to-gray-50' },
  { 
    id: 'wedding', 
    name: 'Wedding & Matchmaking', 
    icon: HeartIcon,
    color: 'from-red-500 to-pink-500', 
    bgColor: 'bg-gradient-to-br from-red-50 to-pink-50',
    comingSoon: true,
    externalUrl: 'https://kumaonmatrimony.com'
  }
];

const CategoryList: React.FC = memo(() => {
  const handleExternalClick = (category: Category) => {
    if (category.externalUrl) {
      window.open(category.externalUrl, '_blank');
    }
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
      {categories.map((category) => {
        const Icon = category.icon;
        const isExternal = category.comingSoon && category.externalUrl;

        return (
          <div
            key={category.id}
            onClick={() => isExternal && handleExternalClick(category)}
            className={`group relative flex flex-col items-center p-6 rounded-2xl transition-all duration-300 hover:-translate-y-2 ${
              isExternal ? 'cursor-pointer' : ''
            }`}
          >
            {!isExternal && (
              <Link
                to={`/category/${category.id}`}
                className="absolute inset-0 z-10"
                aria-label={category.name}
              />
            )}
            
            {/* Background with gradient */}
            <div 
              className={`absolute inset-0 ${category.bgColor} rounded-2xl opacity-100 transition-all duration-300 group-hover:opacity-90 group-hover:shadow-lg`}
            />
            
            {/* Hover border effect */}
            <div className="absolute inset-0 rounded-2xl border-2 border-transparent group-hover:border-gray-200/50 transition-colors duration-300" />
            
            {/* Icon container with gradient background */}
            <div 
              className={`relative z-10 p-6 rounded-xl bg-gradient-to-r ${category.color} text-white shadow-lg mb-4 transform transition-all duration-300 group-hover:scale-110 group-hover:shadow-2xl group-hover:rotate-3`}
            >
              <Icon size={32} strokeWidth={1.5} className={category.id === 'wedding' ? 'text-red-100' : ''} />
            </div>
            
            {/* Category name with better visibility */}
            <div className="relative z-10 text-center">
              <h3 className="text-base font-semibold text-gray-800 group-hover:text-gray-900 transition-colors line-clamp-2">
                {category.name}
              </h3>
              
              {/* Coming soon badge */}
              {category.comingSoon && (
                <div className="mt-2 inline-flex items-center px-3 py-1 rounded-full bg-pink-100 text-pink-600 text-xs font-medium">
                  {isExternal ? (
                    <>
                      <ExternalLink size={12} className="mr-1" />
                      Coming Soon
                    </>
                  ) : (
                    <>
                      <Lock size={12} className="mr-1" />
                      Coming Soon
                    </>
                  )}
                </div>
              )}
            </div>
            
            {/* Hover effect overlay */}
            <div className="absolute inset-0 rounded-2xl bg-white opacity-0 group-hover:opacity-5 transition-opacity duration-300" />
          </div>
        );
      })}
    </div>
  );
});

export default CategoryList;