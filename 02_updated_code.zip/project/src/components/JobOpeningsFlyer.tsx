import React, { useState, useEffect } from 'react';
import { ShoppingBag, MapPin, Clock, Calendar } from 'lucide-react';

const backgroundImages = [
  // High-quality, vibrant background images
  'https://images.unsplash.com/photo-1580974928064-f0aeef70895a?auto=format&fit=crop&w=1920&q=80', // Electronics/Gadgets
  'https://images.unsplash.com/photo-1622185135505-2d795003994a?auto=format&fit=crop&w=1920&q=80', // Bikes/Vehicles
  'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=1920&q=80', // Hostels/Accommodations
  'https://images.unsplash.com/photo-1607082349566-187342175e2f?auto=format&fit=crop&w=1920&q=80'  // Marketplace
];

const messages = [
  {
    id: 1,
    text: "KumaonBazaar.com – Your Local Marketplace for Everything!",
    icon: ShoppingBag,
    gradient: "from-purple-600/75 to-indigo-600/75"
  },
  {
    id: 2,
    text: "Buy and sell gadgets, bikes, and more. Find the perfect hostel or PG accommodation.",
    icon: MapPin,
    gradient: "from-orange-600/75 to-pink-600/75"
  },
  {
    id: 3,
    text: "Simply register, choose a category and district in Kumaon, upload images, and post your ad.",
    icon: Clock,
    gradient: "from-emerald-600/75 to-teal-600/75"
  },
  {
    id: 4,
    text: "Your one-stop destination for all your needs—start exploring today!",
    icon: Calendar,
    gradient: "from-blue-600/75 to-violet-600/75"
  }
];

const JobOpeningsFlyer: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true);
      setCurrentIndex((prev) => (prev + 1) % messages.length);
      setTimeout(() => setIsAnimating(false), 1000);
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  const currentMessage = messages[currentIndex];
  const Icon = currentMessage.icon;

  return (
    <div className="relative overflow-hidden h-64">
      {/* Background Images with Ken Burns effect */}
      {backgroundImages.map((image, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-all duration-2000 transform ${
            index === currentIndex ? 'opacity-100 scale-105' : 'opacity-0 scale-100'
          }`}
          style={{
            backgroundImage: `url(${image})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            transform: index === currentIndex ? 'scale(1.1)' : 'scale(1)',
            transition: 'transform 8s ease-out, opacity 1s ease-in-out',
          }}
        />
      ))}

      {/* Semi-transparent overlay for better text readability */}
      <div className="absolute inset-0 bg-black/30" />

      {/* Gradient Overlay */}
      <div className={`absolute inset-0 bg-gradient-to-r ${currentMessage.gradient} mix-blend-multiply`} />

      {/* Content Container */}
      <div className="relative h-full">
        <div className="container mx-auto px-4 h-full flex items-center justify-center">
          <div className="text-center text-white max-w-3xl">
            {/* Icon with enhanced glow effect */}
            <div className="inline-flex items-center justify-center p-4 mb-6 relative">
              <div className="absolute inset-0 bg-white/30 rounded-full blur-2xl animate-pulse-soft" />
              <div className="absolute inset-0 bg-white/20 rounded-full blur-lg animate-float" />
              <div className="relative bg-white/20 rounded-full p-4 backdrop-blur-sm border border-white/30 shadow-xl animate-float">
                <Icon className="h-8 w-8" />
              </div>
            </div>

            {/* Message with enhanced visibility */}
            <div className="relative overflow-hidden backdrop-blur-sm bg-black/20 rounded-xl p-6 border border-white/10">
              <p 
                className={`text-xl md:text-2xl font-medium tracking-wide transition-all duration-1000 ${
                  isAnimating ? 'opacity-0 transform translate-y-4' : 'opacity-100 transform translate-y-0'
                }`}
                style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
              >
                {currentMessage.text}
              </p>

              {/* Progress Indicators */}
              <div className="flex justify-center mt-6 space-x-2">
                {messages.map((_, index) => (
                  <div
                    key={index}
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      index === currentIndex 
                        ? 'w-8 bg-white shadow-lg' 
                        : 'w-1.5 bg-white/50'
                    }`}
                  >
                    {index === currentIndex && (
                      <div 
                        className="h-full bg-white/50"
                        style={{ 
                          animation: 'progress 8s linear',
                          transformOrigin: 'left'
                        }} 
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-black/5 to-transparent pointer-events-none" />
    </div>
  );
};

export default JobOpeningsFlyer;