import React, { memo } from 'react';
import { MapPin, Calendar } from 'lucide-react';

const DEFAULT_IMAGE_URL = 'https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';

interface AdCardProps {
  id: string;
  title: string;
  price: number;
  location: string;
  category: string;
  createdAt: string;
  imageUrl?: string;
}

const AdCard: React.FC<AdCardProps> = memo(({
  id,
  title,
  price,
  location,
  category,
  createdAt,
  imageUrl
}) => {
  // Get price label based on category
  const getPriceLabel = () => {
    switch (category) {
      case 'jobs':
        return 'Salary';
      case 'education':
        return 'Fees';
      default:
        return 'Price';
    }
  };

  // Format date
  const formattedDate = new Date(createdAt).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });

  return (
    <div className="group bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div className="relative h-48 bg-gray-200 overflow-hidden">
        <img
          src={imageUrl || DEFAULT_IMAGE_URL}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
          loading="lazy"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = DEFAULT_IMAGE_URL;
          }}
        />
        <div className="absolute top-2 left-2">
          <span className="inline-block bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xs px-3 py-1 rounded-full font-medium shadow-lg">
            {category}
          </span>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-800 line-clamp-2 mb-2 group-hover:text-orange-600 transition-colors">
          {title}
        </h3>
        <p className="text-xl font-bold text-orange-600 mb-3">
          {getPriceLabel()}: ₹{price.toLocaleString('en-IN')}
        </p>
        <div className="flex items-center justify-between text-gray-500 text-sm">
          <div className="flex items-center">
            <MapPin size={16} className="mr-1 text-orange-500" />
            <span className="truncate">{location}</span>
          </div>
          <div className="flex items-center">
            <Calendar size={16} className="mr-1 text-orange-500" />
            <span>{formattedDate}</span>
          </div>
        </div>
      </div>
    </div>
  );
});

export default AdCard;