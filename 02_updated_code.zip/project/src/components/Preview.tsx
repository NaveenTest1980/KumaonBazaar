import React from 'react';
import { useLocation } from 'react-router-dom';

interface PreviewProps {
  children: React.ReactNode;
}

const Preview: React.FC<PreviewProps> = ({ children }) => {
  const location = useLocation();
  const isPreview = new URLSearchParams(location.search).get('preview') === 'true';

  if (!isPreview) {
    return <>{children}</>;
  }

  return (
    <div className="relative">
      {/* Preview Banner */}
      <div className="fixed top-0 left-0 right-0 bg-orange-500 text-white py-2 px-4 text-center z-50">
        <p className="text-sm font-medium">
          Preview Mode - This is a preview of your content
        </p>
      </div>

      {/* Add padding to account for the banner */}
      <div className="pt-10">
        {children}
      </div>
    </div>
  );
};

export default Preview;