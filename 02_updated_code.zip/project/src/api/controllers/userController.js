import { sql } from '../../db/neon.js';

export const getUserProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const [user] = await sql`
      SELECT id, name, email, created_at
      FROM users
      WHERE id = ${userId}
    `;

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user });
  } catch (error) {
    console.error('Get user profile error:', error);
    res.status(500).json({
      error: 'Failed to get user profile'
    });
  }
};

export const updateUserProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const { name, email } = req.body;

    // Check if email is already taken
    if (email) {
      const [existingUser] = await sql`
        SELECT id FROM users
        WHERE email = ${email} AND id != ${userId}
      `;

      if (existingUser) {
        return res.status(400).json({ error: 'Email already in use' });
      }
    }

    // Update user
    const [updatedUser] = await sql`
      UPDATE users
      SET
        name = COALESCE(${name}, name),
        email = COALESCE(${email}, email)
      WHERE id = ${userId}
      RETURNING id, name, email, created_at
    `;

    res.json({ user: updatedUser });
  } catch (error) {
    console.error('Update user profile error:', error);
    res.status(500).json({
      error: 'Failed to update user profile'
    });
  }
};