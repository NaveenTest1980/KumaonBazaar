import { neon, neonConfig } from '@neondatabase/serverless';

// Configure Neon
neonConfig.fetchConnectionCache = true;

// Get database URL from environment variables
const databaseUrl = import.meta.env.VITE_NEON_DATABASE_URL;

if (!databaseUrl) {
  throw new Error('Database URL not found');
}

// Initialize SQL client
export const sql = neon(databaseUrl);

// Initialize database
export async function initializeDatabase() {
  try {
    console.log('Testing database connection...');
    
    // Test connection
    const result = await sql`SELECT 1 as connected`;
    if (!result?.[0]?.connected) {
      throw new Error('Database connection test failed');
    }
    console.log('Database connection successful');

    // Set search path to neondb schema
    await sql`SET search_path TO neondb`;

    return true;
  } catch (error) {
    console.error('Database initialization error:', error);
    throw error;
  }
}

export default sql;