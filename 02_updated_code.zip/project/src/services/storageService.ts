// Supported file types
const SUPPORTED_FILE_TYPES = [
  'image/jpeg',
  'image/png',
  'image/gif',
  'image/webp'
];

// Maximum file size (5MB)
const MAX_FILE_SIZE = 5 * 1024 * 1024;

export async function uploadImage(
  file: File,
  onProgress?: (progress: number) => void
): Promise<{ url: string; cloudflareId: string }> {
  try {
    console.log('Starting image upload process:', {
      fileName: file.name,
      fileType: file.type,
      fileSize: file.size
    });

    // Validate file type
    if (!SUPPORTED_FILE_TYPES.includes(file.type)) {
      const error = `Unsupported file type: ${file.type}. Supported types are: ${SUPPORTED_FILE_TYPES.join(', ')}`;
      console.error('File type validation failed:', error);
      throw new Error(error);
    }

    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      const error = `File size exceeds 5MB limit. Current size: ${(file.size / 1024 / 1024).toFixed(2)}MB`;
      console.error('File size validation failed:', error);
      throw new Error(error);
    }

    // Create FormData
    const formData = new FormData();
    formData.append('file', file);

    // Start upload
    if (onProgress) {
      onProgress(10);
    }

    // Upload directly to Cloudflare R2
    const response = await fetch('/api/upload', {
      method: 'POST',
      body: formData,
      headers: {
        'Authorization': `Bearer ${import.meta.env.VITE_CLOUDFLARE_TOKEN}`
      }
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Upload failed: ${error}`);
    }

    const result = await response.json();

    if (!result.success) {
      throw new Error(result.error || 'Upload failed');
    }

    // Upload complete
    if (onProgress) {
      onProgress(100);
    }

    return {
      url: result.url,
      cloudflareId: result.cloudflareId
    };
  } catch (error: any) {
    console.error('Error uploading image:', error);
    throw new Error(`Failed to upload image: ${error.message}`);
  }
}