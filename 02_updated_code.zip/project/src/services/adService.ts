import { sql } from '../db/neon';
import { Ad, CreateAdRequest } from '../types/Ad';
import { uploadImage } from './storageService';

export const DEFAULT_IMAGE_URL = 'https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';

export async function createAd(
  request: CreateAdRequest, 
  images: File[],
  onProgress?: (progress: number) => void
): Promise<Ad> {
  try {
    console.log('Starting ad creation process...');

    // Start a transaction
    await sql`BEGIN`;

    try {
      // Create the ad first
      const [ad] = await sql`
        INSERT INTO neondb.ads (
          title,
          description,
          price,
          category_id,
          location,
          district_id,
          town_id,
          user_id,
          phone_number,
          featured
        ) VALUES (
          ${request.title},
          ${request.description},
          ${request.price},
          ${request.categoryId},
          ${request.location},
          ${request.districtId},
          ${request.townId},
          ${request.userId}::uuid,
          ${request.phoneNumber || null},
          ${request.featured || false}
        )
        RETURNING *
      `;

      console.log('Ad record created:', ad);

      // Upload and store images
      const adImages = [];
      const totalImages = images.length;
      
      for (const [index, file] of images.entries()) {
        console.log(`Uploading image ${index + 1} of ${totalImages}...`);
        
        try {
          // Upload image to Cloudflare R2
          const { url, cloudflareId } = await uploadImage(file, (imageProgress) => {
            if (onProgress) {
              // Calculate overall progress considering all images
              const overallProgress = ((index * 100) + imageProgress) / totalImages;
              onProgress(Math.round(overallProgress));
            }
          });
          
          console.log(`Image ${index + 1} uploaded successfully:`, { url, cloudflareId });
          
          // Store image record in database
          const [image] = await sql`
            INSERT INTO neondb.ad_images (
              ad_id,
              url,
              cloudflare_id,
              is_primary
            ) VALUES (
              ${ad.id}::uuid,
              ${url},
              ${cloudflareId},
              ${index === 0} -- First image is primary
            )
            RETURNING *
          `;
          
          adImages.push(image);
          console.log(`Image ${index + 1} record created:`, image);
        } catch (error) {
          // If image upload fails, rollback the transaction
          await sql`ROLLBACK`;
          console.error(`Error uploading image ${index + 1}:`, error);
          throw error;
        }
      }

      // Get user name
      const [user] = await sql`
        SELECT name FROM neondb.users WHERE id = ${request.userId}::uuid
      `;

      // Commit the transaction
      await sql`COMMIT`;

      console.log('Transaction committed successfully');

      // Return complete ad with images
      return {
        ...ad,
        user_name: user.name,
        images: adImages
      };
    } catch (error) {
      // Rollback on any error
      await sql`ROLLBACK`;
      throw error;
    }
  } catch (error: any) {
    console.error("Error creating ad:", {
      message: error.message,
      stack: error.stack,
      code: error.code,
      severity: error.severity
    });
    throw new Error("Failed to create ad: " + error.message);
  }
}

export async function getRecentAds(
  page = 1,
  limit = 20,
  districtId?: string | null
): Promise<{ ads: Ad[]; total: number }> {
  try {
    console.log('Fetching recent ads:', { page, limit, districtId });

    // Get total count
    const countQuery = districtId
      ? sql`SELECT COUNT(*) FROM neondb.ads a WHERE a.status = 'Active' AND a.district_id = ${districtId}`
      : sql`SELECT COUNT(*) FROM neondb.ads a WHERE a.status = 'Active'`;

    const [{ count }] = await countQuery;

    // Get ads with their images in a single query
    const adsQuery = districtId
      ? sql`
          WITH recent_ads AS (
            SELECT 
              a.*,
              u.name as user_name,
              c.price_label,
              COALESCE(
                (
                  SELECT jsonb_agg(
                    jsonb_build_object(
                      'id', i.id,
                      'url', i.url,
                      'is_primary', i.is_primary,
                      'created_at', i.created_at
                    ) ORDER BY i.is_primary DESC, i.created_at ASC
                  )
                  FROM neondb.ad_images i
                  WHERE i.ad_id = a.id
                ),
                '[]'::jsonb
              ) as images
            FROM neondb.ads a
            LEFT JOIN neondb.users u ON a.user_id = u.id
            LEFT JOIN neondb.categories c ON a.category_id = c.id
            WHERE a.status = 'Active' AND a.district_id = ${districtId}
            ORDER BY a.featured DESC, a.created_at DESC
            LIMIT ${limit}
            OFFSET ${(page - 1) * limit}
          )
          SELECT * FROM recent_ads`
      : sql`
          WITH recent_ads AS (
            SELECT 
              a.*,
              u.name as user_name,
              c.price_label,
              COALESCE(
                (
                  SELECT jsonb_agg(
                    jsonb_build_object(
                      'id', i.id,
                      'url', i.url,
                      'is_primary', i.is_primary,
                      'created_at', i.created_at
                    ) ORDER BY i.is_primary DESC, i.created_at ASC
                  )
                  FROM neondb.ad_images i
                  WHERE i.ad_id = a.id
                ),
                '[]'::jsonb
              ) as images
            FROM neondb.ads a
            LEFT JOIN neondb.users u ON a.user_id = u.id
            LEFT JOIN neondb.categories c ON a.category_id = c.id
            WHERE a.status = 'Active'
            ORDER BY a.featured DESC, a.created_at DESC
            LIMIT ${limit}
            OFFSET ${(page - 1) * limit}
          )
          SELECT * FROM recent_ads`;

    const results = await adsQuery;

    // Parse results and ensure images are properly formatted
    const ads = results.map(row => {
      let images: any[] = [];
      try {
        if (row.images) {
          images = Array.isArray(row.images) ? row.images : JSON.parse(row.images);
        }
      } catch (e) {
        console.error('Error parsing images:', e);
      }

      // Add default image if no images are available
      if (images.length === 0) {
        images = [{
          id: 'default',
          url: DEFAULT_IMAGE_URL,
          is_primary: true,
          created_at: row.created_at
        }];
      }

      return {
        ...row,
        images: images.map(img => ({
          id: img.id,
          url: img.url,
          is_primary: Boolean(img.is_primary),
          created_at: img.created_at
        }))
      };
    });

    console.log(`Found ${ads.length} ads${districtId ? ` for district ${districtId}` : ''}`);
    return {
      ads,
      total: Number(count)
    };
  }catch (error: any) {
    console.error("Error fetching recent ads:", {
      message: error.message,
      stack: error.stack,
      code: error.code,
      severity: error.severity
    });
    throw new Error("Failed to fetch recent ads: " + error.message);
  }
}

export async function getAdById(id: string): Promise<Ad | null> {
  try {
    const [ad] = await sql`
      SELECT a.*,
             u.name as user_name,
             c.price_label,
             COALESCE(
               (
                 SELECT jsonb_agg(
                   jsonb_build_object(
                     'id', i.id,
                     'url', i.url,
                     'is_primary', i.is_primary,
                     'created_at', i.created_at
                   ) ORDER BY i.is_primary DESC, i.created_at ASC
                 )
                 FROM neondb.ad_images i
                 WHERE i.ad_id = a.id
               ),
               '[]'::jsonb
             ) as images
      FROM neondb.ads a
      LEFT JOIN neondb.users u ON a.user_id = u.id
      LEFT JOIN neondb.categories c ON a.category_id = c.id
      WHERE a.id = ${id}::uuid
    `;

    if (!ad) return null;

    // Parse images from JSONB
    let images: any[] = [];
    try {
      if (ad.images) {
        images = Array.isArray(ad.images) ? ad.images : JSON.parse(ad.images);
      }
    } catch (e) {
      console.error('Error parsing images:', e);
    }

    // Add default image if no images are available
    if (images.length === 0) {
      images = [{
        id: 'default',
        url: DEFAULT_IMAGE_URL,
        is_primary: true,
        created_at: ad.created_at
      }];
    }

    return {
      ...ad,
      images: images.map(img => ({
        id: img.id,
        url: img.url,
        is_primary: Boolean(img.is_primary),
        created_at: img.created_at
      }))
    };
  } catch (error) {
    console.error('Error getting ad by ID:', error);
    return null;
  }
}

export async function getAdsByCategory(categoryId: string, page = 1, limit = 20): Promise<{ ads: Ad[]; total: number }> {
  try {
    // Check if category is restricted (jobs or wedding)
    if (categoryId === 'jobs') {
      throw new Error('Please visit KumaonJobs.com for job listings');
    }
    if (categoryId === 'wedding') {
      throw new Error('Please visit KumaonMatrimony.com for matrimonial services');
    }

    // Get total count for this category
    const [{ count }] = await sql`
      SELECT COUNT(*) 
      FROM neondb.ads 
      WHERE category_id = ${categoryId}
      AND status = 'Active'
      AND category_id NOT IN ('jobs', 'wedding')
    `;

    // Get ads with their images in a single query
    const results = await sql`
      WITH category_ads AS (
        SELECT 
          a.*,
          u.name as user_name,
          c.price_label,
          COALESCE(
            (
              SELECT jsonb_agg(
                jsonb_build_object(
                  'id', i.id,
                  'url', i.url,
                  'is_primary', i.is_primary,
                  'created_at', i.created_at
                ) ORDER BY i.is_primary DESC, i.created_at ASC
              )
              FROM neondb.ad_images i
              WHERE i.ad_id = a.id
            ),
            '[]'::jsonb
          ) as images
        FROM neondb.ads a
        LEFT JOIN neondb.users u ON a.user_id = u.id
        LEFT JOIN neondb.categories c ON a.category_id = c.id
        WHERE a.category_id = ${categoryId}
        AND a.status = 'Active'
        AND a.category_id NOT IN ('jobs', 'wedding')
        ORDER BY a.featured DESC, a.created_at DESC
        LIMIT ${limit}
        OFFSET ${(page - 1) * limit}
      )
      SELECT * FROM category_ads
    `;

    // Parse results and ensure images are properly formatted
    const ads = results.map(row => {
      let images: any[] = [];
      try {
        if (row.images) {
          images = Array.isArray(row.images) ? row.images : JSON.parse(row.images);
        }
      } catch (e) {
        console.error('Error parsing images:', e);
      }

      // Add default image if no images are available
      if (images.length === 0) {
        images = [{
          id: 'default',
          url: DEFAULT_IMAGE_URL,
          is_primary: true,
          created_at: row.created_at
        }];
      }

      return {
        ...row,
        images: images.map(img => ({
          id: img.id,
          url: img.url,
          is_primary: Boolean(img.is_primary),
          created_at: img.created_at
        }))
      };
    });

    return {
      ads,
      total: Number(count)
    };
  } catch (error) {
    console.error('Error getting ads by category:', error);
    throw error;
  }
}

export default {
  getAdById,
  getAdsByCategory,
  getRecentAds,
  createAd
};