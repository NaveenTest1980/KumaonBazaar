import { v4 as uuidv4 } from 'uuid';
import { sql } from '../db/neon';
import { Ad } from '../types/Ad';

interface Favorite {
  id: string;
  user_id: string;
  ad_id: string;
  created_at: string;
}

// Add a favorite
export async function addFavorite(userId: string, adId: string): Promise<Favorite> {
  try {
    const [favorite] = await sql<Favorite>`
      INSERT INTO ukmarketplace_dev.favorites (id, user_id, ad_id, created_at)
      VALUES (${uuidv4()}, ${userId}, ${adId}, CURRENT_TIMESTAMP)
      ON CONFLICT (user_id, ad_id) DO NOTHING
      RETURNING *
    `;
    
    if (!favorite) {
      const [existing] = await sql<Favorite>`
        SELECT * FROM ukmarketplace_dev.favorites 
        WHERE user_id = ${userId} AND ad_id = ${adId}
      `;
      return existing;
    }
    
    return favorite;
  } catch (error) {
    console.error('Error adding favorite:', error);
    throw new Error('Failed to add favorite');
  }
}

// Remove a favorite
export async function removeFavorite(userId: string, adId: string): Promise<boolean> {
  try {
    const result = await sql`
      DELETE FROM ukmarketplace_dev.favorites 
      WHERE user_id = ${userId} AND ad_id = ${adId}
    `;
    return result.count > 0;
  } catch (error) {
    console.error('Error removing favorite:', error);
    throw new Error('Failed to remove favorite');
  }
}

// Check if an ad is favorited by a user
export async function isFavorited(userId: string, adId: string): Promise<boolean> {
  try {
    const [result] = await sql`
      SELECT EXISTS (
        SELECT 1 FROM ukmarketplace_dev.favorites 
        WHERE user_id = ${userId} AND ad_id = ${adId}
      ) as exists
    `;
    return result.exists;
  } catch (error) {
    console.error('Error checking favorite:', error);
    throw new Error('Failed to check favorite');
  }
}

// Get user's favorites
export async function getUserFavorites(userId: string): Promise<Ad[]> {
  try {
    const favorites = await sql<Ad>`
      SELECT a.*, u.name as user_name
      FROM ukmarketplace_dev.favorites f
      JOIN ukmarketplace_dev.ads a ON f.ad_id = a.id
      JOIN ukmarketplace_dev.users u ON a.user_id = u.id
      WHERE f.user_id = ${userId}
      ORDER BY f.created_at DESC
    `;
    
    // Get images for each ad
    for (const ad of favorites) {
      const images = await sql`
        SELECT * FROM ukmarketplace_dev.ad_images
        WHERE ad_id = ${ad.id}
        ORDER BY is_primary DESC, created_at ASC
      `;
      ad.images = images;
    }
    
    return favorites;
  } catch (error) {
    console.error('Error getting user favorites:', error);
    throw new Error('Failed to get user favorites');
  }
}