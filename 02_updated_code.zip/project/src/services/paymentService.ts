import { v4 as uuidv4 } from 'uuid';
import { sql } from '../db/neon';
import { PhoneNumberExtensionRequest } from '../types/Ad';

interface Payment {
  id: string;
  user_id: string;
  ad_id: string;
  amount: number;
  payment_method: string;
  payment_id?: string;
  status: PaymentStatus;
  created_at: string;
}

enum PaymentStatus {
  Pending = 'pending',
  Completed = 'completed',
  Failed = 'failed'
}

// Process phone number visibility extension payment
export const extendPhoneNumberVisibility = async (request: PhoneNumberExtensionRequest): Promise<{ success: boolean; message?: string }> => {
  try {
    // Start transaction
    const result = await sql.begin(async (sql) => {
      // Create payment record
      const [payment] = await sql<Payment>`
        INSERT INTO ukmarketplace_dev.payments (
          id, user_id, ad_id, amount, payment_method, payment_id, status, created_at
        ) VALUES (
          ${uuidv4()}, ${request.userId}, ${request.adId}, 100,
          ${request.paymentMethod}, ${request.paymentId || null},
          ${PaymentStatus.Completed}, CURRENT_TIMESTAMP
        ) RETURNING *
      `;

      // Update ad phone number visibility
      const phoneNumberExpiryDate = new Date();
      phoneNumberExpiryDate.setDate(phoneNumberExpiryDate.getDate() + 30);

      await sql`
        UPDATE ukmarketplace_dev.ads
        SET 
          phone_number_visible = true,
          phone_number_expiry_date = ${phoneNumberExpiryDate.toISOString()},
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ${request.adId} AND user_id = ${request.userId}
      `;

      return payment;
    });

    return {
      success: true,
      message: 'Phone number visibility extended successfully'
    };
  } catch (error) {
    console.error('Error extending phone number visibility:', error);
    return {
      success: false,
      message: 'Failed to process payment'
    };
  }
};

// Get payment history for a user
export const getUserPayments = async (userId: string): Promise<Payment[]> => {
  try {
    const payments = await sql<Payment>`
      SELECT * FROM ukmarketplace_dev.payments
      WHERE user_id = ${userId}
      ORDER BY created_at DESC
    `;
    return payments;
  } catch (error) {
    console.error('Error getting user payments:', error);
    throw new Error('Failed to get user payments');
  }
};