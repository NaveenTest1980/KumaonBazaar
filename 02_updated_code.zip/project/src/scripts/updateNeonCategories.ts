import { sql } from '../db/neon.js';

async function updateNeonCategories() {
  try {
    console.log('Connecting to Neon database...');
    
    // Set search path to neondb schema
    await sql`SET search_path TO neondb`;
    
    console.log('Starting categories update...');
    
    // Start a transaction
    await sql`BEGIN`;
    
    try {
      // Drop and recreate categories table
      await sql`DROP TABLE IF EXISTS categories CASCADE`;
      
      await sql`
        CREATE TABLE categories (
          id text PRIMARY KEY,
          name text NOT NULL,
          icon text NOT NULL,
          price_label text DEFAULT 'Price',
          coming_soon boolean DEFAULT false,
          created_at timestamptz DEFAULT CURRENT_TIMESTAMP
        )
      `;
      
      // Insert all categories
      const categories = await sql`
        INSERT INTO categories (id, name, icon, price_label, coming_soon)
        VALUES
          ('books', 'Books', 'BookOpen', 'Price', false),
          ('vehicles', 'Vehicles', 'Car', 'Price', false),
          ('real-estate', 'Real Estate', 'Home', 'Price', false),
          ('electronics', 'Electronics', 'Smartphone', 'Price', false),
          ('jobs', 'Jobs', 'Briefcase', 'Salary', false),
          ('furniture', 'Furniture', 'Sofa', 'Price', false),
          ('fashion', 'Fashion', 'ShoppingBag', 'Price', false),
          ('education', 'Education & Learning', 'GraduationCap', 'Fees', false),
          ('hotels', 'Hotels & Resorts', 'Hotel', 'Price', false),
          ('food', 'Food & Dining', 'UtensilsCrossed', 'Price', false),
          ('grocery', 'Grocery & Supermarkets', 'ShoppingCart', 'Price', false),
          ('transport', 'Transport & Vehicles', 'Truck', 'Price', false),
          ('events', 'Events & Activities', 'Calendar', 'Price', false),
          ('nightlife', 'Bars & Nightclubs', 'Wine', 'Price', false),
          ('mobile', 'Mobile & Tablets', 'Smartphone', 'Price', false),
          ('laptops', 'Laptops & Computers', 'Laptop', 'Price', false),
          ('electrical', 'Electrical & Electronics', 'Zap', 'Price', false),
          ('wedding', 'Wedding & Matchmaking', 'Heart', 'Price', true)
        RETURNING *
      `;
      
      // Create indexes
      await sql`CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name)`;
      await sql`CREATE INDEX IF NOT EXISTS idx_categories_coming_soon ON categories(coming_soon)`;
      await sql`CREATE INDEX IF NOT EXISTS idx_categories_price_label ON categories(price_label)`;
      
      // Commit the transaction
      await sql`COMMIT`;
      
      console.log('Categories updated successfully:', categories.length);
      console.log('Updated categories:', categories.map(c => c.name).join(', '));
      
      process.exit(0);
    } catch (error) {
      // Rollback on error
      await sql`ROLLBACK`;
      throw error;
    }
  } catch (error) {
    console.error('Error updating categories:', error);
    process.exit(1);
  }
}

updateNeonCategories().catch(error => {
  console.error('Unhandled error:', error);
  process.exit(1);
});