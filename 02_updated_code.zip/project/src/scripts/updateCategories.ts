import { sql } from '../db/neon.js';

async function updateCategories() {
  try {
    console.log('Connecting to Neon database...');
    
    // Set search path to neondb schema
    await sql`SET search_path TO neondb`;
    
    console.log('Starting categories update...');
    
    // Start a transaction
    await sql`BEGIN`;
    
    try {
      // Drop and recreate categories table
      await sql`DROP TABLE IF EXISTS categories CASCADE`;
      
      await sql`
        CREATE TABLE categories (
          id text PRIMARY KEY,
          name text NOT NULL,
          icon text NOT NULL,
          coming_soon boolean DEFAULT false,
          created_at timestamptz DEFAULT CURRENT_TIMESTAMP
        )
      `;
      
      // Insert all categories
      const categories = await sql`
        INSERT INTO categories (id, name, icon, coming_soon)
        VALUES
          ('books', 'Books', 'BookOpen', false),
          ('vehicles', 'Vehicles', 'Car', false),
          ('real-estate', 'Real Estate', 'Home', false),
          ('electronics', 'Electronics', 'Smartphone', false),
          ('jobs', 'Jobs', 'Briefcase', false),
          ('furniture', 'Furniture', 'Sofa', false),
          ('fashion', 'Fashion', 'ShoppingBag', false),
          ('education', 'Education & Learning', 'GraduationCap', false),
          ('hotels', 'Hotels & Resorts', 'Hotel', false),
          ('food', 'Food & Dining', 'UtensilsCrossed', false),
          ('grocery', 'Grocery & Supermarkets', 'ShoppingCart', false),
          ('transport', 'Transport & Vehicles', 'Truck', false),
          ('events', 'Events & Activities', 'Calendar', false),
          ('nightlife', 'Bars & Nightclubs', 'Wine', false),
          ('mobile', 'Mobile & Tablets', 'Smartphone', false),
          ('laptops', 'Laptops & Computers', 'Laptop', false),
          ('electrical', 'Electrical & Electronics', 'Zap', false),
          ('wedding', 'Wedding & Matchmaking', 'Heart', true)
        RETURNING *
      `;
      
      // Create indexes
      await sql`CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name)`;
      await sql`CREATE INDEX IF NOT EXISTS idx_categories_coming_soon ON categories(coming_soon)`;
      
      // Commit the transaction
      await sql`COMMIT`;
      
      console.log('Categories updated successfully:', categories.length);
      console.log('Updated categories:', categories.map(c => c.name).join(', '));
      
      process.exit(0);
    } catch (error) {
      // Rollback on error
      await sql`ROLLBACK`;
      throw error;
    }
  } catch (error) {
    console.error('Error updating categories:', error);
    process.exit(1);
  }
}

updateCategories().catch(error => {
  console.error('Unhandled error:', error);
  process.exit(1);
});