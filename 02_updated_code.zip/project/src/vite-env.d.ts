/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly NEON_DATABASE_URL: string;
  readonly VITE_API_URL: string;
  readonly VITE_CLOUDFLARE_ACCESS_KEY_ID: string;
  readonly VITE_CLOUDFLARE_SECRET_ACCESS_KEY: string;
  readonly VITE_CLOUDFLARE_TOKEN: string;
  readonly JWT_SECRET: string;
  readonly JWT_EXPIRY: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}