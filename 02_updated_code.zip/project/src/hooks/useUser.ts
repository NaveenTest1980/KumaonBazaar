import { useState, useEffect } from 'react';
import { User } from '../types/User';

export function useUser() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    const session = localStorage.getItem('userSession');
    if (session) {
      setCurrentUser(JSON.parse(session));
    }
    setLoading(false);
  }, []);

  const register = async (email: string, password: string, name: string) => {
    try {
      // For demo, store user in localStorage
      const user = {
        id: `user_${Date.now()}`,
        email,
        name
      };
      setCurrentUser(user);
      localStorage.setItem('userSession', JSON.stringify(user));
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  };

  const login = async (email: string, password: string) => {
    try {
      // For demo, create a mock user
      const user = {
        id: `user_${Date.now()}`,
        email,
        name: email.split('@')[0]
      };
      setCurrentUser(user);
      localStorage.setItem('userSession', JSON.stringify(user));
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  };

  const logout = async () => {
    localStorage.removeItem('userSession');
    setCurrentUser(null);
  };

  return {
    currentUser,
    loading,
    register,
    login,
    logout
  };
}