import { useLocation } from 'react-router-dom';

export function usePreview() {
  const location = useLocation();
  const isPreview = new URLSearchParams(location.search).get('preview') === 'true';
  
  return {
    isPreview,
    previewUrl: `${window.location.pathname}?preview=true`,
    liveUrl: window.location.pathname
  };
}