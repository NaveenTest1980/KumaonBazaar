import { CLOUDFLARE_CONFIG } from '../config';
import { supabase } from '../lib/supabase';

export const IMAGE_VARIANTS = {
  ORIGINAL: 'public',
  THUMBNAIL: 'thumbnail'
};

export async function uploadImage(
  file: File,
  onProgress?: (progress: number) => void
): Promise<{ url: string; cloudflareId: string }> {
  try {
    // Get the current session
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      throw new Error('No authenticated session found');
    }

    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/upload`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${session.access_token}`
      },
      body: formData
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Upload failed');
    }

    const result = await response.json();
    
    if (onProgress) {
      onProgress(100);
    }
    
    return result;
  } catch (error: any) {
    console.error('Upload error:', error);
    throw new Error(`Upload failed: ${error.message}`);
  }
}

export function getImageUrl(cloudflareId: string, variant: string = IMAGE_VARIANTS.ORIGINAL): string {
  if (!cloudflareId) return '';
  return `${CLOUDFLARE_CONFIG.imageDeliveryUrl}/${cloudflareId}/${variant}`;
}