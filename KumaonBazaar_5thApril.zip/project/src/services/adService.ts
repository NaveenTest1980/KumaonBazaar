import { sql } from '../db/neon';
import { Ad, CreateAdRequest } from '../types/Ad';
import { uploadImage, getImageUrl, IMAGE_VARIANTS } from './storageService';

export const DEFAULT_IMAGE_URL = 'https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';

export async function getAdById(id: string): Promise<Ad | null> {
  try {
    const [ad] = await sql`
      SELECT 
        a.*,
        u.name as user_name,
        COALESCE(
          json_agg(
            json_build_object(
              'id', ai.id,
              'url', ai.url,
              'is_primary', ai.is_primary,
              'created_at', ai.created_at
            ) ORDER BY ai.is_primary DESC, ai.created_at ASC
          ) FILTER (WHERE ai.id IS NOT NULL),
          '[]'
        ) as images
      FROM ads a
      LEFT JOIN users u ON a.user_id = u.id
      LEFT JOIN ad_images ai ON a.id = ai.ad_id
      WHERE a.id = ${id}::uuid
      GROUP BY a.id, u.name
    `;

    if (!ad) {
      return null;
    }

    return {
      ...ad,
      images: ad.images || []
    };
  } catch (error) {
    console.error('Error fetching ad by ID:', error);
    throw new Error('Failed to fetch ad details');
  }
}

export async function getAdsByCategory(
  categoryId: string,
  page: number = 1,
  limit: number = 20
): Promise<{ ads: Ad[]; total: number }> {
  try {
    const offset = (page - 1) * limit;
    
    const query = sql`
      WITH ad_data AS (
        SELECT 
          a.*,
          u.name as user_name,
          json_agg(
            json_build_object(
              'id', ai.id,
              'url', ai.url,
              'is_primary', ai.is_primary
            )
          ) FILTER (WHERE ai.id IS NOT NULL) as images
        FROM ads a
        LEFT JOIN users u ON a.user_id = u.id
        LEFT JOIN ad_images ai ON a.id = ai.ad_id
        WHERE a.status = 'Active'
        AND a.category_id = ${categoryId}
        GROUP BY a.id, u.name
        ORDER BY a.created_at DESC
        LIMIT ${limit} OFFSET ${offset}
      )
      SELECT 
        ad_data.*,
        (
          SELECT COUNT(*)
          FROM ads
          WHERE status = 'Active'
          AND category_id = ${categoryId}
        ) as total_count
      FROM ad_data
    `;

    const results = await query;
    
    if (!results.length) {
      return { ads: [], total: 0 };
    }

    const total = parseInt(results[0].total_count);
    const ads = results.map(row => ({
      ...row,
      images: row.images || []
    }));

    return { ads, total };
  } catch (error: any) {
    console.error('Error fetching ads by category:', error);
    throw new Error('Failed to fetch ads for this category');
  }
}

export async function getRecentAds(
  page: number = 1,
  limit: number = 20,
  districtId?: string | null
): Promise<{ ads: Ad[]; total: number }> {
  try {
    const offset = (page - 1) * limit;
    let query;
    
    if (districtId) {
      query = sql`
        WITH ad_data AS (
          SELECT 
            a.*,
            u.name as user_name,
            COALESCE(
              json_agg(
                json_build_object(
                  'id', ai.id,
                  'url', ai.url,
                  'is_primary', ai.is_primary
                ) ORDER BY ai.is_primary DESC
              ) FILTER (WHERE ai.id IS NOT NULL),
              '[]'
            ) as images
          FROM neondb.ads a
          LEFT JOIN neondb.users u ON a.user_id = u.id
          LEFT JOIN neondb.ad_images ai ON a.id = ai.ad_id
          WHERE a.status = 'Active'
          AND a.district_id = ${districtId}
          GROUP BY a.id, u.name
          ORDER BY a.created_at DESC
          LIMIT ${limit} OFFSET ${offset}
        )
        SELECT 
          ad_data.*,
          (
            SELECT COUNT(*)
            FROM neondb.ads
            WHERE status = 'Active'
            AND district_id = ${districtId}
          ) as total_count
        FROM ad_data
      `;
    } else {
      query = sql`
        WITH ad_data AS (
          SELECT 
            a.*,
            u.name as user_name,
            COALESCE(
              json_agg(
                json_build_object(
                  'id', ai.id,
                  'url', ai.url,
                  'is_primary', ai.is_primary
                ) ORDER BY ai.is_primary DESC
              ) FILTER (WHERE ai.id IS NOT NULL),
              '[]'
            ) as images
          FROM neondb.ads a
          LEFT JOIN neondb.users u ON a.user_id = u.id
          LEFT JOIN neondb.ad_images ai ON a.id = ai.ad_id
          WHERE a.status = 'Active'
          GROUP BY a.id, u.name
          ORDER BY a.created_at DESC
          LIMIT ${limit} OFFSET ${offset}
        )
        SELECT 
          ad_data.*,
          (
            SELECT COUNT(*)
            FROM neondb.ads
            WHERE status = 'Active'
          ) as total_count
        FROM ad_data
      `;
    }

    const results = await query;
    
    if (!results.length) {
      return { ads: [], total: 0 };
    }

    const total = parseInt(results[0].total_count);
    const ads = results.map(row => ({
      ...row,
      images: row.images || []
    }));

    return { ads, total };
  } catch (error: any) {
    console.error('Error fetching recent ads:', error);
    throw new Error('Failed to fetch recent ads');
  }
}

export async function createAd(
  request: CreateAdRequest,
  images: File[],
  onProgress?: (progress: number) => void
): Promise<Ad> {
  try {
    console.log('Starting ad creation process...', { request, imageCount: images.length });

    // Validate inputs
    if (!images || images.length === 0) {
      throw new Error('At least one image is required');
    }

    // Start a transaction
    await sql`BEGIN`;

    try {
      // Create the ad first
      const [ad] = await sql`
        INSERT INTO neondb.ads (
          title,
          description,
          price,
          category_id,
          location,
          district_id,
          town_id,
          user_id,
          phone_number,
          featured,
          status,
          needs_moderation,
          phone_number_visible,
          created_at,
          updated_at
        ) VALUES (
          ${request.title},
          ${request.description},
          ${request.price},
          ${request.categoryId},
          ${request.location},
          ${request.districtId},
          ${request.townId},
          ${request.userId}::uuid,
          ${request.phoneNumber},
          ${request.featured || false},
          'Active',
          false,
          false,
          now(),
          now()
        )
        RETURNING *
      `;

      console.log('Ad record created:', ad);

      // Upload and store images
      const adImages = [];
      const totalImages = images.length;
      
      for (const [index, file] of images.entries()) {
        console.log(`Processing image ${index + 1} of ${totalImages}`, { fileName: file.name, size: file.size });

        try {
          // Upload image to Cloudflare Images
          const { url, cloudflareId } = await uploadImage(file, (imageProgress) => {
            if (onProgress) {
              const overallProgress = ((index * 100) + imageProgress) / totalImages;
              onProgress(Math.round(overallProgress));
            }
          });
          
          console.log(`Image ${index + 1} uploaded successfully:`, { cloudflareId });
          
          // Store image record in database
          const [image] = await sql`
            INSERT INTO ad_images (
              ad_id,
              url,
              cloudflare_image_id,
              variant_name,
              is_primary,
              metadata,
              created_at
            ) VALUES (
              ${ad.id}::uuid,
              ${url},
              ${cloudflareId},
              ${IMAGE_VARIANTS.ORIGINAL},
              ${index === 0},
              ${JSON.stringify({
                original_filename: file.name,
                size: file.size,
                format: file.type.split('/')[1],
                width: null,
                height: null
              })}::jsonb,
              now()
            )
            RETURNING *
          `;
          
          adImages.push(image);
          console.log(`Image ${index + 1} record created:`, image);
        } catch (error: any) {
          console.error(`Error processing image ${index + 1}:`, error);
          await sql`ROLLBACK`;
          throw new Error(`Failed to upload image ${index + 1}: ${error.message}`);
        }
      }

      // Get user name
      const [user] = await sql`
        SELECT name FROM users WHERE id = ${request.userId}::uuid
      `;

      if (!user) {
        await sql`ROLLBACK`;
        throw new Error(`User ${request.userId} not found`);
      }

      await sql`COMMIT`;

      return {
        ...ad,
        images: adImages,
        userName: user.name
      };

    } catch (error: any) {
      await sql`ROLLBACK`;
      throw error;
    }
  } catch (error: any) {
    console.error('Error in createAd:', error);
    throw error;
  }
}