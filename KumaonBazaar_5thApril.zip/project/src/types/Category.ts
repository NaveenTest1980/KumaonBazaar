export interface Category {
  id: string;
  name: string;
  icon: string;
  price_label: string;
  coming_soon: boolean;
  created_at: string;
}