/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly NEON_DATABASE_URL: string;
  readonly VITE_NEON_DATABASE_URL: string;
  readonly VITE_API_URL: string;
  
  // Cloudflare Configuration
  readonly VITE_CLOUDFLARE_ACCOUNT_ID: string;
  readonly VITE_CLOUDFLARE_API_TOKEN: string;
  readonly VITE_CLOUDFLARE_IMAGE_DELIVERY_URL: string;
  
  // Supabase Configuration
  readonly VITE_SUPABASE_URL: string;
  readonly VITE_SUPABASE_ANON_KEY: string;
  
  // JWT Configuration
  readonly JWT_SECRET: string;
  readonly JWT_EXPIRY: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}