// Cloudflare configuration
export const CLOUDFLARE_CONFIG = {
  accountId: import.meta.env.VITE_CLOUDFLARE_ACCOUNT_ID,
  apiToken: import.meta.env.VITE_CLOUDFLARE_API_TOKEN,
  imageDeliveryUrl: import.meta.env.VITE_CLOUDFLARE_IMAGE_DELIVERY_URL
};