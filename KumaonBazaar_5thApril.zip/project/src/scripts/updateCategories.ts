import { neon, neonConfig } from '@neondatabase/serverless';
import * as dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Configure Neon
neonConfig.fetchConnectionCache = true;

// Get database URL from environment variable
const databaseUrl = process.env.NEON_DATABASE_URL;

if (!databaseUrl) {
  throw new Error('NEON_DATABASE_URL environment variable is not set');
}

// Initialize SQL client for script
const sql = neon(databaseUrl);

async function updateCategories() {
  try {
    console.log('Connecting to Neon database...');
    
    // Set search path to neondb schema
    await sql`SET search_path TO neondb`;
    
    console.log('Starting categories update...');
    
    // Start a transaction
    await sql`BEGIN`;
    
    try {
      // Update existing categories
      const updates = await sql`
        UPDATE categories 
        SET 
          name = CASE id
            WHEN 'books' THEN 'Books'
            WHEN 'vehicles' THEN 'Vehicles'
            WHEN 'real-estate' THEN 'Real Estate'
            WHEN 'electronics' THEN 'Electronics'
            WHEN 'jobs' THEN 'Jobs'
            WHEN 'furniture' THEN 'Furniture'
            WHEN 'fashion' THEN 'Fashion'
            WHEN 'education' THEN 'Education & Learning'
            WHEN 'hotels' THEN 'Hotels & Resorts'
            WHEN 'food' THEN 'Food & Dining'
            WHEN 'grocery' THEN 'Grocery & Supermarkets'
            WHEN 'transport' THEN 'Transport & Vehicles'
            WHEN 'events' THEN 'Events & Activities'
            WHEN 'nightlife' THEN 'Bars & Nightclubs'
            WHEN 'mobile' THEN 'Mobile & Tablets'
            WHEN 'laptops' THEN 'Laptops & Computers'
            WHEN 'electrical' THEN 'Electrical & Electronics'
            WHEN 'wedding' THEN 'Wedding & Matchmaking'
            ELSE name
          END,
          icon = CASE id
            WHEN 'books' THEN 'BookOpen'
            WHEN 'vehicles' THEN 'Car'
            WHEN 'real-estate' THEN 'Home'
            WHEN 'electronics' THEN 'Smartphone'
            WHEN 'jobs' THEN 'Briefcase'
            WHEN 'furniture' THEN 'Sofa'
            WHEN 'fashion' THEN 'ShoppingBag'
            WHEN 'education' THEN 'GraduationCap'
            WHEN 'hotels' THEN 'Hotel'
            WHEN 'food' THEN 'UtensilsCrossed'
            WHEN 'grocery' THEN 'ShoppingCart'
            WHEN 'transport' THEN 'Truck'
            WHEN 'events' THEN 'Calendar'
            WHEN 'nightlife' THEN 'Wine'
            WHEN 'mobile' THEN 'Smartphone'
            WHEN 'laptops' THEN 'Laptop'
            WHEN 'electrical' THEN 'Zap'
            WHEN 'wedding' THEN 'Heart'
            ELSE icon
          END,
          price_label = CASE id
            WHEN 'jobs' THEN 'Salary'
            WHEN 'education' THEN 'Fees'
            ELSE 'Price'
          END,
          coming_soon = CASE id
            WHEN 'jobs' THEN true
            WHEN 'wedding' THEN true
            ELSE false
          END
        WHERE id IN (
          'books', 'vehicles', 'real-estate', 'electronics', 'jobs',
          'furniture', 'fashion', 'education', 'hotels', 'food',
          'grocery', 'transport', 'events', 'nightlife', 'mobile',
          'laptops', 'electrical', 'wedding'
        )
        RETURNING *
      `;

      // Insert any missing categories
      const insertMissing = await sql`
        INSERT INTO categories (id, name, icon, price_label, coming_soon)
        VALUES
          ('books', 'Books', 'BookOpen', 'Price', false),
          ('vehicles', 'Vehicles', 'Car', 'Price', false),
          ('real-estate', 'Real Estate', 'Home', 'Price', false),
          ('electronics', 'Electronics', 'Smartphone', 'Price', false),
          ('jobs', 'Jobs', 'Briefcase', 'Salary', true),
          ('furniture', 'Furniture', 'Sofa', 'Price', false),
          ('fashion', 'Fashion', 'ShoppingBag', 'Price', false),
          ('education', 'Education & Learning', 'GraduationCap', 'Fees', false),
          ('hotels', 'Hotels & Resorts', 'Hotel', 'Price', false),
          ('food', 'Food & Dining', 'UtensilsCrossed', 'Price', false),
          ('grocery', 'Grocery & Supermarkets', 'ShoppingCart', 'Price', false),
          ('transport', 'Transport & Vehicles', 'Truck', 'Price', false),
          ('events', 'Events & Activities', 'Calendar', 'Price', false),
          ('nightlife', 'Bars & Nightclubs', 'Wine', 'Price', false),
          ('mobile', 'Mobile & Tablets', 'Smartphone', 'Price', false),
          ('laptops', 'Laptops & Computers', 'Laptop', 'Price', false),
          ('electrical', 'Electrical & Electronics', 'Zap', 'Price', false),
          ('wedding', 'Wedding & Matchmaking', 'Heart', 'Price', true)
        ON CONFLICT (id) DO NOTHING
        RETURNING *
      `;
      
      // Ensure indexes exist
      await sql`CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name)`;
      await sql`CREATE INDEX IF NOT EXISTS idx_categories_coming_soon ON categories(coming_soon)`;
      await sql`CREATE INDEX IF NOT EXISTS idx_categories_price_label ON categories(price_label)`;
      
      // Ensure RLS is enabled
      await sql`ALTER TABLE categories ENABLE ROW LEVEL SECURITY`;
      
      // Ensure RLS policy exists
      await sql`
        DO $$ 
        BEGIN
          IF NOT EXISTS (
            SELECT 1 FROM pg_policies 
            WHERE tablename = 'categories' 
            AND policyname = 'Categories are viewable by everyone'
          ) THEN
            CREATE POLICY "Categories are viewable by everyone" 
            ON categories
            FOR SELECT 
            TO public 
            USING (true);
          END IF;
        END $$;
      `;
      
      // Commit the transaction
      await sql`COMMIT`;
      
      console.log('Categories updated successfully:', updates.length);
      console.log('New categories inserted:', insertMissing.length);
      console.log('Updated categories:', updates.map(c => c.name).join(', '));
      
      process.exit(0);
    } catch (error) {
      // Rollback on error
      await sql`ROLLBACK`;
      throw error;
    }
  } catch (error) {
    console.error('Error updating categories:', error);
    process.exit(1);
  }
}

updateCategories().catch(error => {
  console.error('Unhandled error:', error);
  process.exit(1);
});