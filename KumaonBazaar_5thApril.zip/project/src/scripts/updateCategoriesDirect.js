import { neon } from '@neondatabase/serverless';
import * as dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Get database URL from environment variable
const databaseUrl = process.env.NEON_DATABASE_URL;

if (!databaseUrl) {
  throw new Error('NEON_DATABASE_URL environment variable is not set');
}

// Initialize SQL client
const sql = neon(databaseUrl);

async function updateCategories() {
  try {
    console.log('Connecting to Neon database...');
    
    // Set search path to neondb schema
    await sql`SET search_path TO neondb`;
    
    console.log('Starting categories update...');
    
    // Start a transaction
    await sql`BEGIN`;
    
    try {
      // First, ensure the categories table exists with the correct structure
      await sql`
        CREATE TABLE IF NOT EXISTS categories (
          id text PRIMARY KEY,
          name text NOT NULL,
          icon text NOT NULL,
          price_label text DEFAULT 'Price',
          coming_soon boolean DEFAULT false,
          created_at timestamptz DEFAULT CURRENT_TIMESTAMP
        )
      `;

      // Update existing categories
      const updates = await sql`
        INSERT INTO categories (id, name, icon, price_label, coming_soon)
        VALUES
          ('books', 'Books', 'BookOpen', 'Price', false),
          ('vehicles', 'Vehicles', 'Car', 'Price', false),
          ('real-estate', 'Real Estate', 'Home', 'Price', false),
          ('electronics', 'Electronics', 'Smartphone', 'Price', false),
          ('jobs', 'Jobs', 'Briefcase', 'Salary', true),
          ('furniture', 'Furniture', 'Sofa', 'Price', false),
          ('fashion', 'Fashion', 'ShoppingBag', 'Price', false),
          ('education', 'Education & Learning', 'GraduationCap', 'Fees', false),
          ('hotels', 'Hotels & Resorts', 'Hotel', 'Price', false),
          ('food', 'Food & Dining', 'UtensilsCrossed', 'Price', false),
          ('grocery', 'Grocery & Supermarkets', 'ShoppingCart', 'Price', false),
          ('transport', 'Transport & Vehicles', 'Truck', 'Price', false),
          ('events', 'Events & Activities', 'Calendar', 'Price', false),
          ('nightlife', 'Bars & Nightclubs', 'Wine', 'Price', false),
          ('mobile', 'Mobile & Tablets', 'Smartphone', 'Price', false),
          ('laptops', 'Laptops & Computers', 'Laptop', 'Price', false),
          ('electrical', 'Electrical & Electronics', 'Zap', 'Price', false),
          ('wedding', 'Wedding & Matchmaking', 'Heart', 'Price', true)
        ON CONFLICT (id) DO UPDATE SET
          name = EXCLUDED.name,
          icon = EXCLUDED.icon,
          price_label = EXCLUDED.price_label,
          coming_soon = EXCLUDED.coming_soon
        RETURNING *
      `;
      
      // Ensure indexes exist
      await sql`CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name)`;
      await sql`CREATE INDEX IF NOT EXISTS idx_categories_coming_soon ON categories(coming_soon)`;
      await sql`CREATE INDEX IF NOT EXISTS idx_categories_price_label ON categories(price_label)`;
      
      // Ensure RLS is enabled
      await sql`ALTER TABLE categories ENABLE ROW LEVEL SECURITY`;
      
      // Ensure RLS policy exists
      await sql`
        DO $$ 
        BEGIN
          IF NOT EXISTS (
            SELECT 1 FROM pg_policies 
            WHERE tablename = 'categories' 
            AND policyname = 'Categories are viewable by everyone'
          ) THEN
            CREATE POLICY "Categories are viewable by everyone" 
            ON categories
            FOR SELECT 
            TO public 
            USING (true);
          END IF;
        END $$;
      `;
      
      // Commit the transaction
      await sql`COMMIT`;
      
      console.log('Categories updated successfully:', updates.length);
      console.log('Updated categories:', updates.map(c => c.name).join(', '));
      
      process.exit(0);
    } catch (error) {
      // Rollback on error
      await sql`ROLLBACK`;
      throw error;
    }
  } catch (error) {
    console.error('Error updating categories:', error);
    process.exit(1);
  }
}

updateCategories().catch(error => {
  console.error('Unhandled error:', error);
  process.exit(1);
});