import { useLocation, useNavigate } from 'react-router-dom';

export function usePreview() {
  const location = useLocation();
  const navigate = useNavigate();
  const searchParams = new URLSearchParams(location.search);
  const isPreview = searchParams.get('preview') === 'true';

  const enablePreview = () => {
    const newParams = new URLSearchParams(searchParams);
    newParams.set('preview', 'true');
    navigate(`${location.pathname}?${newParams.toString()}`);
  };

  const disablePreview = () => {
    const newParams = new URLSearchParams(searchParams);
    newParams.delete('preview');
    navigate(`${location.pathname}${newParams.toString() ? `?${newParams.toString()}` : ''}`);
  };

  const togglePreview = () => {
    if (isPreview) {
      disablePreview();
    } else {
      enablePreview();
    }
  };

  return {
    isPreview,
    enablePreview,
    disablePreview,
    togglePreview
  };
}