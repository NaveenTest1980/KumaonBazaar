import React, { useState } from 'react';
import { X, CreditCard, Smartphone, Check, Loader } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentSuccess: (paymentMethod: string, paymentId?: string) => void;
  amount: number;
  title: string;
  description: string;
  processing?: boolean;
  success?: boolean;
}

const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  onPaymentSuccess,
  amount,
  title,
  description,
  processing = false,
  success = false
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'paytm' | 'upi' | 'card'>('paytm');
  
  if (!isOpen) return null;
  
  const handlePayment = () => {
    // Generate a mock payment ID
    const paymentId = `pay_${Math.random().toString(36).substring(2, 15)}`;
    onPaymentSuccess(paymentMethod, paymentId);
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg max-w-md w-full p-6 relative">
        {/* Close button */}
        {!processing && !success && (
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
          >
            <X size={20} />
          </button>
        )}
        
        {/* Payment processing or success state */}
        {(processing || success) ? (
          <div className="flex flex-col items-center justify-center py-8">
            {processing && (
              <>
                <Loader className="h-12 w-12 text-orange-500 animate-spin mb-4" />
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Processing Payment</h3>
                <p className="text-gray-600 text-center">Please wait while we process your payment...</p>
              </>
            )}
            
            {success && (
              <>
                <div className="bg-green-100 p-3 rounded-full mb-4">
                  <Check className="h-10 w-10 text-green-500" />
                </div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Payment Successful!</h3>
                <p className="text-gray-600 text-center">Your phone number will be visible for the next 30 days.</p>
              </>
            )}
          </div>
        ) : (
          <>
            {/* Payment form */}
            <div className="mb-6">
              <h2 className="text-xl font-bold text-gray-800 mb-2">{title}</h2>
              <p className="text-gray-600">{description}</p>
            </div>
            
            <div className="mb-6">
              <p className="text-2xl font-bold text-orange-600 mb-1">₹{amount.toFixed(2)}</p>
              <p className="text-sm text-gray-500">One-time payment</p>
            </div>
            
            <div className="mb-6">
              <h3 className="text-sm font-medium text-gray-700 mb-3">Select Payment Method</h3>
              
              <div className="space-y-3">
                <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="paytm"
                    checked={paymentMethod === 'paytm'}
                    onChange={() => setPaymentMethod('paytm')}
                    className="h-4 w-4 text-orange-500 focus:ring-orange-500"
                  />
                  <div className="ml-3 flex items-center">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/4/42/Paytm_logo.png" alt="Paytm" className="h-6 mr-2" />
                    <span className="font-medium">Paytm</span>
                  </div>
                </label>
                
                <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="upi"
                    checked={paymentMethod === 'upi'}
                    onChange={() => setPaymentMethod('upi')}
                    className="h-4 w-4 text-orange-500 focus:ring-orange-500"
                  />
                  <div className="ml-3 flex items-center">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/UPI-Logo-vector.svg" alt="UPI" className="h-6 mr-2" />
                    <span className="font-medium">UPI</span>
                  </div>
                </label>
                
                <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="card"
                    checked={paymentMethod === 'card'}
                    onChange={() => setPaymentMethod('card')}
                    className="h-4 w-4 text-orange-500 focus:ring-orange-500"
                  />
                  <div className="ml-3 flex items-center">
                    <CreditCard className="h-5 w-5 text-gray-600 mr-2" />
                    <span className="font-medium">Credit/Debit Card</span>
                  </div>
                </label>
              </div>
            </div>
            
            {paymentMethod === 'paytm' && (
              <div className="mb-6 p-4 bg-blue-50 rounded-lg">
                <h4 className="text-sm font-medium text-blue-800 mb-2">Scan QR Code to Pay</h4>
                <div className="flex justify-center">
                  <img 
                    src="https://upload.wikimedia.org/wikipedia/commons/d/d0/QR_code_for_mobile_English_Wikipedia.svg" 
                    alt="Paytm QR Code" 
                    className="h-48 w-48"
                  />
                </div>
                <p className="text-xs text-blue-600 text-center mt-2">
                  UPI ID: paytmqr66ec05@ptys
                </p>
              </div>
            )}
            
            <button
              onClick={handlePayment}
              className="w-full bg-orange-500 text-white py-3 px-4 rounded-lg font-medium hover:bg-orange-600 transition flex items-center justify-center"
            >
              {paymentMethod === 'paytm' ? (
                <>
                  <Smartphone className="mr-2 h-5 w-5" />
                  I've made the payment
                </>
              ) : (
                <>
                  Pay ₹{amount.toFixed(2)}
                </>
              )}
            </button>
            
            <p className="text-xs text-gray-500 text-center mt-4">
              By proceeding, you agree to our terms of service and privacy policy.
            </p>
          </>
        )}
      </div>
    </div>
  );
};

export default PaymentModal;