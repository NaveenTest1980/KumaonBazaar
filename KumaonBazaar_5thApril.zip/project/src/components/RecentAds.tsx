import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { getRecentAds } from '../services/adService';
import AdCard from './AdCard';
import { Ad } from '../types/Ad';
import { Loader, Filter, ArrowUpDown } from 'lucide-react';
import { kumaonDistricts } from '../data/locations';

const RecentAds: React.FC = () => {
  const [searchParams] = useSearchParams();
  const districtId = searchParams.get('district');

  const [ads, setAds] = useState<Ad[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [sortBy, setSortBy] = useState<'newest' | 'price-low' | 'price-high'>('newest');
  const [priceRange, setPriceRange] = useState<{ min: number; max: number | null }>({ min: 0, max: null });
  const ITEMS_PER_PAGE = 20;

  useEffect(() => {
    const fetchAds = async () => {
      try {
        setLoading(true);
        const { ads: recentAds, total } = await getRecentAds(page, ITEMS_PER_PAGE, districtId);

        // Apply sorting
        let sortedAds = [...recentAds];
        switch (sortBy) {
          case 'price-low':
            sortedAds.sort((a, b) => a.price - b.price);
            break;
          case 'price-high':
            sortedAds.sort((a, b) => b.price - a.price);
            break;
          default:
            sortedAds.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        }

        // Apply price filter
        if (priceRange.min > 0 || priceRange.max) {
          sortedAds = sortedAds.filter(ad => {
            const price = ad.price;
            if (priceRange.min > 0 && price < priceRange.min) return false;
            if (priceRange.max && price > priceRange.max) return false;
            return true;
          });
        }

        setAds(sortedAds);
        setTotalPages(Math.ceil(total / ITEMS_PER_PAGE));
      } catch (err: any) {
        console.error('Error fetching recent ads:', err);
        setError(err.message || 'Failed to load recent ads');
      } finally {
        setLoading(false);
      }
    };

    fetchAds();
  }, [page, districtId, sortBy, priceRange]);

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortBy(e.target.value as 'newest' | 'price-low' | 'price-high');
  };

  const handlePriceRangeChange = (min: number, max: number | null) => {
    setPriceRange({ min, max });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-48">
        <Loader className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
        {error}
      </div>
    );
  }

  if (ads.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-lg shadow-md">
        <p className="text-lg text-gray-600 mb-4">
          {districtId 
            ? `No ads found in ${kumaonDistricts.find(d => d.id === districtId)?.name || 'this district'}`
            : 'No ads found'
          }
        </p>
        <Link
          to="/post-ad"
          className="inline-block bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-6 py-2 rounded-lg font-medium hover:from-emerald-600 hover:to-teal-600 transition shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
        >
          Post Your First Ad
        </Link>
      </div>
    );
  }

  return (
    <div>
      {/* Filters and Sort */}
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center">
              <Filter className="h-5 w-5 text-gray-500 mr-2" />
              <span className="text-gray-700 font-medium">Price Range:</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="number"
                placeholder="Min"
                className="w-24 px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-emerald-500"
                onChange={(e) => handlePriceRangeChange(Number(e.target.value), priceRange.max)}
              />
              <span>-</span>
              <input
                type="number"
                placeholder="Max"
                className="w-24 px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-emerald-500"
                onChange={(e) => handlePriceRangeChange(priceRange.min, Number(e.target.value) || null)}
              />
            </div>
          </div>
          
          <div className="flex items-center">
            <ArrowUpDown className="h-5 w-5 text-gray-500 mr-2" />
            <select
              value={sortBy}
              onChange={handleSortChange}
              className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="newest">Newest First</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Ads Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {ads.map((ad) => (
          <Link 
            key={ad.id} 
            to={`/ad/${ad.id}`}
            state={{ from: '/', label: 'Back to Home' }}
          >
            <AdCard 
              id={ad.id}
              title={ad.title}
              price={ad.price}
              location={ad.location}
              category={ad.category_id}
              createdAt={ad.created_at}
              imageUrl={ad.images?.[0]?.url}
            />
          </Link>
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-8 flex justify-center space-x-2">
          <button
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-4 py-2 border rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
          >
            Previous
          </button>
          <span className="px-4 py-2 text-gray-700">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="px-4 py-2 border rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
};

export default RecentAds;