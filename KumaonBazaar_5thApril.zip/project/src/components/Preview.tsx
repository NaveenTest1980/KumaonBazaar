import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

interface PreviewProps {
  children: React.ReactNode;
}

const Preview: React.FC<PreviewProps> = ({ children }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const searchParams = new URLSearchParams(location.search);
  const isPreview = searchParams.get('preview') === 'true';

  const exitPreview = () => {
    searchParams.delete('preview');
    navigate(`${location.pathname}${searchParams.toString() ? `?${searchParams.toString()}` : ''}`);
  };

  if (!isPreview) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen relative">
      {/* Preview Banner */}
      <div 
        className="fixed top-0 left-0 right-0 bg-gradient-to-r from-indigo-600 to-violet-600 text-white py-2 px-4 text-center z-[9999] shadow-lg"
        style={{ 
          backdropFilter: 'blur(8px)',
          WebkitBackdropFilter: 'blur(8px)'
        }}
      >
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center">
            <div className="relative">
              <div className="absolute inset-0 animate-ping rounded-full bg-white/50"></div>
              <div className="relative h-2 w-2 rounded-full bg-white"></div>
            </div>
            <span className="ml-2 text-sm font-medium">Preview Mode</span>
          </div>
          <button
            onClick={exitPreview}
            className="text-sm bg-white/10 hover:bg-white/20 text-white px-3 py-1 rounded-full transition-colors"
          >
            Exit Preview
          </button>
        </div>
      </div>

      {/* Content Container with padding for preview banner */}
      <div className="pt-10">
        {children}
      </div>

      {/* Preview Overlay Effects */}
      <div className="fixed inset-0 pointer-events-none z-[-1]">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-indigo-500/5"></div>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(99,102,241,0.05),transparent)]"></div>
      </div>
    </div>
  );
};

export default Preview;