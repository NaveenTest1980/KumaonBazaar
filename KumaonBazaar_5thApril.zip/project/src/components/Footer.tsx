import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Mail, MapPin, Compass, Heart } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* About */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 text-transparent bg-clip-text">
              About Kumaon Bazaar
            </h3>
            <p className="text-gray-300 leading-relaxed">
              The premier marketplace for the Kumaon region of Uttarakhand. Buy, sell, and exchange goods locally.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://facebook.com/kumaonbazaar" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-gray-400 hover:text-emerald-400 transition-colors"
              >
                <Facebook size={20} />
              </a>
              <a 
                href="https://twitter.com/kumaonbazaar" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-gray-400 hover:text-emerald-400 transition-colors"
              >
                <Twitter size={20} />
              </a>
              <a 
                href="https://instagram.com/kumaonbazaar" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-gray-400 hover:text-emerald-400 transition-colors"
              >
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 text-transparent bg-clip-text">
              Quick Links
            </h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-gray-400 hover:text-emerald-400 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/post-ad" className="text-gray-400 hover:text-emerald-400 transition-colors">
                  Post an Ad
                </Link>
              </li>
              <li>
                <Link to="/category/books" className="text-gray-400 hover:text-emerald-400 transition-colors">
                  Student Books
                </Link>
              </li>
              <li>
                <Link to="/profile" className="text-gray-400 hover:text-emerald-400 transition-colors">
                  My Account
                </Link>
              </li>
              <li>
                <a 
                  href="https://ukdaju.com/" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex items-center text-gray-400 hover:text-emerald-400 transition-colors"
                >
                  <Compass size={16} className="mr-2" />
                  <span>Uttarakhand Tourism</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Kumaon Districts */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 text-transparent bg-clip-text">
              Kumaon Districts
            </h3>
            <ul className="space-y-3">
              <li>
                <Link to="/?district=almora" className="text-gray-400 hover:text-emerald-400 transition-colors">
                  Almora
                </Link>
              </li>
              <li>
                <Link to="/?district=bageshwar" className="text-gray-400 hover:text-emerald-400 transition-colors">
                  Bageshwar
                </Link>
              </li>
              <li>
                <Link to="/?district=champawat" className="text-gray-400 hover:text-emerald-400 transition-colors">
                  Champawat
                </Link>
              </li>
              <li>
                <Link to="/?district=nainital" className="text-gray-400 hover:text-emerald-400 transition-colors">
                  Nainital
                </Link>
              </li>
              <li>
                <Link to="/?district=pithoragarh" className="text-gray-400 hover:text-emerald-400 transition-colors">
                  Pithoragarh
                </Link>
              </li>
              <li>
                <Link to="/?district=udhamsingh" className="text-gray-400 hover:text-emerald-400 transition-colors">
                  Udham Singh Nagar
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 text-transparent bg-clip-text">
              Contact Us
            </h3>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <MapPin size={20} className="flex-shrink-0 mt-1 text-emerald-400" />
                <span className="text-gray-300">Kumaon Region, Uttarakhand, India</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail size={20} className="flex-shrink-0 text-emerald-400" />
                <a 
                  href="mailto:kumaonbazaar1@gmail.com" 
                  className="text-gray-300 hover:text-emerald-400 transition-colors"
                >
                  kumaonbazaar1@gmail.com
                </a>
              </li>
              <li className="flex items-center space-x-3">
                <Compass size={20} className="flex-shrink-0 text-emerald-400" />
                <a 
                  href="https://ukdaju.com/" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-gray-300 hover:text-emerald-400 transition-colors"
                >
                  Visit Uttarakhand Tourism
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-700">
          <div className="text-center space-y-4">
            <p className="text-gray-400">
              &copy; {new Date().getFullYear()} Kumaon Bazaar - Kumaon's Premier Marketplace. All rights reserved.
            </p>
            <p className="text-gray-500 flex items-center justify-center text-sm">
              Made with <Heart size={14} className="mx-1 text-emerald-400" /> in Uttarakhand
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;