import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { AlertCircle, ExternalLink, Filter, ArrowUpDown } from 'lucide-react';
import AdCard from '../components/AdCard';
import { getAdsByCategory } from '../services/adService';
import { Ad } from '../types/Ad';

const CategoryPage = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const navigate = useNavigate();
  const [ads, setAds] = useState<Ad[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'newest' | 'price-low' | 'price-high'>('newest');
  const [priceRange, setPriceRange] = useState<{ min: number; max: number | null }>({ min: 0, max: null });

  useEffect(() => {
    const fetchAds = async () => {
      if (!categoryId) return;
      
      setLoading(true);
      setError(null);
      
      try {
        // Handle restricted categories
        if (categoryId === 'jobs') {
          window.location.href = 'https://kumaonjobs.com';
          return;
        }
        if (categoryId === 'wedding') {
          window.location.href = 'https://kumaonmatrimony.com';
          return;
        }

        const result = await getAdsByCategory(categoryId, 1, 20);
        
        // Apply sorting
        let sortedAds = [...result.ads];
        switch (sortBy) {
          case 'price-low':
            sortedAds.sort((a, b) => a.price - b.price);
            break;
          case 'price-high':
            sortedAds.sort((a, b) => b.price - a.price);
            break;
          default:
            sortedAds.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        }

        // Apply price filter
        if (priceRange.min > 0 || priceRange.max) {
          sortedAds = sortedAds.filter(ad => {
            const price = ad.price;
            if (priceRange.min > 0 && price < priceRange.min) return false;
            if (priceRange.max && price > priceRange.max) return false;
            return true;
          });
        }

        setAds(sortedAds);
      } catch (error: any) {
        console.error('Error fetching ads:', error);
        setError(error.message || 'Failed to load ads');
      } finally {
        setLoading(false);
      }
    };

    fetchAds();
  }, [categoryId, sortBy, priceRange]);

  const handleSortChange = useCallback((e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortBy(e.target.value as 'newest' | 'price-low' | 'price-high');
  }, []);

  const handlePriceRangeChange = useCallback((min: number, max: number | null) => {
    setPriceRange({ min, max });
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-lg">
          <div className="flex items-center">
            <AlertCircle className="h-6 w-6 text-red-500 mr-3" />
            <div>
              <h3 className="text-lg font-medium text-red-800">Error</h3>
              <p className="text-red-700 mt-1">{error}</p>
              {(categoryId === 'jobs' || categoryId === 'wedding') && (
                <a 
                  href={categoryId === 'jobs' ? 'https://kumaonjobs.com' : 'https://kumaonmatrimony.com'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center mt-3 text-red-700 hover:text-red-800 font-medium"
                >
                  Visit Website
                  <ExternalLink className="ml-1 h-4 w-4" />
                </a>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Filters and Sort */}
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center">
              <Filter className="h-5 w-5 text-gray-500 mr-2" />
              <span className="text-gray-700 font-medium">Price Range:</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="number"
                placeholder="Min"
                className="w-24 px-2 py-1 border rounded"
                onChange={(e) => handlePriceRangeChange(Number(e.target.value), priceRange.max)}
              />
              <span>-</span>
              <input
                type="number"
                placeholder="Max"
                className="w-24 px-2 py-1 border rounded"
                onChange={(e) => handlePriceRangeChange(priceRange.min, Number(e.target.value) || null)}
              />
            </div>
          </div>
          
          <div className="flex items-center">
            <ArrowUpDown className="h-5 w-5 text-gray-500 mr-2" />
            <select
              value={sortBy}
              onChange={handleSortChange}
              className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="newest">Newest First</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
          </div>
        </div>
      </div>

      {ads.length === 0 ? (
        <div className="text-center bg-white rounded-lg shadow-md p-8">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">No ads found in this category</h2>
          <Link
            to="/post-ad"
            className="inline-block bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-6 py-2 rounded-lg font-medium hover:from-emerald-600 hover:to-teal-600 transition"
          >
            Post the First Ad
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {ads.map((ad) => (
            <Link 
              key={ad.id} 
              to={`/ad/${ad.id}`}
              state={{ from: `/category/${categoryId}`, label: 'Back to Category' }}
            >
              <AdCard 
                id={ad.id}
                title={ad.title}
                price={ad.price}
                location={ad.location}
                category={ad.category_id}
                createdAt={ad.created_at}
              />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};

export default CategoryPage;