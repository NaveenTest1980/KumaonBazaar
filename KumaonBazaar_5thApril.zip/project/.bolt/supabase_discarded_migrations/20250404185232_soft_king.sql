/*
  # Add Authentication Schema

  1. Purpose
    - Set up authentication tables and policies
    - Enable Supabase Auth

  2. Changes
    - Enable auth schema
    - Add auth policies for users table
    - Add auth policies for ads table
    - Add auth policies for ad_images table
*/

-- Enable auth schema
CREATE SCHEMA IF NOT EXISTS auth;

-- Update users table policies
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Update ads table policies
ALTER TABLE ads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read active ads"
  ON ads
  FOR SELECT
  TO public
  USING (status = 'Active');

CREATE POLICY "Users can create ads"
  ON ads
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own ads"
  ON ads
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own ads"
  ON ads
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Update ad_images table policies
ALTER TABLE ad_images ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view ad images"
  ON ad_images
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can manage own ad images"
  ON ad_images
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM ads
      WHERE ads.id = ad_images.ad_id
      AND ads.user_id = auth.uid()
    )
  );