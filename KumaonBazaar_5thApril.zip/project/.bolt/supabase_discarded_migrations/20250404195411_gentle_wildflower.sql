/*
  # Update Schema for Cloudflare Images Integration

  1. Changes
    - Update ad_images table to store Cloudflare Images metadata
    - Add variant_name for different image sizes
    - Add metadata JSONB field for image details

  2. Security
    - Maintain existing RLS policies
    - Add indexes for efficient queries
*/

-- Update ad_images table
ALTER TABLE ad_images
  -- Rename cloudflare_id to cloudflare_image_id for clarity
  RENAME COLUMN cloudflare_id TO cloudflare_image_id;

-- Add new columns
ALTER TABLE ad_images
  ADD COLUMN IF NOT EXISTS variant_name text DEFAULT 'public',
  ADD COLUMN IF NOT EXISTS metadata jsonb DEFAULT '{}';

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_ad_images_cloudflare_image_id 
  ON ad_images(cloudflare_image_id);

CREATE INDEX IF NOT EXISTS idx_ad_images_variant_name 
  ON ad_images(variant_name);

-- Add comments
COMMENT ON COLUMN ad_images.cloudflare_image_id IS 'Cloudflare Images unique identifier';
COMMENT ON COLUMN ad_images.variant_name IS 'Cloudflare Images variant name (e.g., public, thumbnail)';
COMMENT ON COLUMN ad_images.metadata IS 'Image metadata including dimensions, size, and format';