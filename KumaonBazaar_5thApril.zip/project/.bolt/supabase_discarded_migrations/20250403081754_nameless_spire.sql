/*
  # Update Categories Table
  
  1. Changes
    - Drop and recreate categories table with proper schema
    - Insert all categories with correct data
    - Add necessary indexes
    - Enable RLS with proper policies
    
  2. Security
    - Transaction to ensure atomic updates
    - RLS enabled with public read access
*/

-- Set search path
SET search_path TO neondb;

-- Start transaction
BEGIN;

-- Drop and recreate categories table
DROP TABLE IF EXISTS categories CASCADE;

CREATE TABLE categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  icon text NOT NULL,
  price_label text DEFAULT 'Price',
  coming_soon boolean DEFAULT false,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

-- Insert all categories with proper price labels and coming soon status
INSERT INTO categories (id, name, icon, price_label, coming_soon)
VALUES
  ('books', 'Books', 'BookOpen', 'Price', false),
  ('vehicles', 'Vehicles', 'Car', 'Price', false),
  ('real-estate', 'Real Estate', 'Home', 'Price', false),
  ('electronics', 'Electronics', 'Smartphone', 'Price', false),
  ('jobs', 'Jobs', 'Briefcase', 'Salary', true),
  ('furniture', 'Furniture', 'Sofa', 'Price', false),
  ('fashion', 'Fashion', 'ShoppingBag', 'Price', false),
  ('education', 'Education & Learning', 'GraduationCap', 'Fees', false),
  ('hotels', 'Hotels & Resorts', 'Hotel', 'Price', false),
  ('food', 'Food & Dining', 'UtensilsCrossed', 'Price', false),
  ('grocery', 'Grocery & Supermarkets', 'ShoppingCart', 'Price', false),
  ('transport', 'Transport & Vehicles', 'Truck', 'Price', false),
  ('events', 'Events & Activities', 'Calendar', 'Price', false),
  ('nightlife', 'Bars & Nightclubs', 'Wine', 'Price', false),
  ('mobile', 'Mobile & Tablets', 'Smartphone', 'Price', false),
  ('laptops', 'Laptops & Computers', 'Laptop', 'Price', false),
  ('electrical', 'Electrical & Electronics', 'Zap', 'Price', false),
  ('wedding', 'Wedding & Matchmaking', 'Heart', 'Price', true);

-- Create indexes for better performance
CREATE INDEX idx_categories_name ON categories(name);
CREATE INDEX idx_categories_coming_soon ON categories(coming_soon);
CREATE INDEX idx_categories_price_label ON categories(price_label);

-- Enable RLS
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'categories' 
    AND policyname = 'Categories are viewable by everyone'
  ) THEN
    CREATE POLICY "Categories are viewable by everyone" 
      ON categories
      FOR SELECT 
      TO public 
      USING (true);
  END IF;
END $$;

COMMIT;