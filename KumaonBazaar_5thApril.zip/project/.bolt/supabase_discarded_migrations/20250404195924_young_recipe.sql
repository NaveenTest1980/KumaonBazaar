/*
  # Update Insert Scripts for Ads and Ad Images

  1. Tables Structure
    - ads
      - Core ad information
      - User reference
      - Status and moderation flags
      - Phone number visibility
    - ad_images
      - Image metadata
      - Cloudflare Images integration
      - Primary image flag

  2. Insert Functions
    - create_ad(): Creates new ad with all required fields
    - add_ad_image(): Adds image to existing ad
*/

-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create ads table if not exists
CREATE TABLE IF NOT EXISTS ads (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  description text NOT NULL,
  price numeric NOT NULL,
  category_id text NOT NULL,
  location text NOT NULL,
  district_id text NOT NULL,
  town_id text NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  featured boolean DEFAULT false,
  needs_moderation boolean DEFAULT false,
  phone_number text,
  phone_number_visible boolean DEFAULT false,
  phone_number_expiry_date timestamptz,
  status text DEFAULT 'Active' CHECK (status IN ('Active', 'Pending', 'Rejected', 'Expired', 'Sold'))
);

-- Create ad_images table if not exists
CREATE TABLE IF NOT EXISTS ad_images (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  ad_id uuid REFERENCES ads(id) ON DELETE CASCADE,
  url text NOT NULL,
  cloudflare_image_id text NOT NULL,
  variant_name text DEFAULT 'public',
  is_primary boolean DEFAULT false,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Function to create a new ad
CREATE OR REPLACE FUNCTION create_ad(
  p_title text,
  p_description text,
  p_price numeric,
  p_category_id text,
  p_location text,
  p_district_id text,
  p_town_id text,
  p_user_id uuid,
  p_phone_number text DEFAULT NULL,
  p_featured boolean DEFAULT false
) RETURNS ads AS $$
DECLARE
  v_ad ads;
BEGIN
  -- Insert new ad
  INSERT INTO ads (
    title,
    description,
    price,
    category_id,
    location,
    district_id,
    town_id,
    user_id,
    phone_number,
    featured,
    status,
    needs_moderation,
    phone_number_visible,
    created_at,
    updated_at
  ) VALUES (
    p_title,
    p_description,
    p_price,
    p_category_id,
    p_location,
    p_district_id,
    p_town_id,
    p_user_id,
    p_phone_number,
    p_featured,
    'Active',
    false,
    false,
    now(),
    now()
  ) RETURNING * INTO v_ad;

  RETURN v_ad;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to add an image to an ad
CREATE OR REPLACE FUNCTION add_ad_image(
  p_ad_id uuid,
  p_url text,
  p_cloudflare_image_id text,
  p_is_primary boolean DEFAULT false,
  p_variant_name text DEFAULT 'public',
  p_metadata jsonb DEFAULT '{}'::jsonb
) RETURNS ad_images AS $$
DECLARE
  v_image ad_images;
BEGIN
  -- Insert new image
  INSERT INTO ad_images (
    ad_id,
    url,
    cloudflare_image_id,
    is_primary,
    variant_name,
    metadata,
    created_at
  ) VALUES (
    p_ad_id,
    p_url,
    p_cloudflare_image_id,
    p_is_primary,
    p_variant_name,
    p_metadata,
    now()
  ) RETURNING * INTO v_image;

  RETURN v_image;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Enable RLS
ALTER TABLE ads ENABLE ROW LEVEL SECURITY;
ALTER TABLE ad_images ENABLE ROW LEVEL SECURITY;

-- RLS Policies for ads
CREATE POLICY "Anyone can view active ads" ON ads
  FOR SELECT TO public
  USING (status = 'Active');

CREATE POLICY "Users can manage own ads" ON ads
  FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for ad_images
CREATE POLICY "Anyone can view ad images" ON ad_images
  FOR SELECT TO public
  USING (true);

CREATE POLICY "Users can manage images of own ads" ON ad_images
  FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM ads
    WHERE ads.id = ad_images.ad_id
    AND ads.user_id = auth.uid()
  ));

-- Indexes
CREATE INDEX IF NOT EXISTS idx_ads_user_id ON ads(user_id);
CREATE INDEX IF NOT EXISTS idx_ads_category_id ON ads(category_id);
CREATE INDEX IF NOT EXISTS idx_ads_status ON ads(status);
CREATE INDEX IF NOT EXISTS idx_ad_images_ad_id ON ad_images(ad_id);
CREATE INDEX IF NOT EXISTS idx_ad_images_cloudflare_id ON ad_images(cloudflare_image_id);

/*
Example usage:

-- Create a new ad
SELECT create_ad(
  'Example Ad Title',
  'Ad description here',
  1000.00,
  'electronics',
  'Nainital, Uttarakhand',
  'nainital',
  'nainital-city',
  'user-uuid-here',
  '+1234567890',
  false
);

-- Add an image to the ad
SELECT add_ad_image(
  'ad-uuid-here',
  'https://imagedelivery.net/account-hash/image-id/public',
  'cloudflare-image-id',
  true,
  'public',
  '{"width": 800, "height": 600, "format": "jpeg", "size": 123456}'
);
*/