/*
  # Update Insert Scripts for Ads and Ad Images

  1. Purpose
    - Ensure all columns are properly handled during inserts
    - Add validation checks for required fields
    - Set appropriate default values

  2. Tables
    - ads
      - All columns with proper defaults and constraints
    - ad_images
      - Updated schema with Cloudflare Images metadata
      - Proper defaults and constraints

  3. Security
    - Maintain existing RLS policies
*/

-- Function to validate phone number format
CREATE OR REPLACE FUNCTION validate_phone_number(phone text)
RETURNS boolean AS $$
BEGIN
  RETURN phone IS NULL OR phone ~ '^\+?[0-9]{10,}$';
END;
$$ LANGUAGE plpgsql;

-- Add check constraint for phone number format
ALTER TABLE ads
  DROP CONSTRAINT IF EXISTS valid_phone_number,
  ADD CONSTRAINT valid_phone_number 
    CHECK (validate_phone_number(phone_number));

-- Create function for inserting ads
CREATE OR REPLACE FUNCTION insert_ad(
  p_title text,
  p_description text,
  p_price numeric,
  p_category_id text,
  p_location text,
  p_district_id text,
  p_town_id text,
  p_user_id uuid,
  p_phone_number text DEFAULT NULL,
  p_featured boolean DEFAULT false
) RETURNS ads AS $$
DECLARE
  v_ad ads;
BEGIN
  -- Validate inputs
  IF NOT validate_phone_number(p_phone_number) THEN
    RAISE EXCEPTION 'Invalid phone number format';
  END IF;

  -- Insert ad with all columns
  INSERT INTO ads (
    title,
    description,
    price,
    category_id,
    location,
    district_id,
    town_id,
    user_id,
    phone_number,
    featured,
    status,
    needs_moderation,
    phone_number_visible,
    created_at,
    updated_at
  ) VALUES (
    p_title,
    p_description,
    p_price,
    p_category_id,
    p_location,
    p_district_id,
    p_town_id,
    p_user_id,
    p_phone_number,
    p_featured,
    'Active',  -- Default status
    false,     -- Default needs_moderation
    false,     -- Default phone_number_visible
    now(),     -- created_at
    now()      -- updated_at
  ) RETURNING * INTO v_ad;

  RETURN v_ad;
END;
$$ LANGUAGE plpgsql;

-- Create function for inserting ad images
CREATE OR REPLACE FUNCTION insert_ad_image(
  p_ad_id uuid,
  p_url text,
  p_cloudflare_image_id text,
  p_is_primary boolean DEFAULT false,
  p_variant_name text DEFAULT 'public',
  p_metadata jsonb DEFAULT '{}'::jsonb
) RETURNS ad_images AS $$
DECLARE
  v_image ad_images;
BEGIN
  -- Insert image with all columns
  INSERT INTO ad_images (
    ad_id,
    url,
    cloudflare_image_id,
    is_primary,
    variant_name,
    metadata,
    created_at
  ) VALUES (
    p_ad_id,
    p_url,
    p_cloudflare_image_id,
    p_is_primary,
    p_variant_name,
    p_metadata,
    now()
  ) RETURNING * INTO v_image;

  RETURN v_image;
END;
$$ LANGUAGE plpgsql;

-- Example usage:
COMMENT ON FUNCTION insert_ad IS 'Insert a new ad with all required fields and proper defaults';
COMMENT ON FUNCTION insert_ad_image IS 'Insert a new ad image with Cloudflare Images metadata';

/*
Example usage:

-- Insert an ad
SELECT * FROM insert_ad(
  'Example Ad',
  'Description here',
  1000.00,
  'electronics',
  'Nainital',
  'nainital',
  'nainital-city',
  'user-uuid-here',
  '+1234567890',
  false
);

-- Insert an ad image
SELECT * FROM insert_ad_image(
  'ad-uuid-here',
  'https://imagedelivery.net/account-hash/image-id/public',
  'cloudflare-image-id',
  true,
  'public',
  '{"width": 800, "height": 600, "format": "jpeg", "size": 123456}'
);
*/