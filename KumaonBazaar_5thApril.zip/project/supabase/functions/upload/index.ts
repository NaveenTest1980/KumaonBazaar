import { createClient } from "npm:@supabase/supabase-js@2.39.7";
import { v4 as uuidv4 } from "npm:uuid@9.0.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

// Maximum file size (10MB for Cloudflare Images)
const MAX_FILE_SIZE = 10 * 1024 * 1024;

// Supported file types
const SUPPORTED_FILE_TYPES = [
  'image/jpeg',
  'image/png',
  'image/webp'
];

// Cloudflare configuration
const CLOUDFLARE_CONFIG = {
  accountId: Deno.env.get('CLOUDFLARE_ACCOUNT_ID'),
  apiToken: Deno.env.get('CLOUDFLARE_API_TOKEN'),
  imageDeliveryUrl: Deno.env.get('CLOUDFLARE_IMAGE_DELIVERY_URL')
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    // Verify authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    // Create Supabase client to verify the token
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        auth: {
          persistSession: false,
        }
      }
    );

    // Verify the JWT token
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    // Validate Cloudflare credentials
    if (!CLOUDFLARE_CONFIG.accountId || !CLOUDFLARE_CONFIG.apiToken || !CLOUDFLARE_CONFIG.imageDeliveryUrl) {
      console.error('Missing Cloudflare configuration:', {
        hasAccountId: !!CLOUDFLARE_CONFIG.accountId,
        hasApiToken: !!CLOUDFLARE_CONFIG.apiToken,
        hasImageDeliveryUrl: !!CLOUDFLARE_CONFIG.imageDeliveryUrl
      });
      throw new Error('Missing Cloudflare credentials in Edge Function environment');
    }

    // Get the file data from the request
    const formData = await req.formData();
    const file = formData.get('file') as File;

    if (!file) {
      throw new Error('No file provided');
    }

    // Validate file type
    if (!SUPPORTED_FILE_TYPES.includes(file.type)) {
      throw new Error(`Unsupported file type: ${file.type}`);
    }

    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      throw new Error(`File size exceeds 10MB limit`);
    }

    // Create new FormData for Cloudflare upload
    const cloudflareFormData = new FormData();
    cloudflareFormData.append('file', file);
    cloudflareFormData.append('id', uuidv4());

    console.log('Uploading to Cloudflare Images...', {
      accountId: CLOUDFLARE_CONFIG.accountId,
      fileType: file.type,
      fileSize: file.size
    });

    // Upload to Cloudflare Images
    const response = await fetch(
      `https://api.cloudflare.com/client/v4/accounts/${CLOUDFLARE_CONFIG.accountId}/images/v1`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${CLOUDFLARE_CONFIG.apiToken}`,
        },
        body: cloudflareFormData,
      }
    );

    if (!response.ok) {
      const error = await response.json();
      console.error('Cloudflare upload error:', error);
      throw new Error(error.errors?.[0]?.message || 'Failed to upload image to Cloudflare');
    }

    const result = await response.json();
    
    if (!result.success || !result.result?.id) {
      console.error('Invalid response from Cloudflare:', result);
      throw new Error('Invalid response from Cloudflare');
    }

    console.log('Upload successful:', {
      id: result.result.id,
      variants: result.result.variants
    });

    return new Response(
      JSON.stringify({
        url: `${CLOUDFLARE_CONFIG.imageDeliveryUrl}/${result.result.id}/public`,
        cloudflareId: result.result.id
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error('Upload error:', error);
    
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : 'Internal server error'
      }),
      {
        status: error instanceof Error && error.message === 'Unauthorized' ? 401 : 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});