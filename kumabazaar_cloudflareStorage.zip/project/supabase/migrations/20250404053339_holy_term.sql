/*
  # Initial Schema Setup

  1. Tables
    - users
      - id (uuid, primary key)
      - email (text, unique)
      - name (text)
      - created_at (timestamp)
    - ads
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - price (numeric)
      - category_id (text)
      - location (text)
      - district_id (text)
      - town_id (text)
      - user_id (uuid, foreign key)
      - created_at (timestamp)
      - updated_at (timestamp)
      - featured (boolean)
      - needs_moderation (boolean)
      - phone_number (text)
      - phone_number_visible (boolean)
      - status (text)
    - ad_images
      - id (uuid, primary key)
      - ad_id (uuid, foreign key)
      - url (text)
      - cloudflare_id (text)
      - is_primary (boolean)
      - created_at (timestamp)
    - categories
      - id (text, primary key)
      - name (text)
      - icon (text)
      - price_label (text)
      - coming_soon (boolean)
      - created_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create ads table
CREATE TABLE IF NOT EXISTS ads (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  description text NOT NULL,
  price numeric NOT NULL,
  category_id text NOT NULL,
  location text NOT NULL,
  district_id text NOT NULL,
  town_id text NOT NULL,
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  featured boolean DEFAULT false,
  needs_moderation boolean DEFAULT false,
  phone_number text,
  phone_number_visible boolean DEFAULT false,
  status text DEFAULT 'Active',
  CONSTRAINT valid_status CHECK (status IN ('Active', 'Pending', 'Rejected', 'Expired', 'Sold'))
);

-- Create ad_images table
CREATE TABLE IF NOT EXISTS ad_images (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  ad_id uuid REFERENCES ads(id) ON DELETE CASCADE,
  url text NOT NULL,
  cloudflare_id text,
  is_primary boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  icon text NOT NULL,
  price_label text DEFAULT 'Price',
  coming_soon boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE ads ENABLE ROW LEVEL SECURITY;
ALTER TABLE ad_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Create policies
-- Users policies
CREATE POLICY "Users can read own data" ON users
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data" ON users
  FOR UPDATE TO authenticated
  USING (auth.uid() = id);

-- Ads policies
CREATE POLICY "Anyone can read active ads" ON ads
  FOR SELECT TO public
  USING (status = 'Active');

CREATE POLICY "Users can create ads" ON ads
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own ads" ON ads
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own ads" ON ads
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- Ad images policies
CREATE POLICY "Anyone can view ad images" ON ad_images
  FOR SELECT TO public
  USING (true);

CREATE POLICY "Users can manage images of own ads" ON ad_images
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM ads
      WHERE ads.id = ad_images.ad_id
      AND ads.user_id = auth.uid()
    )
  );

-- Categories policies
CREATE POLICY "Anyone can view categories" ON categories
  FOR SELECT TO public
  USING (true);

-- Create indexes
CREATE INDEX idx_ads_user_id ON ads(user_id);
CREATE INDEX idx_ads_category_id ON ads(category_id);
CREATE INDEX idx_ads_status ON ads(status);
CREATE INDEX idx_ad_images_ad_id ON ad_images(ad_id);
CREATE INDEX idx_categories_coming_soon ON categories(coming_soon);