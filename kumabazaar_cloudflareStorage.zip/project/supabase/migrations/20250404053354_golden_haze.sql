/*
  # Seed Categories Table

  1. Purpose
    - Populate the categories table with initial data
    - Set up default categories for the marketplace

  2. Categories
    - Books
    - Vehicles
    - Real Estate
    - Electronics
    - Jobs (coming soon)
    - Furniture
    - Fashion
    - Education
    - Hotels
    - Food
    - Grocery
    - Transport
    - Events
    - Nightlife
    - Mobile
    - Laptops
    - Electrical
    - Wedding (coming soon)
*/

INSERT INTO categories (id, name, icon, price_label, coming_soon)
VALUES
  ('books', 'Books', 'BookOpen', 'Price', false),
  ('vehicles', 'Vehicles', 'Car', 'Price', false),
  ('real-estate', 'Real Estate', 'Home', 'Price', false),
  ('electronics', 'Electronics', 'Smartphone', 'Price', false),
  ('jobs', 'Jobs', 'Briefcase', 'Salary', true),
  ('furniture', 'Furniture', 'Sofa', 'Price', false),
  ('fashion', 'Fashion', 'ShoppingBag', 'Price', false),
  ('education', 'Education & Learning', 'GraduationCap', 'Fees', false),
  ('hotels', 'Hotels & Resorts', 'Hotel', 'Price', false),
  ('food', 'Food & Dining', 'UtensilsCrossed', 'Price', false),
  ('grocery', 'Grocery & Supermarkets', 'ShoppingCart', 'Price', false),
  ('transport', 'Transport & Vehicles', 'Truck', 'Price', false),
  ('events', 'Events & Activities', 'Calendar', 'Price', false),
  ('nightlife', 'Bars & Nightclubs', 'Wine', 'Price', false),
  ('mobile', 'Mobile & Tablets', 'Smartphone', 'Price', false),
  ('laptops', 'Laptops & Computers', 'Laptop', 'Price', false),
  ('electrical', 'Electrical & Electronics', 'Zap', 'Price', false),
  ('wedding', 'Wedding & Matchmaking', 'Heart', 'Price', true)
ON CONFLICT (id) DO UPDATE
SET
  name = EXCLUDED.name,
  icon = EXCLUDED.icon,
  price_label = EXCLUDED.price_label,
  coming_soon = EXCLUDED.coming_soon;