import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { getSignedUrl } from 'npm:@aws-sdk/s3-request-presigner';
import { S3Client, PutObjectCommand } from 'npm:@aws-sdk/client-s3';

// Supported file types
const SUPPORTED_FILE_TYPES = [
  'image/jpeg',
  'image/png',
  'image/gif',
  'image/webp'
];

// Maximum file size (5MB)
const MAX_FILE_SIZE = 5 * 1024 * 1024;

// Initialize R2 client
const r2Client = new S3Client({
  region: 'auto',
  endpoint: `https://${Deno.env.get('CLOUDFLARE_ACCOUNT_ID')}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: Deno.env.get('CLOUDFLARE_ACCESS_KEY_ID') || '',
    secretAccessKey: Deno.env.get('CLOUDFLARE_SECRET_ACCESS_KEY') || ''
  }
});

serve(async (req: Request) => {
  // Handle CORS
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
  };

  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Verify request method
    if (req.method !== 'POST') {
      return new Response(
        JSON.stringify({ error: 'Method not allowed' }), 
        { 
          status: 405,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Get request body
    const body = await req.json();
    const { fileName, fileType, fileSize } = body;

    // Validate file type
    if (!SUPPORTED_FILE_TYPES.includes(fileType)) {
      return new Response(
        JSON.stringify({
          error: `Unsupported file type: ${fileType}. Supported types are: ${SUPPORTED_FILE_TYPES.join(', ')}`
        }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Validate file size
    if (fileSize > MAX_FILE_SIZE) {
      return new Response(
        JSON.stringify({
          error: `File size exceeds 5MB limit. Current size: ${(fileSize / 1024 / 1024).toFixed(2)}MB`
        }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Generate a unique ID for the file
    const fileId = crypto.randomUUID();
    const extension = fileName.split('.').pop()?.toLowerCase() || 'jpg';
    const objectKey = `${fileId}.${extension}`;

    // Create PutObject command
    const command = new PutObjectCommand({
      Bucket: Deno.env.get('CLOUDFLARE_BUCKET_NAME'),
      Key: objectKey,
      ContentType: fileType,
      CacheControl: 'public, max-age=31536000', // Cache for 1 year
      Metadata: {
        'original-filename': fileName,
        'upload-date': new Date().toISOString()
      }
    });

    // Generate signed URL with 1 hour expiry
    const signedUrl = await getSignedUrl(r2Client, command, { expiresIn: 3600 });

    // Return signed URL and file info
    return new Response(
      JSON.stringify({
        uploadUrl: signedUrl,
        fileId: objectKey,
        publicUrl: `${Deno.env.get('CLOUDFLARE_PUBLIC_URL')}/${objectKey}`
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  } catch (error) {
    console.error('Error generating signed URL:', error);

    return new Response(
      JSON.stringify({
        error: error.message || 'Failed to generate signed URL'
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});