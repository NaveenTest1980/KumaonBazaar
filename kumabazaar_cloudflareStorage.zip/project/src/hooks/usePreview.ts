import { useLocation } from 'react-router-dom';

export function usePreview() {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const isPreview = searchParams.get('preview') === 'true';
  
  // Create preview URL by adding preview=true parameter
  const getPreviewUrl = () => {
    const newParams = new URLSearchParams(searchParams);
    newParams.set('preview', 'true');
    return `${location.pathname}?${newParams.toString()}`;
  };

  // Create live URL by removing preview parameter
  const getLiveUrl = () => {
    const newParams = new URLSearchParams(searchParams);
    newParams.delete('preview');
    const queryString = newParams.toString();
    return `${location.pathname}${queryString ? `?${queryString}` : ''}`;
  };
  
  return {
    isPreview,
    previewUrl: getPreviewUrl(),
    liveUrl: getLiveUrl()
  };
}