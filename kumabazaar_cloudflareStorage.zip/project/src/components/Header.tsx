import React, { useState, useCallback, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Search, Menu, X, LogOut, User, PlusCircle, Bell } from 'lucide-react';

const Header = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/?search=${searchQuery}`);
    if (isMenuOpen) setIsMenuOpen(false);
  }, [navigate, searchQuery, isMenuOpen]);

  const handleLogout = useCallback(async () => {
    try {
      await logout();
      navigate('/');
      setIsProfileMenuOpen(false);
      setIsMenuOpen(false);
    } catch (error) {
      console.error('Failed to log out', error);
    }
  }, [logout, navigate]);

  const toggleMenu = useCallback(() => {
    setIsMenuOpen(!isMenuOpen);
  }, [isMenuOpen]);

  const toggleProfileMenu = useCallback(() => {
    setIsProfileMenuOpen(!isProfileMenuOpen);
  }, [isProfileMenuOpen]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (isProfileMenuOpen && !target.closest('.profile-menu-container')) {
        setIsProfileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isProfileMenuOpen]);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white shadow-lg backdrop-blur-lg bg-opacity-90' 
          : 'bg-gradient-to-r from-emerald-600 to-teal-600'
      }`}
    >
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link 
            to="/" 
            className={`text-xl font-bold transition-colors duration-300 ${
              isScrolled ? 'text-emerald-600' : 'text-white'
            }`}
          >
            Kumaon Bazaar
          </Link>

          {/* Search Bar - Hidden on mobile */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 mx-8">
            <div className="relative w-full max-w-xl">
              <input
                type="text"
                placeholder="Search in Kumaon Bazaar..."
                className="w-full py-2 px-4 pl-12 rounded-lg bg-white/90 backdrop-blur-sm border border-transparent focus:border-emerald-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 shadow-inner transition-all duration-300"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            </div>
          </form>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link 
              to="/post-ad" 
              className={`flex items-center space-x-1 px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
                isScrolled
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white hover:from-emerald-700 hover:to-teal-700'
                  : 'bg-gradient-to-r from-white to-emerald-50 text-emerald-600 hover:from-white hover:to-emerald-100'
              }`}
            >
              <PlusCircle className="h-5 w-5" />
              <span>Post Ad</span>
            </Link>
            
            {currentUser ? (
              <div className="relative profile-menu-container">
                <button 
                  className={`flex items-center space-x-2 transition-colors duration-300 ${
                    isScrolled ? 'text-gray-700 hover:text-emerald-600' : 'text-white hover:text-emerald-100'
                  }`}
                  onClick={toggleProfileMenu}
                >
                  <div className="relative">
                    <User className="h-5 w-5" />
                    <span className="absolute -top-1 -right-1 h-3 w-3 bg-green-500 rounded-full border-2 border-white"></span>
                  </div>
                  <span>{currentUser.name}</span>
                </button>
                {isProfileMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-10 animate-fade-in">
                    <Link 
                      to="/profile" 
                      className="block px-4 py-2 text-gray-700 hover:bg-emerald-50 hover:text-emerald-600 transition-colors"
                      onClick={() => setIsProfileMenuOpen(false)}
                    >
                      My Profile
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-emerald-50 hover:text-emerald-600 transition-colors"
                    >
                      Logout
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link 
                to="/login" 
                className={`font-medium transition-colors duration-300 ${
                  isScrolled ? 'text-gray-700 hover:text-emerald-600' : 'text-white hover:text-emerald-100'
                }`}
              >
                Login / Register
              </Link>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className={`md:hidden transition-colors duration-300 ${
              isScrolled ? 'text-gray-700' : 'text-white'
            }`} 
            onClick={toggleMenu}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Search - Visible only on mobile */}
        <form onSubmit={handleSearch} className="mt-3 md:hidden">
          <div className="relative">
            <input
              type="text"
              placeholder="Search in Kumaon Bazaar..."
              className="w-full py-2 px-4 pl-12 rounded-lg bg-white/90 backdrop-blur-sm border border-transparent focus:border-emerald-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 shadow-inner transition-all duration-300"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          </div>
        </form>

        {/* Mobile Navigation Menu */}
        {isMenuOpen && (
          <nav className="mt-3 md:hidden bg-white rounded-lg shadow-lg overflow-hidden animate-slide-in">
            <div className="flex flex-col">
              <Link 
                to="/post-ad" 
                className="flex items-center space-x-2 px-4 py-3 text-gray-700 hover:bg-emerald-50 hover:text-emerald-600 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                <PlusCircle className="h-5 w-5" />
                <span>Post Ad</span>
              </Link>
              
              {currentUser ? (
                <>
                  <Link 
                    to="/profile" 
                    className="flex items-center space-x-2 px-4 py-3 text-gray-700 hover:bg-emerald-50 hover:text-emerald-600 transition-colors"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <User className="h-5 w-5" />
                    <span>My Profile</span>
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="flex items-center space-x-2 px-4 py-3 text-gray-700 hover:bg-emerald-50 hover:text-emerald-600 transition-colors w-full"
                  >
                    <LogOut className="h-5 w-5" />
                    <span>Logout</span>
                  </button>
                </>
              ) : (
                <Link 
                  to="/login" 
                  className="px-4 py-3 text-gray-700 hover:bg-emerald-50 hover:text-emerald-600 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Login / Register
                </Link>
              )}
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;