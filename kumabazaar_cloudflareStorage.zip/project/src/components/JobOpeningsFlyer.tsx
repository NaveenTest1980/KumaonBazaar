import React, { useState, useEffect } from 'react';
import { ShoppingBag,ShieldAlert, MapPin,AlertTriangle, Clock, Link,Calendar,Lock,Star,Eye,Tag,QrCode,Briefcase,Key,Users} from 'lucide-react';

const backgroundImages = [
  // **Electronics & Gadgets**  
  'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1920&q=80', // Modern workspace with laptop, smartphone, and gadgets  
  'https://images.unsplash.com/photo-1584433144859-1fc2f6499e98?auto=format&fit=crop&w=1920&q=80', // Smartphone display in a tech store  
  'https://images.unsplash.com/photo-1603808033192-082d397925d6?auto=format&fit=crop&w=1920&q=80', // TV showroom with multiple screens  

  // **Vehicles - Bikes & Cars**  
  'https://images.unsplash.com/photo-1592194996308-7d9ce1f4d45c?auto=format&fit=crop&w=1920&q=80', // Sports bike parked on a scenic road  
  'https://images.unsplash.com/photo-1616587896030-d40f4ecb0cbb?auto=format&fit=crop&w=1920&q=80', // Luxury cars inside a showroom  

  // **Home Appliances - AC, Refrigerators, and More**  
  'https://images.unsplash.com/photo-1600585153482-4b5b06e8d8d0?auto=format&fit=crop&w=1920&q=80', // Modern living room with air conditioning  
  'https://images.unsplash.com/photo-1623161517644-03855ec5b1cf?auto=format&fit=crop&w=1920&q=80', // Smart home appliances in a stylish kitchen  

  // **Fashion & Accessories**  
  'https://images.unsplash.com/photo-1516762689617-e1cffcef479d?auto=format&fit=crop&w=1920&q=80', // Clothing store with trendy outfits  
  'https://images.unsplash.com/photo-1612902401109-2a4dc92cb2ea?auto=format&fit=crop&w=1920&q=80', // Shoe store with stylish sneakers  

  // **Marketplace & General Shopping**  
  'https://images.unsplash.com/photo-1624378438084-12ebef1e85a7?auto=format&fit=crop&w=1920&q=80', // Crowded local market with vendors and shoppers  
  'https://images.unsplash.com/photo-1580894908361-96789b4d83cf?auto=format&fit=crop&w=1920&q=80'  // Online shopping concept with e-commerce browsing  
];
const messages = [
  {
    id: 1,
    text: "KumaonBazaar.com – आपका स्थानीय बाज़ार, हर चीज़ के लिए!",
    icon: ShoppingBag,
    gradient: "from-purple-600/75 to-indigo-600/75"
  },
  {
    id: 2,
    text: "ऑनलाइन धोखाधड़ी से बचें! कोई भी बैंक अधिकारी आपसे OTP, CVV या पासवर्ड नहीं मांगेगा। ऐसी कॉल्स पर भरोसा न करें।",
    icon: ShieldAlert,
    gradient: "from-red-600/75 to-orange-600/75"
  },
  {
    id: 3,
    text: "गैजेट्स, बाइक और बहुत कुछ खरीदें और बेचें। परफेक्ट हॉस्टल या पीजी ढूंढें।",
    icon: MapPin,
    gradient: "from-orange-600/75 to-pink-600/75"
  },
  {
    id: 4,
    text: "अगर कोई खुद को CBI, पुलिस या ED अधिकारी बताकर पैसे मांगे, तो सतर्क रहें! ऐसे कॉल्स को तुरंत रिपोर्ट करें।",
    icon: AlertTriangle,
    gradient: "from-yellow-600/75 to-red-600/75"
  },
  {
    id: 5,
    text: "बस रजिस्टर करें, श्रेणी और ज़िला चुनें, तस्वीरें अपलोड करें और अपना विज्ञापन पोस्ट करें।",
    icon: Clock,
    gradient: "from-emerald-600/75 to-teal-600/75"
  },
  {
    id: 6,
    text: "अज्ञात लिंक पर क्लिक न करें! KYC अपडेट या लॉटरी के नाम पर भेजे गए लिंक स्कैम हो सकते हैं।",
    icon: Link,
    gradient: "from-red-600/75 to-purple-600/75"
  },
  {
    id: 7,
    text: "खरीदें, बेचें और मज़े करें!",
    icon: Calendar,
    gradient: "from-blue-600/75 to-violet-600/75"
  },
  {
    id: 8,
    text: "अगर कोई आपसे फोन पर UPI पिन डालने को कहे, तो सावधान रहें! पैसा तुरंत कट सकता है।",
    icon: Lock,
    gradient: "from-indigo-600/75 to-blue-600/75"
  },
  {
    id: 9,
    text: "कुमाऊं का सबसे आसान ऑनलाइन बाज़ार – अभी जोड़ें और अपने शहर से जुड़े रहें!",
    icon: Star,
    gradient: "from-red-600/75 to-yellow-600/75"
  },
  {
    id: 10,
    text: "जल्दबाज़ी में कोई निर्णय न लें! पहले सोचें, समझें और फिर कोई कदम उठाएं।",
    icon: Eye,
    gradient: "from-gray-600/75 to-black-600/75"
  },
  {
    id: 11,
    text: "यहां पाएं सबसे अच्छे डील्स! कोई भी चीज़ आसानी से खरीदें या बेचें।",
    icon: Tag,
    gradient: "from-pink-600/75 to-purple-600/75"
  },
  {
    id: 12,
    text: "अगर कोई खरीदार जल्दी से QR कोड स्कैन करने को कहे, तो सतर्क रहें! पैसा कट सकता है।",
    icon: QrCode,
    gradient: "from-orange-600/75 to-red-600/75"
  },
  {
    id: 13,
    text: "घर बैठे कमाएं – अपने पुराने सामान को ऑनलाइन बेचें और तुरंत ग्राहक पाएं!",
    icon: Briefcase,
    gradient: "from-green-600/75 to-lime-600/75"
  },
  {
    id: 14,
    text: "हमेशा अपनी व्यक्तिगत जानकारी गोपनीय रखें। कोई भी बैंकिंग जानकारी किसी से साझा न करें।",
    icon: Key,
    gradient: "from-purple-600/75 to-indigo-600/75"
  },
  {
    id: 15,
    text: "स्थानीय विज्ञापन, विश्वसनीय ग्राहक – KumaonBazaar से खरीदारी करें!",
    icon: Users,
    gradient: "from-indigo-600/75 to-blue-600/75"
  }
];

const JobOpeningsFlyer: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true);
      setCurrentIndex((prev) => (prev + 1) % messages.length);
      setTimeout(() => setIsAnimating(false), 1000);
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  const currentMessage = messages[currentIndex];
  const Icon = currentMessage.icon;

  return (
    <div className="relative overflow-hidden h-64">
      {/* Background Images with Ken Burns effect */}
      {backgroundImages.map((image, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-all duration-2000 transform ${
            index === currentIndex ? 'opacity-100 scale-105' : 'opacity-0 scale-100'
          }`}
          style={{
            backgroundImage: `url(${image})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            transform: index === currentIndex ? 'scale(1.1)' : 'scale(1)',
            transition: 'transform 8s ease-out, opacity 1s ease-in-out',
          }}
        />
      ))}

      {/* Semi-transparent overlay for better text readability */}
      <div className="absolute inset-0 bg-black/30" />

      {/* Gradient Overlay */}
      <div className={`absolute inset-0 bg-gradient-to-r ${currentMessage.gradient} mix-blend-multiply`} />

      {/* Content Container */}
      <div className="relative h-full">
        <div className="container mx-auto px-4 h-full flex items-center justify-center">
          <div className="text-center text-white max-w-3xl">
            {/* Icon with enhanced glow effect */}
            <div className="inline-flex items-center justify-center p-4 mb-6 relative">
              <div className="absolute inset-0 bg-white/30 rounded-full blur-2xl animate-pulse-soft" />
              <div className="absolute inset-0 bg-white/20 rounded-full blur-lg animate-float" />
              <div className="relative bg-white/20 rounded-full p-4 backdrop-blur-sm border border-white/30 shadow-xl animate-float">
                <Icon className="h-8 w-8" />
              </div>
            </div>

            {/* Message with enhanced visibility */}
            <div className="relative overflow-hidden backdrop-blur-sm bg-black/20 rounded-xl p-6 border border-white/10">
              <p 
                className={`text-xl md:text-2xl font-medium tracking-wide transition-all duration-1000 ${
                  isAnimating ? 'opacity-0 transform translate-y-4' : 'opacity-100 transform translate-y-0'
                }`}
                style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
              >
                {currentMessage.text}
              </p>

              {/* Progress Indicators */}
              <div className="flex justify-center mt-6 space-x-2">
                {messages.map((_, index) => (
                  <div
                    key={index}
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      index === currentIndex 
                        ? 'w-8 bg-white shadow-lg' 
                        : 'w-1.5 bg-white/50'
                    }`}
                  >
                    {index === currentIndex && (
                      <div 
                        className="h-full bg-white/50"
                        style={{ 
                          animation: 'progress 8s linear',
                          transformOrigin: 'left'
                        }} 
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-black/5 to-transparent pointer-events-none" />
    </div>
  );
};

export default JobOpeningsFlyer;