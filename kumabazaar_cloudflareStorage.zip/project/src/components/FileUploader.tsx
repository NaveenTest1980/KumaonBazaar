import React, { useState, useRef, useCallback } from 'react';
import { Upload, X, Image as ImageIcon, Check } from 'lucide-react';

interface FileUploaderProps {
  onFilesSelected: (files: File[]) => void;
  maxFiles?: number;
  acceptedFileTypes?: string;
  maxSizeMB?: number;
  className?: string;
  allowVideos?: boolean;
}

const FileUploader: React.FC<FileUploaderProps> = ({
  onFilesSelected,
  maxFiles = 5,
  acceptedFileTypes = 'image/*',
  maxSizeMB = 5,
  className = '',
  allowVideos = false
}) => {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [uploadStatus, setUploadStatus] = useState<('idle' | 'uploading' | 'success' | 'error')[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFile = (file: File): { valid: boolean; error?: string } => {
    // Check file size
    const maxSizeBytes = maxSizeMB * 1024 * 1024;
    if (file.size > maxSizeBytes) {
      return {
        valid: false,
        error: `File size exceeds the maximum allowed size of ${maxSizeMB}MB`
      };
    }

    // Check file type
    if (!file.type.startsWith('image/')) {
      return {
        valid: false,
        error: 'Only image files are allowed'
      };
    }

    return { valid: true };
  };

  const handleFileChange = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newFiles = Array.from(files).slice(0, maxFiles - selectedFiles.length);
    const newErrors: string[] = [];
    const validFiles: File[] = [];
    const newPreviews: string[] = [];
    const newStatuses: ('idle' | 'uploading' | 'success' | 'error')[] = [];

    // Validate each file
    for (const file of newFiles) {
      const validation = validateFile(file);
      
      if (!validation.valid) {
        newErrors.push(`${file.name}: ${validation.error}`);
        continue;
      }

      validFiles.push(file);
      
      // Create preview URL
      const previewUrl = URL.createObjectURL(file);
      newPreviews.push(previewUrl);
      newStatuses.push('success');
    }

    if (validFiles.length > 0) {
      const newSelectedFiles = [...selectedFiles, ...validFiles];
      setSelectedFiles(newSelectedFiles);
      setPreviews(prev => [...prev, ...newPreviews]);
      setUploadStatus(prev => [...prev, ...newStatuses]);
      onFilesSelected(newSelectedFiles);
    }

    if (newErrors.length > 0) {
      setErrors(prev => [...prev, ...newErrors]);
    }

    // Reset input value
    e.target.value = '';
  }, [selectedFiles, maxFiles, maxSizeMB, onFilesSelected]);

  const handleRemoveFile = useCallback((index: number) => {
    URL.revokeObjectURL(previews[index]);
    
    const newFiles = [...selectedFiles];
    const newPreviews = [...previews];
    const newUploadStatus = [...uploadStatus];
    
    newFiles.splice(index, 1);
    newPreviews.splice(index, 1);
    newUploadStatus.splice(index, 1);
    
    setSelectedFiles(newFiles);
    setPreviews(newPreviews);
    setUploadStatus(newUploadStatus);
    onFilesSelected(newFiles);
  }, [selectedFiles, previews, uploadStatus, onFilesSelected]);

  const handleClick = useCallback(() => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  }, []);

  const clearErrors = useCallback(() => {
    setErrors([]);
  }, []);

  return (
    <div className={`w-full ${className}`}>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept={acceptedFileTypes}
        multiple={maxFiles > 1}
      />
      
      {selectedFiles.length < maxFiles && (
        <div 
          className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:bg-gray-50 transition-colors"
          onClick={handleClick}
        >
          <Upload className="mx-auto h-12 w-12 text-gray-400" />
          <p className="mt-2 text-sm text-gray-600">
            Click to upload images
          </p>
          <p className="text-xs text-gray-500">
            PNG, JPG, GIF up to {maxSizeMB}MB (max {maxFiles} files)
          </p>
        </div>
      )}
      
      {errors.length > 0 && (
        <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md">
          <div className="flex justify-between items-start">
            <div className="flex items-center">
              <X className="h-5 w-5 text-red-500 mr-2" />
              <h4 className="text-sm font-medium text-red-800">Upload errors</h4>
            </div>
            <button 
              onClick={clearErrors}
              className="text-red-500 hover:text-red-700"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <ul className="mt-2 text-xs text-red-700 list-disc list-inside">
            {errors.map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        </div>
      )}
      
      {selectedFiles.length > 0 && (
        <div className="mt-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Selected Files:</h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {selectedFiles.map((file, index) => (
              <div key={index} className="relative group">
                <div className="aspect-square bg-gray-100 rounded-md overflow-hidden">
                  <img
                    src={previews[index]}
                    alt={`Preview ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveFile(index)}
                  className="absolute top-1 right-1 bg-white rounded-full p-1 shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="h-4 w-4 text-red-500" />
                </button>
                <div className="absolute bottom-1 right-1">
                  <div className="bg-green-100 rounded-full p-1">
                    <Check className="h-4 w-4 text-green-500" />
                  </div>
                </div>
                <p className="text-xs text-gray-500 truncate mt-1">{file.name}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUploader;