import React, { useEffect, useRef } from 'react';

interface AdSenseProps {
  adSlot: string;
  adFormat?: 'auto' | 'fluid' | 'rectangle' | 'horizontal' | 'vertical';
  style?: React.CSSProperties;
  className?: string;
}

const AdSense: React.FC<AdSenseProps> = ({ 
  adSlot, 
  adFormat = 'auto', 
  style = {}, 
  className = '' 
}) => {
  const adRef = useRef<HTMLDivElement>(null);
  const initializedRef = useRef(false);
  
  // Generate a stable unique ID for this specific ad instance
  const uniqueId = useRef(`ad-${adSlot}-${Math.random().toString(36).substring(2, 9)}`);

  useEffect(() => {
    // Skip if already initialized or AdSense is disabled
    if (initializedRef.current || window.adsbygoogle?.disabled) {
      return;
    }

    // Check if the element exists and hasn't been initialized
    if (adRef.current) {
      // Set a data attribute to mark this specific ad
      adRef.current.setAttribute('data-ad-id', uniqueId.current);
      
      // Mark as initialized BEFORE pushing to prevent double initialization
      initializedRef.current = true;
      
      // Use a more significant delay to ensure the DOM is fully ready
      const timer = setTimeout(() => {
        try {
          // Check if adsbygoogle is available and not disabled
          if (window.adsbygoogle && !window.adsbygoogle.disabled) {
            // Create a new adsbygoogle push call
            window.adsbygoogle.push({});
          }
        } catch (error) {
          console.error('AdSense initialization error:', error);
          // Reset initialization flag on error
          initializedRef.current = false;
        }
      }, 300); // Longer delay to ensure DOM is ready
      
      return () => {
        clearTimeout(timer);
      };
    }
    
    return () => {
      // Don't reset the initialization flag on unmount
      // This prevents re-initialization if the component remounts
    };
  }, [adSlot]); // Only re-run if adSlot changes

  // If AdSense is disabled, render a placeholder instead
  if (window.adsbygoogle?.disabled) {
    return (
      <div 
        className={`adsense-placeholder ${className}`} 
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#f3f4f6',
          color: '#9ca3af',
          fontSize: '0.875rem',
          ...style
        }}
      >
        <span>Advertisement Placeholder</span>
      </div>
    );
  }

  return (
    <div className={`adsense-container ${className}`} ref={adRef} data-ad-id={uniqueId.current}>
      <ins
        className="adsbygoogle"
        style={{
          display: 'block',
          ...style
        }}
        data-ad-client="ca-pub-1234567890123456"
        data-ad-slot={adSlot}
        data-ad-format={adFormat}
        data-full-width-responsive="true"
      />
    </div>
  );
};

// Use React.memo to prevent unnecessary re-renders
export default React.memo(AdSense);