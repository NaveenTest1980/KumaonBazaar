import React, { useState, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { kumaonDistricts } from '../data/locations';
import { PlusCircle, Loader, AlertCircle, Phone } from 'lucide-react';
import FileUploader from '../components/FileUploader';
import { createAd } from '../services/adService';

const categories = [
  { id: 'books', name: 'Books' },
  { id: 'vehicles', name: 'Vehicles' },
  { id: 'real-estate', name: 'Real Estate' },
  { id: 'electronics', name: 'Electronics' },
  { id: 'furniture', name: 'Furniture' },
  { id: 'fashion', name: 'Fashion' },
  { id: 'education', name: 'Education & Learning', priceLabel: 'Fees' },
  { id: 'hotels', name: 'Hotels & Resorts' },
  { id: 'food', name: 'Food & Dining' },
  { id: 'grocery', name: 'Grocery & Supermarkets' },
  { id: 'transport', name: 'Transport & Vehicles' },
  { id: 'events', name: 'Events & Activities' },
  { id: 'nightlife', name: 'Bars & Nightclubs' },
  { id: 'mobile', name: 'Mobile & Tablets' },
  { id: 'laptops', name: 'Laptops & Computers' },
  { id: 'electrical', name: 'Electrical & Electronics' }
];

const PostAd = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('');
  const [district, setDistrict] = useState('');
  const [town, setTown] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneNumberError, setPhoneNumberError] = useState('');
  const [images, setImages] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  
  const selectedDistrict = kumaonDistricts.find(d => d.id === district);
  const selectedCategory = categories.find(c => c.id === category);
  const priceLabel = selectedCategory?.priceLabel || 'Price';

  // If user is not logged in, redirect to login page
  if (!currentUser) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-md mx-auto bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-gradient-to-r from-indigo-600 to-violet-600 py-6 px-8">
            <h1 className="text-2xl font-bold text-white">Login Required</h1>
          </div>
          <div className="p-6">
            <p className="text-gray-600 mb-4">
              You must be logged in to post an ad.
            </p>
            <Link
              to="/login"
              state={{ from: '/post-ad' }}
              className="block w-full bg-gradient-to-r from-indigo-600 to-violet-600 text-white text-center py-3 px-4 rounded-lg font-medium hover:from-indigo-700 hover:to-violet-700 transition shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              Login to Continue
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Reset error states
      setError('');
      setPhoneNumberError('');
      
      // Validate required fields
      if (!title || !description || !price || !category || !district || !town) {
        setError('Please fill in all required fields');
        return;
      }
      
      // Validate images
      if (images.length === 0) {
        setError('Please upload at least one image');
        return;
      }

      // Validate phone number if provided
      if (phoneNumber) {
        const phoneRegex = /^\d{10}$/;
        if (!phoneRegex.test(phoneNumber)) {
          setPhoneNumberError('Please enter a valid 10-digit phone number');
          return;
        }
      }

      // Start loading state
      setLoading(true);
      console.log('Starting ad creation process...');
      
      // Prepare location string
      const districtName = selectedDistrict?.name || '';
      const townName = selectedDistrict?.towns.find(t => t.id === town)?.name || '';
      const location = `${townName}, ${districtName}`;
      
      // Create ad
      const adData = {
        title,
        description,
        price: parseFloat(price),
        categoryId: category,
        location,
        districtId: district,
        townId: town,
        userId: currentUser.id,
        phoneNumber: phoneNumber || undefined
      };
      
      console.log('Creating ad with data:', {
        ...adData,
        imageCount: images.length
      });

      const result = await createAd(adData, images, (progress) => {
        setUploadProgress(progress);
      });
      
      if (result) {
        console.log('Ad created successfully:', result);
        navigate(`/ad/${result.id}`);
      } else {
        throw new Error('Failed to create ad - no result returned');
      }
    } catch (error: any) {
      console.error('Error creating ad:', error);
      setError(error.message || 'Failed to create ad. Please try again.');
      setLoading(false);
    }
  }, [title, description, price, category, district, town, phoneNumber, images, currentUser, navigate, selectedDistrict]);

  const handleDistrictChange = useCallback((e: React.ChangeEvent<HTMLSelectElement>) => {
    setDistrict(e.target.value);
    setTown(''); // Reset town when district changes
  }, []);

  const handleFilesSelected = useCallback((files: File[]) => {
    console.log('Files selected:', files.map(f => ({ name: f.name, type: f.type, size: f.size })));
    setImages(files);
  }, []);

  const handlePhoneNumberChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '').slice(0, 10); // Only allow digits, max 10
    setPhoneNumber(value);
    setPhoneNumberError('');
  }, []);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-indigo-600 to-violet-600 py-6 px-8">
          <h1 className="text-2xl font-bold text-white flex items-center">
            <PlusCircle className="mr-2" />
            Post a New Ad
          </h1>
        </div>
        
        <div className="p-8">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
              <div className="flex items-center">
                <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                <p className="text-red-700">{error}</p>
              </div>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="title" className="block text-gray-700 font-medium mb-2">
                Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
                placeholder="Enter a descriptive title"
                required
                disabled={loading}
              />
            </div>
            
            <div>
              <label htmlFor="category" className="block text-gray-700 font-medium mb-2">
                Category <span className="text-red-500">*</span>
              </label>
              <select
                id="category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
                required
                disabled={loading}
              >
                <option value="">Select a category</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="description" className="block text-gray-700 font-medium mb-2">
                Description <span className="text-red-500">*</span>
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
                placeholder={description ? '' : 'विवरण फ़ील्ड में कृपया अपने उत्पाद का विवरण जोड़ें और अपना संपर्क नंबर भी उल्लेख करें'}
                rows={5}
                required
                disabled={loading}
                maxLength={300}
              />
              <p className="text-sm text-gray-500 mt-1">
                {description.length}/300 characters
              </p>
            </div>
            
            <div>
              <label htmlFor="price" className="block text-gray-700 font-medium mb-2">
                {priceLabel} (₹) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                id="price"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
                placeholder={`Enter ${priceLabel.toLowerCase()} in INR`}
                min="0"
                step="0.01"
                required
                disabled={loading}
              />
            </div>

            <div>
              <label htmlFor="phoneNumber" className="block text-gray-700 font-medium mb-2">
                Phone Number <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Phone className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="tel"
                  id="phoneNumber"
                  value={phoneNumber}
                  onChange={handlePhoneNumberChange}
                  className={`w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow ${
                    phoneNumberError ? 'border-red-500' : ''
                  }`}
                  placeholder="Enter your 10-digit phone number"
                  required
                  disabled={loading}
                  maxLength={10}
                />
              </div>
              {phoneNumberError && (
                <p className="mt-1 text-sm text-red-600">{phoneNumberError}</p>
              )}
              <p className="mt-1 text-sm text-gray-500">
                Enter a valid 10-digit mobile number
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="district" className="block text-gray-700 font-medium mb-2">
                  District <span className="text-red-500">*</span>
                </label>
                <select
                  id="district"
                  value={district}
                  onChange={handleDistrictChange}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
                  required
                  disabled={loading}
                >
                  <option value="">Select a district</option>
                  {kumaonDistricts.map((dist) => (
                    <option key={dist.id} value={dist.id}>
                      {dist.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label htmlFor="town" className="block text-gray-700 font-medium mb-2">
                  Town <span className="text-red-500">*</span>
                </label>
                <select
                  id="town"
                  value={town}
                  onChange={(e) => setTown(e.target.value)}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
                  disabled={!district || loading}
                  required
                >
                  <option value="">Select a town</option>
                  {selectedDistrict?.towns.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            <div>
              <label htmlFor="images" className="block text-gray-700 font-medium mb-2">
                Images <span className="text-red-500">*</span>
              </label>
              <FileUploader 
                onFilesSelected={handleFilesSelected}
                maxFiles={5}
                acceptedFileTypes="image/*"
                maxSizeMB={5}
                allowVideos={false}
              />
              {uploadProgress > 0 && uploadProgress < 100 && (
                <div className="mt-2">
                  <div className="bg-gray-200 rounded-full h-2 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-indigo-600 to-violet-600 h-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                  <p className="text-sm text-gray-600 mt-1">
                    Uploading: {uploadProgress}%
                  </p>
                </div>
              )}
            </div>
            
            <button
              type="submit"
              disabled={loading || images.length === 0}
              className="w-full bg-gradient-to-r from-indigo-600 to-violet-600 text-white py-3 px-4 rounded-lg font-medium hover:from-indigo-700 hover:to-violet-700 transition shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center"
            >
              {loading ? (
                <>
                  <Loader className="animate-spin mr-2 h-5 w-5" />
                  Posting...
                </>
              ) : 'Post Ad'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PostAd;