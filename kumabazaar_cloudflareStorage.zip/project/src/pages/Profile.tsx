import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { User, LogOut, Edit, Trash2, AlertCircle, Clock, Phone } from 'lucide-react';
import { sql } from '../db/neon';
import { getUserPayments } from '../services/paymentService';
import AdCard from '../components/AdCard';
import PaymentModal from '../components/PaymentModal';

interface Ad {
  id: string;
  title: string;
  price: number;
  location: string;
  images: Array<{url: string}>;
  category_id: string;
  created_at: string;
  phone_number?: string;
  phone_number_visible?: boolean;
  phone_number_expiry_date?: string;
}

interface Payment {
  id: string;
  adId: string;
  amount: number;
  paymentMethod: string;
  status: string;
  createdAt: string;
}

const Profile = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  
  const [userAds, setUserAds] = useState<Ad[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('my-ads');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [selectedAdForPayment, setSelectedAdForPayment] = useState<string | null>(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentProcessing, setPaymentProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  useEffect(() => {
    const fetchUserData = async () => {
      if (!currentUser) return;
      
      setLoading(true);
      try {
        // Fetch user's ads directly using SQL query
        const ads = await sql<Ad>`
          SELECT a.*, 
                 COALESCE(jsonb_agg(
                   jsonb_build_object(
                     'id', ai.id,
                     'url', ai.url,
                     'is_primary', ai.is_primary
                   ) ORDER BY ai.is_primary DESC, ai.created_at ASC
                 ) FILTER (WHERE ai.id IS NOT NULL), '[]') as images
          FROM ads a
          LEFT JOIN ad_images ai ON a.id = ai.ad_id
          WHERE a.user_id = ${currentUser.id}
          GROUP BY a.id
          ORDER BY a.created_at DESC
        `;
        setUserAds(ads);
        
        // Fetch user's payment history
        const paymentHistory = await getUserPayments(currentUser.id);
        setPayments(paymentHistory);
      } catch (error) {
        console.error('Error fetching user data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [currentUser]);

  const handleLogout = useCallback(async () => {
    try {
      await logout();
      navigate('/');
    } catch (error) {
      console.error('Failed to log out', error);
    }
  }, [logout, navigate]);

  const handleDeleteAd = useCallback(async (adId: string) => {
    try {
      // Delete ad from database
      await sql`DELETE FROM ads WHERE id = ${adId} AND user_id = ${currentUser?.id}`;
      setUserAds(prevAds => prevAds.filter(ad => ad.id !== adId));
      setDeleteConfirm(null);
    } catch (error) {
      console.error('Error deleting ad:', error);
    }
  }, [currentUser]);

  const handleTabChange = useCallback((tab: string) => {
    setActiveTab(tab);
  }, []);
  
  const openPaymentModal = useCallback((adId: string) => {
    setSelectedAdForPayment(adId);
    setIsPaymentModalOpen(true);
  }, []);
  
  const closePaymentModal = useCallback(() => {
    setIsPaymentModalOpen(false);
    setSelectedAdForPayment(null);
  }, []);
  
  const handlePaymentSuccess = useCallback(async (paymentMethod: string, paymentId?: string) => {
    if (!currentUser || !selectedAdForPayment) return;
    
    try {
      setPaymentProcessing(true);
      
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setPaymentSuccess(true);
      
      // Update the ad in state
      setUserAds(prevAds => 
        prevAds.map(ad => {
          if (ad.id === selectedAdForPayment) {
            const phoneNumberExpiryDate = new Date();
            phoneNumberExpiryDate.setDate(phoneNumberExpiryDate.getDate() + 30);
            
            return {
              ...ad,
              phone_number_visible: true,
              phone_number_expiry_date: phoneNumberExpiryDate.toISOString()
            };
          }
          return ad;
        })
      );
      
      // Add to payment history
      const newPayment = {
        id: paymentId || `pay_${Math.random().toString(36).substring(2, 15)}`,
        adId: selectedAdForPayment,
        amount: 100,
        paymentMethod,
        status: 'completed',
        createdAt: new Date().toISOString()
      };
      
      setPayments(prev => [newPayment, ...prev]);
      
      // Close the modal after a delay
      setTimeout(() => {
        setIsPaymentModalOpen(false);
        setPaymentProcessing(false);
        setPaymentSuccess(false);
        setSelectedAdForPayment(null);
      }, 2000);
    } catch (error) {
      console.error('Error processing payment:', error);
      setPaymentProcessing(false);
    }
  }, [currentUser, selectedAdForPayment]);

  if (!currentUser) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded">
          Please log in to view your profile
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {/* Profile Header */}
        <div className="bg-orange-500 p-6 text-white">
          <div className="flex items-center">
            <div className="bg-white rounded-full p-3 mr-4">
              <User className="h-10 w-10 text-orange-500" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{currentUser.name}</h1>
              <p>{currentUser.email}</p>
            </div>
          </div>
        </div>
        
        {/* Tabs */}
        <div className="border-b">
          <div className="flex">
            <button
              className={`px-6 py-3 font-medium ${
                activeTab === 'my-ads'
                  ? 'border-b-2 border-orange-500 text-orange-500'
                  : 'text-gray-600 hover:text-orange-500'
              }`}
              onClick={() => handleTabChange('my-ads')}
            >
              My Ads
            </button>
            <button
              className={`px-6 py-3 font-medium ${
                activeTab === 'payments'
                  ? 'border-b-2 border-orange-500 text-orange-500'
                  : 'text-gray-600 hover:text-orange-500'
              }`}
              onClick={() => handleTabChange('payments')}
            >
              Payments
            </button>
            <button
              className={`px-6 py-3 font-medium ${
                activeTab === 'settings'
                  ? 'border-b-2 border-orange-500 text-orange-500'
                  : 'text-gray-600 hover:text-orange-500'
              }`}
              onClick={() => handleTabChange('settings')}
            >
              Settings
            </button>
          </div>
        </div>
        
        {/* Tab Content */}
        <div className="p-6">
          {activeTab === 'my-ads' && (
            <>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">My Ads</h2>
                <Link
                  to="/post-ad"
                  className="bg-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:bg-orange-600 transition"
                >
                  Post New Ad
                </Link>
              </div>
              
              {loading ? (
                <div className="flex justify-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-orange-500"></div>
                </div>
              ) : userAds.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {userAds.map((ad) => (
                    <div key={ad.id} className="relative">
                      <Link to={`/ad/${ad.id}`}>
                        <AdCard 
                          id={ad.id}
                          title={ad.title}
                          price={ad.price}
                          location={ad.location}
                          imageUrl={ad.images[0]?.url || 'https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'}
                          category={ad.category_id}
                          createdAt={ad.created_at}
                        />
                      </Link>
                      
                      {/* Phone Number Status */}
                      {ad.phone_number && (
                        <div className="absolute top-2 left-2 z-10">
                          {ad.phone_number_visible ? (
                            <div className="bg-green-500 text-white text-xs px-2 py-1 rounded-full flex items-center">
                              <Phone className="h-3 w-3 mr-1" />
                              <span>Phone Visible</span>
                            </div>
                          ) : (
                            <div className="bg-gray-500 text-white text-xs px-2 py-1 rounded-full flex items-center">
                              <Phone className="h-3 w-3 mr-1" />
                              <span>Phone Hidden</span>
                            </div>
                          )}
                        </div>
                      )}
                      
                      <div className="absolute top-2 right-2 flex space-x-1">
                        <button 
                          className="bg-white p-2 rounded-full shadow-md hover:bg-gray-100"
                          onClick={() => navigate(`/edit-ad/${ad.id}`)}
                        >
                          <Edit className="h-4 w-4 text-gray-600" />
                        </button>
                        <button 
                          className="bg-white p-2 rounded-full shadow-md hover:bg-gray-100"
                          onClick={() => setDeleteConfirm(ad.id)}
                        >
                          <Trash2 className="h-4 w-4 text-red-600" />
                        </button>
                      </div>
                      
                      {/* Phone Number Extension Button */}
                      {ad.phone_number && !ad.phone_number_visible && (
                        <div className="mt-2">
                          <button
                            onClick={() => openPaymentModal(ad.id)}
                            className="w-full bg-orange-500 text-white py-2 rounded-lg font-medium hover:bg-orange-600 transition text-sm flex items-center justify-center"
                          >
                            <Phone className="h-4 w-4 mr-1" />
                            Show Phone Number (₹100)
                          </button>
                        </div>
                      )}
                      
                      {/* Delete Confirmation Modal */}
                      {deleteConfirm === ad.id && (
                        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                          <div className="bg-white rounded-lg p-6 max-w-md w-full">
                            <div className="flex items-center text-red-600 mb-4">
                              <AlertCircle className="h-6 w-6 mr-2" />
                              <h3 className="text-lg font-medium">Delete Ad</h3>
                            </div>
                            <p className="mb-6">Are you sure you want to delete this ad? This action cannot be undone.</p>
                            <div className="flex justify-end space-x-3">
                              <button
                                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100"
                                onClick={() => setDeleteConfirm(null)}
                              >
                                Cancel
                              </button>
                              <button
                                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                                onClick={() => handleDeleteAd(ad.id)}
                              >
                                Delete
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <p className="text-lg text-gray-600">You haven't posted any ads yet.</p>
                  <Link
                    to="/post-ad"
                    className="mt-4 inline-block bg-orange-500 text-white px-6 py-2 rounded-lg font-medium hover:bg-orange-600 transition"
                  >
                    Post Your First Ad
                  </Link>
                </div>
              )}
            </>
          )}
          
          {activeTab === 'payments' && (
            <>
              <h2 className="text-xl font-bold mb-6">Payment History</h2>
              {loading ? (
                <div className="flex justify-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-orange-500"></div>
                </div>
              ) : payments.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Ad
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Amount
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Payment Method
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {payments.map((payment) => {
                        // Find the ad associated with this payment
                        const ad = userAds.find(ad => ad.id === payment.adId);
                        
                        return (
                          <tr key={payment.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {new Date(payment.createdAt).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {ad ? (
                                <Link to={`/ad/${ad.id}`} className="text-orange-500 hover:underline">
                                  {ad.title.length > 30 ? ad.title.substring(0, 30) + '...' : ad.title}
                                </Link>
                              ) : (
                                <span className="text-gray-500">Ad not found</span>
                              )}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              ₹{payment.amount.toFixed(2)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">
                              {payment.paymentMethod}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 capitalize">
                                {payment.status}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <p className="text-lg text-gray-600">You don't have any payment history yet.</p>
                </div>
              )}
            </>
          )}
          
          {activeTab === 'settings' && (
            <>
              <h2 className="text-xl font-bold mb-6">Account Settings</h2>
              
              <div className="space-y-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Personal Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm text-gray-600 mb-1">Name</label>
                      <input
                        type="text"
                        value={currentUser.name}
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-600 mb-1">Email</label>
                      <input
                        type="email"
                        value={currentUser.email}
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                        readOnly
                      />
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Change Password</h3>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm text-gray-600 mb-1">Current Password</label>
                      <input
                        type="password"
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                        placeholder="Enter current password"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-600 mb-1">New Password</label>
                      <input
                        type="password"
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                        placeholder="Enter new password"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-600 mb-1">Confirm New Password</label>
                      <input
                        type="password"
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                        placeholder="Confirm new password"
                      />
                    </div>
                    <button className="bg-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:bg-orange-600 transition">
                      Update Password
                    </button>
                  </div>
                </div>
                
                <div className="border-t pt-6">
                  <button
                    onClick={handleLogout}
                    className="flex items-center text-red-600 hover:text-red-800"
                  >
                    <LogOut className="h-5 w-5 mr-2" />
                    Logout
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
      
      {/* Payment Modal */}
      <PaymentModal 
        isOpen={isPaymentModalOpen}
        onClose={closePaymentModal}
        onPaymentSuccess={handlePaymentSuccess}
        amount={100}
        title="Extend Phone Number Visibility"
        description="Pay ₹100 to make your phone number visible for 30 more days"
        processing={paymentProcessing}
        success={paymentSuccess}
      />
    </div>
  );
};

export default Profile;