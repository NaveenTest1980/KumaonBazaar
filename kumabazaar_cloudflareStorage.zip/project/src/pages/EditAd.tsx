import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Edit, AlertCircle, Loader } from 'lucide-react';
import { sql } from '../db/neon';
import { Ad } from '../types/Ad';
import { kumaonDistricts } from '../data/locations';
import FileUploader from '../components/FileUploader';

const categories = [
  { id: 'books', name: 'Books' },
  { id: 'vehicles', name: 'Vehicles' },
  { id: 'real-estate', name: 'Real Estate' },
  { id: 'electronics', name: 'Electronics' },
  { id: 'furniture', name: 'Furniture' },
  { id: 'fashion', name: 'Fashion' },
  { id: 'education', name: 'Education & Learning', priceLabel: 'Fees' },
  { id: 'hotels', name: 'Hotels & Resorts' },
  { id: 'food', name: 'Food & Dining' },
  { id: 'grocery', name: 'Grocery & Supermarkets' },
  { id: 'transport', name: 'Transport & Vehicles' },
  { id: 'events', name: 'Events & Activities' },
  { id: 'nightlife', name: 'Bars & Nightclubs' },
  { id: 'mobile', name: 'Mobile & Tablets' },
  { id: 'laptops', name: 'Laptops & Computers' },
  { id: 'electrical', name: 'Electrical & Electronics' }
];

const EditAd = () => {
  const { adId } = useParams<{ adId: string }>();
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const [ad, setAd] = useState<Ad | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('');
  const [district, setDistrict] = useState('');
  const [town, setTown] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [images, setImages] = useState<File[]>([]);
  const [existingImages, setExistingImages] = useState<any[]>([]);

  const selectedDistrict = kumaonDistricts.find(d => d.id === district);
  const selectedCategory = categories.find(c => c.id === category);
  const priceLabel = selectedCategory?.priceLabel || 'Price';

  useEffect(() => {
    const fetchAd = async () => {
      if (!adId) return;

      try {
        const [fetchedAd] = await sql<Ad>`
          SELECT * FROM neondb.ads 
          WHERE id = ${adId}::uuid
        `;

        if (!fetchedAd) {
          setError('Ad not found');
          return;
        }

        if (fetchedAd.user_id !== currentUser?.id) {
          setError('You do not have permission to edit this ad');
          return;
        }

        // Fetch images
        const images = await sql`
          SELECT * FROM neondb.ad_images 
          WHERE ad_id = ${adId}::uuid 
          ORDER BY is_primary DESC
        `;

        setAd(fetchedAd);
        setTitle(fetchedAd.title);
        setDescription(fetchedAd.description);
        setPrice(fetchedAd.price.toString());
        setCategory(fetchedAd.category_id);
        setDistrict(fetchedAd.district_id);
        setTown(fetchedAd.town_id);
        setPhoneNumber(fetchedAd.phone_number || '');
        setExistingImages(images);
      } catch (error) {
        console.error('Error fetching ad:', error);
        setError('Failed to load ad');
      } finally {
        setLoading(false);
      }
    };

    fetchAd();
  }, [adId, currentUser]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) {
      setError('You must be logged in to edit an ad');
      return;
    }

    try {
      setSaving(true);
      setError('');

      // Update ad in database
      await sql`
        UPDATE neondb.ads 
        SET 
          title = ${title},
          description = ${description},
          price = ${parseFloat(price)},
          category_id = ${category},
          district_id = ${district},
          town_id = ${town},
          phone_number = ${phoneNumber || null},
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ${adId}::uuid 
        AND user_id = ${currentUser.id}::uuid
      `;

      // Handle new images if any
      if (images.length > 0) {
        for (const [index, file] of images.entries()) {
          const formData = new FormData();
          formData.append('file', file);

          const response = await fetch('/api/upload', {
            method: 'POST',
            body: formData,
            headers: {
              'Authorization': `Bearer ${import.meta.env.VITE_CLOUDFLARE_TOKEN}`
            }
          });

          if (!response.ok) {
            throw new Error('Failed to upload image');
          }

          const { url, cloudflareId } = await response.json();

          await sql`
            INSERT INTO neondb.ad_images (
              ad_id, url, cloudflare_id, is_primary
            ) VALUES (
              ${adId}::uuid, ${url}, ${cloudflareId}, ${index === 0}
            )
          `;
        }
      }

      navigate(`/ad/${adId}`);
    } catch (error) {
      console.error('Error updating ad:', error);
      setError('Failed to update ad');
    } finally {
      setSaving(false);
    }
  };

  const handleImageDelete = async (imageId: string) => {
    try {
      await sql`
        DELETE FROM neondb.ad_images 
        WHERE id = ${imageId} 
        AND ad_id = ${adId}::uuid
      `;

      setExistingImages(prev => prev.filter(img => img.id !== imageId));
    } catch (error) {
      console.error('Error deleting image:', error);
      setError('Failed to delete image');
    }
  };

  const handleFilesSelected = (files: File[]) => {
    setImages(files);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <Loader className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-md">
          <div className="flex items-center">
            <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
            <p className="text-red-700">{error}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-indigo-600 to-violet-600 py-6 px-8">
          <h1 className="text-2xl font-bold text-white flex items-center">
            <Edit className="mr-2" />
            Edit Ad
          </h1>
        </div>

        <div className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-gray-700 font-medium mb-2">Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-2">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              >
                <option value="">Select a category</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-2">Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                rows={5}
                required
              />
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-2">{priceLabel}</label>
              <input
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-700 font-medium mb-2">District</label>
                <select
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                >
                  <option value="">Select a district</option>
                  {kumaonDistricts.map((dist) => (
                    <option key={dist.id} value={dist.id}>{dist.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-gray-700 font-medium mb-2">Town</label>
                <select
                  value={town}
                  onChange={(e) => setTown(e.target.value)}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  disabled={!district}
                  required
                >
                  <option value="">Select a town</option>
                  {selectedDistrict?.towns.map((t) => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-2">Phone Number</label>
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="Enter your phone number (optional)"
              />
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-2">Current Images</label>
              <div className="grid grid-cols-4 gap-4 mb-4">
                {existingImages.map((image) => (
                  <div key={image.id} className="relative">
                    <img
                      src={image.url}
                      alt="Ad"
                      className="w-full h-24 object-cover rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={() => handleImageDelete(image.id)}
                      className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full hover:bg-red-600"
                    >
                      <AlertCircle className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-2">Add New Images</label>
              <FileUploader
                onFilesSelected={handleFilesSelected}
                maxFiles={5}
                acceptedFileTypes="image/*"
                maxSizeMB={5}
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full bg-gradient-to-r from-indigo-600 to-violet-600 text-white py-3 px-4 rounded-lg font-medium hover:from-indigo-700 hover:to-violet-700 transition disabled:opacity-50 flex items-center justify-center"
            >
              {saving ? (
                <>
                  <Loader className="animate-spin mr-2 h-5 w-5" />
                  Saving Changes...
                </>
              ) : (
                'Save Changes'
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditAd;