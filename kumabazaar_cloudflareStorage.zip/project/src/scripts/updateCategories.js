import { Pool } from '@neondatabase/serverless';
import * as dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Get database URL from environment variable
const databaseUrl = process.env.NEON_DATABASE_URL;

if (!databaseUrl) {
  throw new Error('NEON_DATABASE_URL environment variable is not set');
}

// Initialize connection pool
const pool = new Pool({ connectionString: databaseUrl });

async function updateCategories() {
  // Get a client from the pool
  const client = await pool.connect();
  
  try {
    console.log('Connecting to Neon database...');
    
    // Set search path to neondb schema
    await client.query('SET search_path TO neondb');
    
    console.log('Starting categories update...');
    
    // Start a transaction
    await client.query('BEGIN');
    
    try {
      // First, ensure the categories table exists with the correct structure
      await client.query(`
        CREATE TABLE IF NOT EXISTS categories (
          id text PRIMARY KEY,
          name text NOT NULL,
          icon text NOT NULL,
          price_label text DEFAULT 'Price',
          coming_soon boolean DEFAULT false,
          created_at timestamptz DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Insert or update categories using ON CONFLICT
      const upsertQuery = `
        INSERT INTO categories (id, name, icon, price_label, coming_soon)
        VALUES
          ('books', 'Books', 'BookOpen', 'Price', false),
          ('vehicles', 'Vehicles', 'Car', 'Price', false),
          ('real-estate', 'Real Estate', 'Home', 'Price', false),
          ('electronics', 'Electronics', 'Smartphone', 'Price', false),
          ('jobs', 'Jobs', 'Briefcase', 'Salary', true),
          ('furniture', 'Furniture', 'Sofa', 'Price', false),
          ('fashion', 'Fashion', 'ShoppingBag', 'Price', false),
          ('education', 'Education & Learning', 'GraduationCap', 'Fees', false),
          ('hotels', 'Hotels & Resorts', 'Hotel', 'Price', false),
          ('food', 'Food & Dining', 'UtensilsCrossed', 'Price', false),
          ('grocery', 'Grocery & Supermarkets', 'ShoppingCart', 'Price', false),
          ('transport', 'Transport & Vehicles', 'Truck', 'Price', false),
          ('events', 'Events & Activities', 'Calendar', 'Price', false),
          ('nightlife', 'Bars & Nightclubs', 'Wine', 'Price', false),
          ('mobile', 'Mobile & Tablets', 'Smartphone', 'Price', false),
          ('laptops', 'Laptops & Computers', 'Laptop', 'Price', false),
          ('electrical', 'Electrical & Electronics', 'Zap', 'Price', false),
          ('wedding', 'Wedding & Matchmaking', 'Heart', 'Price', true)
        ON CONFLICT (id) DO UPDATE SET
          name = EXCLUDED.name,
          icon = EXCLUDED.icon,
          price_label = EXCLUDED.price_label,
          coming_soon = EXCLUDED.coming_soon
        RETURNING *
      `;

      const { rows: upsertedCategories } = await client.query(upsertQuery);
      
      // Ensure indexes exist
      await client.query('CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name)');
      await client.query('CREATE INDEX IF NOT EXISTS idx_categories_coming_soon ON categories(coming_soon)');
      await client.query('CREATE INDEX IF NOT EXISTS idx_categories_price_label ON categories(price_label)');
      
      // Ensure RLS is enabled
      await client.query('ALTER TABLE categories ENABLE ROW LEVEL SECURITY');
      
      // Ensure RLS policy exists
      await client.query(`
        DO $$ 
        BEGIN
          IF NOT EXISTS (
            SELECT 1 FROM pg_policies 
            WHERE tablename = 'categories' 
            AND policyname = 'Categories are viewable by everyone'
          ) THEN
            CREATE POLICY "Categories are viewable by everyone" 
            ON categories
            FOR SELECT 
            TO public 
            USING (true);
          END IF;
        END $$;
      `);
      
      // Commit the transaction
      await client.query('COMMIT');
      
      console.log('Categories upserted successfully:', upsertedCategories.length);
      console.log('Updated categories:', upsertedCategories.map(row => row.name).join(', '));
      
      process.exit(0);
    } catch (error) {
      // Rollback on error
      await client.query('ROLLBACK');
      throw error;
    }
  } catch (error) {
    console.error('Error updating categories:', error);
    process.exit(1);
  } finally {
    // Release the client back to the pool
    client.release();
  }
}

updateCategories().catch(error => {
  console.error('Unhandled error:', error);
  process.exit(1);
});