import express from 'express';
import { body } from 'express-validator';
import { getUserProfile, updateUserProfile } from '../controllers/userController.js';
import { auth } from '../middleware/auth.js';

const router = express.Router();

// Update profile validation
const updateProfileValidation = [
  body('name').optional().trim().notEmpty().withMessage('Name cannot be empty'),
  body('email').optional().isEmail().withMessage('Invalid email')
];

router.get('/profile', auth, getUserProfile);
router.put('/profile', auth, updateProfileValidation, updateUserProfile);

export default router;