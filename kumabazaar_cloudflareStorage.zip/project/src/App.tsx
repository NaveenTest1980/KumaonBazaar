import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import PostAd from './pages/PostAd';
import EditAd from './pages/EditAd';
import AdDetails from './pages/AdDetails';
import Profile from './pages/Profile';
import CategoryPage from './pages/CategoryPage';
import ProtectedRoute from './components/ProtectedRoute';
import JobOpeningsFlyer from './components/JobOpeningsFlyer';
import Preview from './components/Preview';

function App() {
  return (
    <AuthProvider>
      <Preview>
        <div className="flex flex-col min-h-screen bg-gradient-to-br from-gray-50 via-gray-100 to-gray-50">
          {/* Background gradient - Lowest z-index */}
          <div className="fixed inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.3),rgba(255,255,255,0))] z-0" />
          
          {/* Main content - Higher z-index */}
          <div className="relative z-[2]">
            <JobOpeningsFlyer />
            <Header />
            <main className="flex-grow container mx-auto px-4 py-8">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/category/:categoryId" element={<CategoryPage />} />
                <Route path="/ad/:adId" element={<AdDetails />} />
                <Route 
                  path="/post-ad" 
                  element={
                    <ProtectedRoute>
                      <PostAd />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/edit-ad/:adId" 
                  element={
                    <ProtectedRoute>
                      <EditAd />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/profile" 
                  element={
                    <ProtectedRoute>
                      <Profile />
                    </ProtectedRoute>
                  } 
                />
              </Routes>
            </main>
            <Footer />
          </div>
        </div>
      </Preview>
    </AuthProvider>
  );
}

export default App;