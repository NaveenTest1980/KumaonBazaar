import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { sql } from '../db/neon';
import { User } from '../types/User';

interface AuthContextType {
  currentUser: User | null;
  loading: boolean;
  register: (email: string, password: string, name: string) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

// Use localStorage for better persistence
const AUTH_KEY = 'auth_user';

// Hash password using Web Crypto API for better security
async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  
  // Use SHA-256 for password hashing
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashedPassword = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  
  return hashedPassword;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing auth on mount
    const savedUser = localStorage.getItem(AUTH_KEY);
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser);
        setCurrentUser(userData);
      } catch (error) {
        console.error('Error parsing auth data:', error);
        localStorage.removeItem(AUTH_KEY);
      }
    }
    setLoading(false);
  }, []);

  // Persist user data whenever it changes
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(AUTH_KEY, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(AUTH_KEY);
    }
  }, [currentUser]);

  async function register(email: string, password: string, name: string) {
    try {
      // Check if user exists
      const [existingUser] = await sql`
        SELECT id, email FROM neondb.users 
        WHERE email = ${email}
      `;

      if (existingUser) {
        throw new Error('User with this email already exists');
      }

      // Hash password
      const hashedPassword = await hashPassword(password);

      // Create new user
      const [newUser] = await sql`
        INSERT INTO neondb.users (name, email, password_hash)
        VALUES (${name}, ${email}, ${hashedPassword})
        RETURNING id, name, email
      `;

      if (!newUser) {
        throw new Error('Failed to create user');
      }

      // Set current user
      setCurrentUser({
        id: newUser.id,
        name: newUser.name,
        email: newUser.email
      });

    } catch (error: any) {
      console.error('Registration error:', error);
      throw new Error(error.message || 'Failed to register');
    }
  }

  async function login(email: string, password: string) {
    try {
      // Hash the provided password
      const hashedPassword = await hashPassword(password);

      // Get user and verify password
      const [user] = await sql`
        SELECT id, name, email 
        FROM neondb.users 
        WHERE email = ${email} 
        AND password_hash = ${password}
      `;

      if (!user) {
        throw new Error('Invalid email or password');
      }

      // Set current user
      setCurrentUser({
        id: user.id,
        name: user.name,
        email: user.email
      });

    } catch (error: any) {
      console.error('Login error:', error);
      throw new Error('Invalid email or password');
    }
  }

  async function logout() {
    setCurrentUser(null);
  }

  const value = {
    currentUser,
    loading,
    register,
    login,
    logout
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}