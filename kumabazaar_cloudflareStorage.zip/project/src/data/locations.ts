interface Town {
  id: string;
  name: string;
}

interface District {
  id: string;
  name: string;
  towns: Town[];
}

export const kumaonDistricts: District[] = [
  {
    id: 'almora',
    name: 'Almora',
    towns: [
      { id: 'almora-city', name: 'Almora City' },
      { id: 'ranikhet', name: 'Ranikhet' },
      { id: 'dwarahat', name: 'Dwarahat' },
      { id: 'someshwar', name: 'Someshwar' },
      { id: 'chaukhutiya', name: 'Chaukhutiya' }
    ]
  },
  {
    id: 'bageshwar',
    name: 'Bageshwar',
    towns: [
      { id: 'bageshwar-city', name: 'Bageshwar City' },
      { id: 'kapkot', name: 'Kapkot' },
      { id: 'kausani', name: 'Kausani' },
      { id: 'garur', name: 'Garur' }
    ]
  },
  {
    id: 'champawat',
    name: 'Champawat',
    towns: [
      { id: 'champawat-city', name: 'Champawat City' },
      { id: 'lohaghat', name: 'Lohaghat' },
      { id: 'tanakpur', name: 'Tanakpur' },
      { id: 'banbasa', name: 'Banbasa' }
    ]
  },
  {
    id: 'nainital',
    name: 'Nainital',
    towns: [
      { id: 'nainital-city', name: 'Nainital City' },
      { id: 'haldwani', name: 'Haldwani' },
      { id: 'bhowali', name: 'Bhowali' },
      { id: 'bhimtal', name: 'Bhimtal' },
      { id: 'ramnagar', name: 'Ramnagar' },
      { id: 'kaladhungi', name: 'Kaladhungi' },
      { id: 'mukteshwar', name: 'Mukteshwar' }
    ]
  },
  {
    id: 'pithoragarh',
    name: 'Pithoragarh',
    towns: [
      { id: 'pithoragarh-city', name: 'Pithoragarh City' },
      { id: 'dharchula', name: 'Dharchula' },
      { id: 'didihat', name: 'Didihat' },
      { id: 'berinag', name: 'Berinag' },
      { id: 'gangolihat', name: 'Gangolihat' }
    ]
  },
  {
    id: 'udhamsingh',
    name: 'Udham Singh Nagar',
    towns: [
      { id: 'rudrapur', name: 'Rudrapur' },
      { id: 'kashipur', name: 'Kashipur' },
      { id: 'kichha', name: 'Kichha' },
      { id: 'jaspur', name: 'Jaspur' },
      { id: 'bazpur', name: 'Bazpur' },
      { id: 'gadarpur', name: 'Gadarpur' },
      { id: 'khatima', name: 'Khatima' }
    ]
  }
];

const getAllLocations = () => {
  const locations: { id: string; name: string; district: string }[] = [];
  
  kumaonDistricts.forEach(district => {
    district.towns.forEach(town => {
      locations.push({
        id: town.id,
        name: town.name,
        district: district.name
      });
    });
  });
  
  return locations;
};