export interface Ad {
  id: string;
  title: string;
  description: string;
  price: number;
  category_id: string;
  location: string;
  district_id: string;
  town_id: string;
  user_id: string;
  created_at: string;
  updated_at: string;
  featured: boolean;
  needs_moderation: boolean;
  phone_number?: string;
  phone_number_visible: boolean;
  status: AdStatus;
  user_name?: string;
  price_label?: string;
  images: AdImage[];
}

export interface AdImage {
  id: string;
  url: string;
  is_primary: boolean;
  created_at: string;
}

export enum AdStatus {
  Active = 'Active',
  Pending = 'Pending',
  Rejected = 'Rejected',
  Expired = 'Expired',
  Sold = 'Sold'
}

export interface CreateAdRequest {
  title: string;
  description: string;
  price: number;
  categoryId: string;
  location: string;
  districtId: string;
  townId: string;
  userId: string;
  phoneNumber?: string;
  featured?: boolean;
}

export interface UpdateAdRequest {
  title?: string;
  description?: string;
  price?: number;
  categoryId?: string;
  location?: string;
  districtId?: string;
  townId?: string;
  phoneNumber?: string;
  phoneNumberVisible?: boolean;
  featured?: boolean;
  needs_moderation?: boolean;
  status?: AdStatus;
}

export interface AdSearchParams {
  query?: string;
  categoryId?: string;
  districtId?: string;
  userId?: string;
  limit?: number;
  offset?: number;
  sortBy?: 'newest' | 'price-low' | 'price-high';
}

export interface PhoneNumberExtensionRequest {
  adId: string;
  userId: string;
  paymentMethod: string;
  paymentId?: string;
}