import { S3Client } from '@aws-sdk/client-s3';

// Initialize S3 client for Cloudflare R2
export const s3Client = new S3Client({
  region: 'auto',
  endpoint: `https://${import.meta.env.VITE_CLOUDFLARE_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: import.meta.env.VITE_CLOUDFLARE_ACCESS_KEY_ID,
    secretAccessKey: import.meta.env.VITE_CLOUDFLARE_SECRET_ACCESS_KEY
  },
  forcePathStyle: true, // Required for Cloudflare R2
  // Add CORS configuration
  config: {
    cors: {
      allowOrigin: '*',
      allowMethods: ['PUT', 'POST', 'GET', 'DELETE', 'HEAD'],
      allowHeaders: ['*'],
      exposeHeaders: ['ETag']
    }
  }
});