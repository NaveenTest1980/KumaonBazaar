import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { v4 as uuidv4 } from 'uuid';

// Initialize S3 client for Cloudflare R2
const s3Client = new S3Client({
  region: 'auto',
  endpoint: `https://${import.meta.env.VITE_CLOUDFLARE_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: import.meta.env.VITE_CLOUDFLARE_ACCESS_KEY_ID,
    secretAccessKey: import.meta.env.VITE_CLOUDFLARE_SECRET_ACCESS_KEY
  },
  // Add CORS configuration
  config: {
    cors: {
      allowOrigin: '*',
      allowMethods: ['PUT', 'POST', 'GET', 'DELETE', 'HEAD'],
      allowHeaders: ['*'],
      exposeHeaders: ['ETag']
    }
  }
});

// Supported file types with proper MIME types
const SUPPORTED_FILE_TYPES = [
  'image/jpeg',
  'image/png',
  'image/gif',
  'image/webp'
];

// Maximum file size (5MB)
const MAX_FILE_SIZE = 5 * 1024 * 1024;

// Retry configuration
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000; // 1 second

export async function uploadImage(
  file: File,
  onProgress?: (progress: number) => void
): Promise<{ url: string; cloudflareId: string }> {
  let retryCount = 0;

  async function attemptUpload(): Promise<{ url: string; cloudflareId: string }> {
    try {
      console.log('Starting image upload process:', {
        fileName: file.name,
        fileType: file.type,
        fileSize: file.size,
        attempt: retryCount + 1
      });

      // Validate file type
      if (!SUPPORTED_FILE_TYPES.includes(file.type)) {
        throw new Error(`Unsupported file type: ${file.type}. Supported types are: ${SUPPORTED_FILE_TYPES.join(', ')}`);
      }

      // Validate file size
      if (file.size > MAX_FILE_SIZE) {
        throw new Error(`File size exceeds 5MB limit. Current size: ${(file.size / 1024 / 1024).toFixed(2)}MB`);
      }

      // Generate a unique file ID with proper extension
      const fileId = uuidv4();
      const extension = file.name.split('.').pop()?.toLowerCase() || 'jpg';
      const objectKey = `ads/${fileId}.${extension}`;

      // Create PutObject command with optimized settings
      const command = new PutObjectCommand({
        Bucket: import.meta.env.VITE_CLOUDFLARE_BUCKET_NAME,
        Key: objectKey,
        Body: file,
        ContentType: file.type,
        CacheControl: 'public, max-age=31536000', // Cache for 1 year
        Metadata: {
          'original-filename': file.name,
          'upload-date': new Date().toISOString(),
          'content-type': file.type
        }
      });

      // Start upload progress
      if (onProgress) {
        onProgress(10);
      }

      try {
        // Upload to R2 with progress tracking
        await s3Client.send(command);

        // Upload complete
        if (onProgress) {
          onProgress(100);
        }

        // Return the public URL and Cloudflare ID
        const publicUrl = `${import.meta.env.VITE_CLOUDFLARE_PUBLIC_URL}/${objectKey}`;

        console.log('Upload completed successfully:', {
          objectKey,
          size: file.size,
          type: file.type
        });

        return {
          url: publicUrl,
          cloudflareId: objectKey
        };
      } catch (error) {
        console.error('Error uploading to R2:', error);
        throw new Error(`Failed to upload to R2: ${error.message}`);
      }
    } catch (error: any) {
      // Handle retries
      if (retryCount < MAX_RETRIES && error.message.includes('network')) {
        retryCount++;
        console.log(`Retrying upload (attempt ${retryCount + 1}/${MAX_RETRIES})...`);
        await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
        return attemptUpload();
      }
      throw error;
    }
  }

  try {
    return await attemptUpload();
  } catch (error: any) {
    console.error('Upload failed after retries:', error);
    throw new Error(`Upload failed: ${error.message}`);
  }
}

export function getImageUrl(path: string | null): string | null {
  if (!path) return null;
  
  try {
    // Ensure the path is properly formatted
    const cleanPath = path.startsWith('/') ? path.slice(1) : path;
    return `${import.meta.env.VITE_CLOUDFLARE_PUBLIC_URL}/${cleanPath}`;
  } catch (error) {
    console.error('Error generating image URL:', error);
    return null;
  }
}

// Add image optimization parameters to URL
export function getOptimizedImageUrl(
  path: string | null,
  options: { width?: number; height?: number; quality?: number } = {}
): string | null {
  const baseUrl = getImageUrl(path);
  if (!baseUrl) return null;

  const params = new URLSearchParams();
  if (options.width) params.append('width', options.width.toString());
  if (options.height) params.append('height', options.height.toString());
  if (options.quality) params.append('quality', options.quality.toString());

  return `${baseUrl}?${params.toString()}`;
}