// API URL from environment variable with fallback
export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// Cloudflare R2 configuration
export const CLOUDFLARE_CONFIG = {
  accountId: import.meta.env.VITE_CLOUDFLARE_ACCOUNT_ID,
  accessKeyId: import.meta.env.VITE_CLOUDFLARE_ACCESS_KEY_ID,
  secretAccessKey: import.meta.env.VITE_CLOUDFLARE_SECRET_ACCESS_KEY,
  bucketName: import.meta.env.VITE_CLOUDFLARE_BUCKET_NAME,
  publicUrl: import.meta.env.VITE_CLOUDFLARE_PUBLIC_URL
};

// File upload configuration
export const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
export const SUPPORTED_FILE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
export const DEFAULT_IMAGE_URL = 'https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';